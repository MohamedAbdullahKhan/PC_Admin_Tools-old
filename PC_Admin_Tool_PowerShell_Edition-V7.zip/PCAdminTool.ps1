﻿#Requires -Version 5.0
# ============================================================
#  PC Admin & Performance Tool  v2.7 -- PowerShell GUI Edition
#  (c) 2024-2026 Abdullah | All Rights Reserved
#  Contact: abuabdullah.be@outlook.com
# ============================================================
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch {}

$COPY  = "(c) 2024-2026 Abdullah  |  All Rights Reserved  |  abuabdullah.be@outlook.com"
$COPYL = "(c) 2024-2026 Abdullah  |  PC Admin & Performance Tool v2.7  |  All Rights Reserved  |  abuabdullah.be@outlook.com"
$VER   = "v2.7  PowerShell GUI Edition"
$DIR   = if ($MyInvocation.MyCommand.Path) { Split-Path $MyInvocation.MyCommand.Path } else { $PWD.Path }
$LOGD  = Join-Path $DIR "PC_Admin_Logs"
if (-not (Test-Path $LOGD)) { New-Item -ItemType Directory -Path $LOGD | Out-Null }

function HC([string]$h) { [System.Drawing.ColorTranslator]::FromHtml($h) }
$BG=HC "#111827"; $PNL=HC "#1a2438"; $CARD=HC "#1f2e47"; $CRD2=HC "#263654"
$BDR=HC "#2e4368"; $BDR2=HC "#3a5580"; $ACC=HC "#1d4ed8"
$CYAN=HC "#22d3ee"; $GRN=HC "#22c55e"; $RED=HC "#ef4444"; $YEL=HC "#f59e0b"
$TXT=HC "#d1dff0"; $TXTB=HC "#eef2ff"; $TXDD=HC "#5c7a9a"; $LOGBG=HC "#090f1a"
$HDRB=HC "#08111e"; $DIM=HC "#2d4a68"; $OUT2=HC "#8ab0cc"

$DANGER=@("flush_dns","net_reset","run_sfc","dism_check","high_perf","empty_recycle","disk_cleanup_util")
$TMAP=[ordered]@{
    "Windows Domain (NTLM) -- Recommended"="Negotiate"
    "Workgroup / Local Account (Basic)"="Basic"
    "Active Directory (Kerberos)"="Kerberos"
    "Admin Double-Hop (CredSSP)"="Credssp"
}
$CbMap=@{}; $Script:LogFile=$null; $Script:BgPS=$null; $Script:BgRS=$null
$SH=[hashtable]::Synchronized(@{
    Q=[System.Collections.Concurrent.ConcurrentQueue[hashtable]]::new()
    Stop=$false; Done=$false; Pv=0; Pm=1; Stat=""; Task=""
})

function GF([string]$n="Segoe UI",[int]$s=9,[switch]$B) {
    $style = [System.Drawing.FontStyle]::Regular
    if ($B) { $style = [System.Drawing.FontStyle]::Bold }
    New-Object System.Drawing.Font($n,$s,$style)
}
function MF {
    foreach($f in @("Cascadia Mono","Consolas","Courier New")){
        if(([System.Drawing.FontFamily]::Families|Select-Object -Expand Name) -contains $f){
            return New-Object System.Drawing.Font($f,9)
        }
    }
    return New-Object System.Drawing.Font("Courier New",9)
}

# ============================================================
# OPERATIONS (36 total)
# ============================================================
$Ops=@(
 @{Id="clear_user_temp";Cat="Cleanup";D=$false;L="Clear All Users Temp Files";Ds="Removes %TEMP% from every user profile (incl. SYSTEM/service accounts)"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     $tot=0;$denied=0;$profCount=0
     $us=Get-ChildItem "C:\Users" -Directory -Force -EA SilentlyContinue
     if(-not $us){Write-Output "  WARNING: Cannot access C:\Users (insufficient rights?)"}
     else{
       Write-Output "  Found $($us.Count) user profile folder(s) under C:\Users"
       foreach($u in $us){
         if($u.Name -in @("Default","Default User","Public","All Users")){continue}
         $profCount++
         $p="$($u.FullName)\AppData\Local\Temp"
         if(Test-Path $p){
           $it=Get-ChildItem $p -Recurse -Force -EA SilentlyContinue -ErrorVariable errs
           $sz=($it|Measure-Object Length -Sum -EA SilentlyContinue).Sum;if(-not $sz){$sz=0}
           $before=$it.Count
           $it|Remove-Item -Recurse -Force -EA SilentlyContinue -ErrorVariable delErrs
           $mb=[math]::Round($sz/1MB,2);$tot+=$mb
           if($delErrs -and $delErrs.Count -gt 0){
             $denied++
             Write-Output "  [$($u.Name)] Freed $mb MB  ($($delErrs.Count) file(s) skipped -- in use / access denied)"
           } else {
             Write-Output "  [$($u.Name)] Freed $mb MB  ($before items)"
           }
         }else{
           Write-Output "  [$($u.Name)] No temp folder (profile never fully loaded)"
         }
       }
     }
     # Also clear SYSTEM and built-in service account temp -- these are real
     # profiles too and are commonly missed by "all users" cleanup tools.
     $svcProfiles=@(
       @{Name="SYSTEM";Path="C:\Windows\System32\config\systemprofile\AppData\Local\Temp"}
       @{Name="LocalService";Path="C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"}
       @{Name="NetworkService";Path="C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp"}
     )
     foreach($sp in $svcProfiles){
       if(Test-Path $sp.Path){
         $it=Get-ChildItem $sp.Path -Recurse -Force -EA SilentlyContinue
         $sz=($it|Measure-Object Length -Sum -EA SilentlyContinue).Sum;if(-not $sz){$sz=0}
         $it|Remove-Item -Recurse -Force -EA SilentlyContinue -ErrorVariable svcErrs
         $mb=[math]::Round($sz/1MB,2);$tot+=$mb
         $note=if($svcErrs -and $svcErrs.Count -gt 0){" ($($svcErrs.Count) file(s) skipped -- in use)"}else{""}
         Write-Output "  [$($sp.Name)] Freed $mb MB$note"
         $profCount++
       }
     }
     Write-Output "  ------------------------------------------------"
     Write-Output "  Profiles processed: $profCount   |   TOTAL FREED: $tot MB"
     if($denied -gt 0){Write-Output "  NOTE: $denied profile(s) had files in use and were partially skipped (normal for the logged-in user's active session)"}
   }
 }
 @{Id="clear_win_temp";Cat="Cleanup";D=$false;L="Clear Windows System Temp";Ds="Deletes C:\Windows\Temp"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     $p="C:\Windows\Temp"
     if(Test-Path $p){
       $it=Get-ChildItem $p -Recurse -EA SilentlyContinue
       $sz=($it|Measure-Object Length -Sum -EA SilentlyContinue).Sum;if(-not $sz){$sz=0}
       $it|Remove-Item -Recurse -Force -EA SilentlyContinue
       Write-Output "  Deleted $($it.Count) items | Freed: $([math]::Round($sz/1MB,2)) MB"
     }else{
       Write-Output "  Not found: $p"
     }
   }
 }
 @{Id="clear_prefetch";Cat="Cleanup";D=$false;L="Clear Windows Prefetch Files";Ds="Removes .pf files from Prefetch"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     $p="C:\Windows\Prefetch"
     if(Test-Path $p){
       $f=Get-ChildItem $p -Filter "*.pf" -EA SilentlyContinue
       $sz=($f|Measure-Object Length -Sum -EA SilentlyContinue).Sum;if(-not $sz){$sz=0}
       $f|Remove-Item -Force -EA SilentlyContinue
       Write-Output "  Removed $($f.Count) files | Freed: $([math]::Round($sz/1MB,2)) MB"
     }else{
       Write-Output "  Prefetch not found"
     }
   }
 }
 @{Id="clear_thumb";Cat="Cleanup";D=$false;L="Clear Thumbnail Cache (All Users)";Ds="Deletes thumbcache_*.db from all Explorer profiles"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     $tot=0
     Get-ChildItem "C:\Users" -Directory -EA SilentlyContinue|ForEach-Object{
       $p="$($_.FullName)\AppData\Local\Microsoft\Windows\Explorer"
       if(Test-Path $p){
         $f=Get-ChildItem $p -Filter "thumbcache_*.db" -EA SilentlyContinue
         $sz=($f|Measure-Object Length -Sum -EA SilentlyContinue).Sum;if(-not $sz){$sz=0}
         $f|Remove-Item -Force -EA SilentlyContinue
         $mb=[math]::Round($sz/1MB,2);$tot+=$mb
         Write-Output "  [$($_.Name)] $($f.Count) files | $mb MB"
       }
     }
     Write-Output "  Total freed: $tot MB"
   }
 }
 @{Id="clear_wu";Cat="Cleanup";D=$false;L="Clear Windows Update Download Cache";Ds="Stops WU/BITS, clears SoftwareDistribution\Download"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     Stop-Service wuauserv,bits -Force -EA SilentlyContinue;Start-Sleep 2
     $p="C:\Windows\SoftwareDistribution\Download"
     if(Test-Path $p){
       $sz=(Get-ChildItem $p -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum
       if(-not $sz){$sz=0};Remove-Item "$p\*" -Recurse -Force -EA SilentlyContinue
       Write-Output "  Cache cleared | Freed: $([math]::Round($sz/1MB,2)) MB"
     }
     Start-Service wuauserv,bits -EA SilentlyContinue
     Write-Output "  WU and BITS restarted"
   }
 }
 @{Id="flush_dns";Cat="Cleanup";D=$true;L="Flush DNS Resolver Cache";Ds="SAFE: Clears local DNS cache + /registerdns to preserve network"
   Cmd={
     $ProgressPreference="SilentlyContinue"
     Write-Output "  SAFE FLUSH -- local DNS cache only"
     $b=@(Get-DnsClientCache -EA SilentlyContinue).Count
     Write-Output "  Entries before: $b"
     Clear-DnsClientCache -EA SilentlyContinue
     ipconfig /flushdns 2>&1|Out-Null;ipconfig /registerdns 2>&1|Out-Null
     $a=@(Get-DnsClientCache -EA SilentlyContinue).Count
     Write-Output "  Entries after: $a"
     $gw=(Get-NetIPConfiguration -EA SilentlyContinue|Where-Object{$_.IPv4DefaultGateway}|Select-Object -First 1).IPv4DefaultGateway.NextHop
     if($gw){
       $pg=Test-NetConnection $gw -WarningAction SilentlyContinue -EA SilentlyContinue
       $gwStatus="check connectivity"
       if($pg.PingSucceeded){$gwStatus="REACHABLE"}
       Write-Output "  Gateway $gw : $gwStatus"
     }
     Write-Output "  DNS flushed safely -- domain connectivity preserved"
   }
 }
 @{Id="clear_browsers";Cat="Cleanup";D=$false;L="Clear Browser Caches (Chrome/Edge/Firefox)";Ds="Purges browser cache folders for all user profiles"
   Cmd={$ProgressPreference="SilentlyContinue"
   $brs=@{"Chrome"="\AppData\Local\Google\Chrome\User Data\Default\Cache";"Edge"="\AppData\Local\Microsoft\Edge\User Data\Default\Cache"}
   $tot=0
   Get-ChildItem "C:\Users" -Directory -EA SilentlyContinue|ForEach-Object{
     $u=$_;foreach($b in $brs.GetEnumerator()){$p="$($u.FullName)$($b.Value)"
       if(Test-Path $p){$sz=(Get-ChildItem $p -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum
         if(-not $sz){$sz=0};Remove-Item "$p\*" -Recurse -Force -EA SilentlyContinue
         $mb=[math]::Round($sz/1MB,2);$tot+=$mb;Write-Output "  [$($u.Name)] $($b.Key): $mb MB"}}
     $ff="$($u.FullName)\AppData\Local\Mozilla\Firefox\Profiles"
     if(Test-Path $ff){Get-ChildItem $ff -Directory -EA SilentlyContinue|ForEach-Object{
         $c2="$($_.FullName)\cache2";if(Test-Path $c2){
           $sz=(Get-ChildItem $c2 -Recurse -EA SilentlyContinue|Measure-Object Length -Sum).Sum
           if(-not $sz){$sz=0};Remove-Item "$c2\*" -Recurse -Force -EA SilentlyContinue
           $mb=[math]::Round($sz/1MB,2);$tot+=$mb;Write-Output "  [$($u.Name)] Firefox: $mb MB"}}}}
   Write-Output "  TOTAL browser cache freed: $tot MB" } }
 @{Id="clear_evtlogs";Cat="Cleanup";D=$false;L="Clear Windows Event Logs";Ds="Clears App/System/Setup -- skips Security if >100k entries"
   Cmd={$ProgressPreference="SilentlyContinue"
   foreach($log in @("Application","System","Security","Setup")){try{
     $cnt=0;try{$li=Get-WinEvent -ListLog $log -EA SilentlyContinue;if($li){$cnt=$li.RecordCount}}catch{}
     if($log -eq "Security" -and $cnt -gt 100000){
       Write-Output "  SKIPPED: $log ($cnt entries) -- too large, would hang session";continue}
     wevtutil cl "$log" 2>$null;Write-Output "  Cleared: $log ($cnt entries)"}
   catch{Write-Output "  Skipped: $log"}}}}
 @{Id="empty_recycle";Cat="Cleanup";D=$true;L="Empty Recycle Bin (All Drives)";Ds="Permanently empties Recycle Bin -- cannot be undone"
   Cmd={$ProgressPreference="SilentlyContinue"
   try{$sh2=New-Object -ComObject Shell.Application
     $cnt=($sh2.Namespace(0xA).Items()|Measure-Object).Count
     Clear-RecycleBin -Force -EA Stop;Write-Output "  Recycle Bin emptied: $cnt items"}
   catch{Write-Output "  Already empty or error: $_"}}}
 @{Id="disk_cleanup_util";Cat="Cleanup";D=$true;L="Run Disk Cleanup Utility (cleanmgr)";Ds="Runs Windows Disk Cleanup silently with all categories"
   Cmd={$ProgressPreference="SilentlyContinue"
   $base="HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches";$n=0
   Get-ChildItem $base -EA SilentlyContinue|ForEach-Object{Set-ItemProperty $_.PSPath -Name StateFlags0099 -Value 2 -EA SilentlyContinue;$n++}
   Write-Output "  Configured $n categories"
   Write-Output "  Launching cleanmgr (max wait: 10 minutes)..."
   $p=Start-Process cleanmgr -ArgumentList "/sagerun:99" -WindowStyle Hidden -PassThru -EA SilentlyContinue
   if($p){
     if(-not $p.WaitForExit(600000)){
       Write-Output "  WARNING: cleanmgr did not finish within 10 minutes -- no desktop is"
       Write-Output "  attached in a remote session, so it can wait forever on a UI dialog"
       Write-Output "  nobody can see. Terminating it now."
       try{$p.Kill()}catch{}
       Get-Process cleanmgr -EA SilentlyContinue|Stop-Process -Force -EA SilentlyContinue
       Write-Output "  Disk Cleanup was terminated after timeout -- some categories may be incomplete"
     } else {
       Write-Output "  Disk Cleanup completed (exit code: $($p.ExitCode))"
     }
   } else { Write-Output "  Failed to launch cleanmgr" } } }
 @{Id="disk_report";Cat="Disk";D=$false;L="Disk Space Report (All Drives)";Ds="Shows used/free/health for all fixed drives"
   Cmd={$ProgressPreference="SilentlyContinue"
   $vols=Get-Volume -EA SilentlyContinue|Where-Object{$_.DriveType -eq "Fixed" -and $_.DriveLetter}
   if(-not $vols){Write-Output "  No fixed volumes";return}
   foreach($v in $vols){$t=[math]::Round($v.Size/1GB,2);$f=[math]::Round($v.SizeRemaining/1GB,2);$u=[math]::Round($t-$f,2)
     $pct=if($t -gt 0){"$([math]::Round(($u/$t)*100,0))%"}else{"N/A"}
     $w=if($t -gt 0 -and ($u/$t) -gt 0.9){"CRITICAL"}elseif($t -gt 0 -and ($u/$t) -gt 0.8){"LOW"}else{"OK"}
     Write-Output "  $($v.DriveLetter):  $($v.FileSystem) ${t}GB used=${u}GB free=${f}GB  $pct  [$w]"}}}
 @{Id="defrag_drives";Cat="Disk";D=$false;L="Optimize / Defragment All Fixed Drives";Ds="Defragments HDDs; TRIM on SSDs (auto-detects)"
   Cmd={$ProgressPreference="SilentlyContinue"
   $vols=Get-Volume -EA SilentlyContinue|Where-Object{$_.DriveType -eq "Fixed" -and $_.DriveLetter -and $_.FileSystem -match "NTFS|ReFS"}
   foreach($v in $vols){$dl=$v.DriveLetter;Write-Output "  Optimizing ${dl}: ..."
     Optimize-Volume -DriveLetter $dl -Verbose 4>$null -EA SilentlyContinue;Write-Output "  Drive ${dl}: complete"}}}
 @{Id="disk_health";Cat="Disk";D=$false;L="Scan Disk Health (Quick -- No Reboot)";Ds="Runs Repair-Volume scan on all drives"
   Cmd={$ProgressPreference="SilentlyContinue"
   $vols=Get-Volume -EA SilentlyContinue|Where-Object{$_.DriveType -eq "Fixed" -and $_.DriveLetter}
   foreach($v in $vols){$dl=$v.DriveLetter;Write-Output "  Scanning ${dl}: ..."
     $r=Repair-Volume -DriveLetter $dl -Scan -EA SilentlyContinue
     Write-Output "  Drive ${dl}: Scan=$r  Health=$($v.HealthStatus)"}}}
 @{Id="large_files";Cat="Disk";D=$false;L="Find Top 20 Largest Files on C:";Ds="Files >100 MB on C: sorted by size"
   Cmd={$ProgressPreference="SilentlyContinue";Write-Output "  Scanning C: ..."
   $files=Get-ChildItem "C:\" -Recurse -File -EA SilentlyContinue|Where-Object{$_.Length -gt 100MB}
   $files|Sort-Object Length -Desc|Select-Object -First 20|ForEach-Object{
     Write-Output "  $([math]::Round($_.Length/1GB,3).ToString("F3")) GB   $($_.FullName)"}
   Write-Output "  Total large files: $($files.Count)"}}
 @{Id="high_perf";Cat="Performance";D=$true;L="Set High Performance Power Plan";Ds="Activates High Performance -- increases power on laptops"
   Cmd={$ProgressPreference="SilentlyContinue"
   powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2>$null
   Write-Output "  High Performance power plan activated"
   Write-Output "  NOTE: On laptops this increases heat and power usage" } }
 @{Id="visual_perf";Cat="Performance";D=$false;L="Optimize Visual Effects for Performance";Ds="Sets Best Performance mode -- disables animations"
   Cmd={$ProgressPreference="SilentlyContinue"
   $vfx="HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
   if(-not(Test-Path $vfx)){New-Item $vfx -Force -EA SilentlyContinue|Out-Null}
   Set-ItemProperty $vfx VisualFXSetting 2 -EA SilentlyContinue
   Set-ItemProperty "HKCU:\Control Panel\Desktop" DragFullWindows "0" -EA SilentlyContinue
   Set-ItemProperty "HKCU:\Control Panel\Desktop" MenuShowDelay "0" -EA SilentlyContinue
   Write-Output "  Visual effects set to Best Performance -- re-login for full effect" } }
 @{Id="ram_optimize";Cat="Performance";D=$false;L="Optimize RAM / Force GC Collection";Ds="Reports RAM before/after forcing .NET garbage collection"
   Cmd={$ProgressPreference="SilentlyContinue"
   $os=Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
   if(-not $os){Write-Output "  Cannot query WMI";return}
   $tot=[math]::Round($os.TotalVisibleMemorySize/1MB,2)
   $frB=[math]::Round($os.FreePhysicalMemory/1MB,2)
   Write-Output "  RAM BEFORE: Total=${tot}GB | Used=$([math]::Round($tot-$frB,2))GB | Free=${frB}GB"
   [System.GC]::Collect();[System.GC]::WaitForPendingFinalizers();[System.GC]::Collect()
   $frA=[math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,2)
   Write-Output "  RAM AFTER : Total=${tot}GB | Used=$([math]::Round($tot-$frA,2))GB | Free=${frA}GB"
   Write-Output "  Recovered : $([math]::Round($frA-$frB,2)) GB" } }
 @{Id="sysmain_tune";Cat="Performance";D=$false;L="Auto-Tune SysMain / Superfetch";Ds="Disables on SSD; keeps active on HDD systems"
   Cmd={$ProgressPreference="SilentlyContinue"
   $svc=Get-Service "SysMain" -EA SilentlyContinue
   $ssds=Get-PhysicalDisk -EA SilentlyContinue|Where-Object{$_.MediaType -eq "SSD"}
   if($ssds){Write-Output "  SSD detected ($($ssds.Count))"
     if($svc -and $svc.Status -eq "Running"){
       Stop-Service SysMain -Force -EA SilentlyContinue
       Set-Service SysMain -StartupType Disabled -EA SilentlyContinue
       Write-Output "  SysMain DISABLED (recommended for SSD)"}
     else{Write-Output "  SysMain already disabled"}}
   else{Write-Output "  HDD system -- keeping SysMain ACTIVE"} } }
 @{Id="restart_search";Cat="Performance";D=$false;L="Restart Windows Search Indexer";Ds="Restarts WSearch to free CPU/disk"
   Cmd={$ProgressPreference="SilentlyContinue"
   $svc=Get-Service "WSearch" -EA SilentlyContinue
   if($svc){Stop-Service WSearch -Force -EA SilentlyContinue;Start-Sleep 2
     Start-Service WSearch -EA SilentlyContinue;Write-Output "  Windows Search indexer restarted"}
   else{Write-Output "  WSearch service not found"} } }
 @{Id="startup_report";Cat="Performance";D=$false;L="Startup Programs and Services Report";Ds="Lists all autostart entries from registry"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === STARTUP REGISTRY ENTRIES ==="
   @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run","HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run")|ForEach-Object{
     if(Test-Path $_){$b=$_.Split("\")[-3]
       Get-ItemProperty $_ -EA SilentlyContinue|ForEach-Object{
         $_.PSObject.Properties|Where-Object{$_.Name -notlike "PS*"}|ForEach-Object{
           Write-Output "  [$b] $($_.Name) = $($_.Value)"}}}}
   Write-Output ""
   Write-Output "  === NON-MICROSOFT SCHEDULED TASKS ==="
   Get-ScheduledTask -EA SilentlyContinue|Where-Object{$_.State -eq "Ready" -and $_.TaskPath -notlike "\Microsoft\*"}|
     Select-Object -First 20|ForEach-Object{Write-Output "  $($_.TaskPath)$($_.TaskName)"} } }
 @{Id="pagefile_report";Cat="Performance";D=$false;L="Virtual Memory / Page File Report";Ds="Shows page file path, usage and recommendations"
   Cmd={$ProgressPreference="SilentlyContinue"
   $sys=Get-CimInstance Win32_ComputerSystem -EA SilentlyContinue
   if(-not $sys){Write-Output "  Cannot query WMI";return}
   $ramGB=[math]::Round($sys.TotalPhysicalMemory/1GB,2)
   Write-Output "  RAM Installed   : ${ramGB} GB"
   Write-Output "  Auto-Managed PF : $($sys.AutomaticManagedPagefile)"
   Get-CimInstance Win32_PageFileUsage -EA SilentlyContinue|ForEach-Object{
     Write-Output "  File: $($_.Name) | Allocated: $($_.AllocatedBaseSize) MB | Used: $($_.CurrentUsage) MB | Peak: $($_.PeakUsage) MB"}
   Write-Output "  Recommended: $([math]::Round($ramGB*1024*1.5)) - $([math]::Round($ramGB*1024*3)) MB" } }
 @{Id="services_report";Cat="Performance";D=$false;L="Non-Essential Running Services Report";Ds="Lists third-party auto-start services"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === THIRD-PARTY AUTO-START RUNNING SERVICES ==="
   $svcs=Get-WmiObject Win32_Service -EA SilentlyContinue|Where-Object{
     $_.State -eq "Running" -and $_.StartMode -eq "Auto" -and
     $_.PathName -notlike "*system32*" -and $_.PathName -notlike "*SysWOW64*"}
   if($svcs){foreach($s in $svcs){$mem="N/A"
       try{$pr2=Get-Process -Id $s.ProcessId -EA SilentlyContinue
         if($pr2){$mem="$([math]::Round($pr2.WorkingSet64/1MB,1)) MB"}}catch{}
       Write-Output "  $($s.Name.PadRight(40)) RAM: $mem"}}
   else{Write-Output "  No third-party auto-start services"} } }
 @{Id="sys_info";Cat="Windows Health";D=$false;L="Full System Information Report";Ds="CPU, RAM, OS, uptime, BIOS, domain"
   Cmd={$ProgressPreference="SilentlyContinue"
   $cs=Get-CimInstance Win32_ComputerSystem -EA SilentlyContinue
   $os=Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
   $cpu=Get-CimInstance Win32_Processor -EA SilentlyContinue|Select-Object -First 1
   $bio=Get-CimInstance Win32_BIOS -EA SilentlyContinue
   if(-not $cs){Write-Output "  Cannot query WMI";return}
   $up=(Get-Date)-$os.LastBootUpTime
   Write-Output "  Hostname     : $($cs.Name)"
   Write-Output "  Manufacturer : $($cs.Manufacturer) $($cs.Model)"
   Write-Output "  OS           : $($os.Caption) $($os.OSArchitecture)"
   Write-Output "  OS Build     : $($os.Version) (Build $($os.BuildNumber))"
   Write-Output "  CPU          : $($cpu.Name)"
   Write-Output "  CPU Cores    : $($cpu.NumberOfCores) / $($cpu.NumberOfLogicalProcessors) logical"
   Write-Output "  RAM Total    : $([math]::Round($cs.TotalPhysicalMemory/1GB,2)) GB"
   if($bio){Write-Output "  BIOS         : $($bio.Manufacturer) v$($bio.SMBIOSBIOSVersion)"}
   Write-Output "  Last Boot    : $($os.LastBootUpTime.ToString("yyyy-MM-dd HH:mm:ss"))"
   Write-Output "  Uptime       : $($up.Days)d $($up.Hours)h $($up.Minutes)m"
   Write-Output "  Domain       : $($cs.Domain)"
   Write-Output "  Logged User  : $($cs.UserName)"} }
 @{Id="top_procs";Cat="Windows Health";D=$false;L="Top CPU and RAM Consuming Processes";Ds="Top 10 processes by CPU time and working set"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === TOP 10 BY CPU ==="
   Get-Process -EA SilentlyContinue|Sort-Object CPU -Desc|Select-Object -First 10|ForEach-Object{
     $c2=if($_.CPU){[math]::Round($_.CPU,1)}else{0}
     Write-Output "  $($_.Name.PadRight(32)) $($c2.ToString().PadLeft(8)) s  $([math]::Round($_.WorkingSet64/1MB,1).ToString().PadLeft(8)) MB"}
   Write-Output ""
   Write-Output "  === TOP 10 BY RAM ==="
   Get-Process -EA SilentlyContinue|Sort-Object WorkingSet64 -Desc|Select-Object -First 10|ForEach-Object{
     Write-Output "  $($_.Name.PadRight(32)) $([math]::Round($_.WorkingSet64/1MB,1).ToString().PadLeft(8)) MB  PID:$($_.Id)"} } }
 @{Id="run_sfc";Cat="Windows Health";D=$true;L="Run SFC /scannow (System File Check)";Ds="Scans and repairs corrupted system files (5-15 min)"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  Starting SFC scan (5-15 min) ..."
   sfc /scannow 2>&1|ForEach-Object{Write-Output "  $_"}
   Write-Output "  SFC scan complete" } }
 @{Id="dism_check";Cat="Windows Health";D=$true;L="Run DISM Health Check and Scan";Ds="Checks Windows component store (5-20 min)"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  Running DISM CheckHealth..."
   DISM /Online /Cleanup-Image /CheckHealth 2>&1|ForEach-Object{Write-Output "  $_"}
   Write-Output "  Running DISM ScanHealth..."
   DISM /Online /Cleanup-Image /ScanHealth 2>&1|ForEach-Object{Write-Output "  $_"} } }
 @{Id="wu_history";Cat="Windows Health";D=$false;L="Windows Update History Report";Ds="Last 20 installed Windows updates with dates"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === LAST 20 WINDOWS UPDATES ==="
   Get-HotFix -EA SilentlyContinue|Sort-Object InstalledOn -Desc|Select-Object -First 20|ForEach-Object{
     $d=if($_.InstalledOn){$_.InstalledOn.ToString("yyyy-MM-dd")}else{"Unknown    "}
     Write-Output "  $d  $($_.HotFixID.PadRight(15)) $($_.Description)"} } }
 @{Id="recent_errors";Cat="Windows Health";D=$false;L="Recent System and App Errors (Last 24h)";Ds="Error/warning events from System and Application logs"
   Cmd={$ProgressPreference="SilentlyContinue";$since=(Get-Date).AddHours(-24)
   Write-Output "  === SYSTEM ERRORS/WARNINGS ==="
   $e=Get-EventLog -LogName System -EntryType Error,Warning -After $since -Newest 15 -EA SilentlyContinue
   if($e){$e|ForEach-Object{Write-Output "  [$($_.TimeGenerated.ToString("HH:mm"))] [$($_.EntryType)] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"}}
   else{Write-Output "  No System errors in last 24h"}
   Write-Output ""
   Write-Output "  === APP ERRORS ==="
   $a=Get-EventLog -LogName Application -EntryType Error -After $since -Newest 15 -EA SilentlyContinue
   if($a){$a|ForEach-Object{Write-Output "  [$($_.TimeGenerated.ToString("HH:mm"))] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"}}
   else{Write-Output "  No App errors in last 24h"} } }
 @{Id="installed_sw";Cat="Windows Health";D=$false;L="Installed Software Inventory";Ds="All installed apps with version and install date"
   Cmd={$ProgressPreference="SilentlyContinue"
   $reg=@("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")
   $apps=$reg|ForEach-Object{Get-ItemProperty $_ -EA SilentlyContinue}|Where-Object{$_.DisplayName}|Sort-Object DisplayName
   Write-Output "  Total: $($apps.Count) applications"
   $apps|ForEach-Object{$v=if($_.DisplayVersion){$_.DisplayVersion}else{"--"}
     $d=if($_.InstallDate){$_.InstallDate}else{"Unknown"}
     Write-Output "  $($_.DisplayName.PadRight(50)) $($v.PadRight(16)) $d"} } }
 @{Id="net_ip";Cat="Network";D=$false;L="Network Adapter and IP Configuration";Ds="IP, gateway, DNS for all active adapters"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === NETWORK ADAPTERS ==="
   $cfgs=Get-NetIPConfiguration -EA SilentlyContinue|Where-Object{$_.IPv4Address}
   if(-not $cfgs){Write-Output "  No active IPv4 adapters";return}
   foreach($c2 in $cfgs){$dns=($c2.DNSServer|Where-Object{$_.AddressFamily -eq 2}|Select-Object -ExpandProperty ServerAddresses) -join ", "
     $mac=(Get-NetAdapter -Name $c2.InterfaceAlias -EA SilentlyContinue).MacAddress
     Write-Output "  Adapter: $($c2.InterfaceAlias)"
     Write-Output "  IPv4   : $($c2.IPv4Address.IPAddress)  GW: $($c2.IPv4DefaultGateway.NextHop)"
     Write-Output "  DNS    : $dns  MAC: $mac"
     Write-Output "  ----------------------------------------------"} } }
 @{Id="net_ping";Cat="Network";D=$false;L="Test Network Connectivity (Ping Suite)";Ds="Pings gateway, DNS servers, Google, Microsoft, WU"
   Cmd={$ProgressPreference="SilentlyContinue"
   $gw=(Get-NetIPConfiguration -EA SilentlyContinue|Where-Object{$_.IPv4DefaultGateway}|Select-Object -First 1).IPv4DefaultGateway.NextHop
   $tgt=[ordered]@{"Default Gateway"=$gw;"Google DNS"="8.8.8.8";"Cloudflare"="1.1.1.1";"Google.com"="google.com";"Microsoft.com"="microsoft.com";"Windows Update"="windowsupdate.microsoft.com"}
   Write-Output "  Target                    Address                  Status    Latency"
   foreach($t in $tgt.GetEnumerator()){if(-not $t.Value){continue}
     $r=Test-NetConnection -ComputerName $t.Value -WarningAction SilentlyContinue -EA SilentlyContinue
     $ok=if($r.PingSucceeded){"PASS"}else{"FAIL"}
     $ms=if($r.PingReplyDetails){"$($r.PingReplyDetails.RoundtripTime) ms"}else{"--"}
     Write-Output "  $($t.Key.PadRight(26)) $($t.Value.PadRight(25)) $ok   $ms"} } }
 @{Id="net_stats";Cat="Network";D=$false;L="Network Adapter Speed and Traffic Stats";Ds="Link speed, status and sent/received counters"
   Cmd={$ProgressPreference="SilentlyContinue"
   $ada=Get-NetAdapter -EA SilentlyContinue|Where-Object{$_.Status -eq "Up"}
   if(-not $ada){Write-Output "  No active adapters";return}
   foreach($a in $ada){$st=$a|Get-NetAdapterStatistics -EA SilentlyContinue
     $sp=if($a.LinkSpeed){"$([math]::Round($a.LinkSpeed/1MB,0)) Mbps"}else{"Unknown"}
     Write-Output "  $($a.Name)  Speed: $sp  MAC: $($a.MacAddress)"
     if($st){Write-Output "  Sent: $([math]::Round($st.SentBytes/1MB,2)) MB  Recv: $([math]::Round($st.ReceivedBytes/1MB,2)) MB"}
     Write-Output "  ----------------------------------------------"} } }
 @{Id="net_reset";Cat="Network";D=$true;L="Reset TCP/IP and Winsock Stack";Ds="REBOOT REQUIRED -- resets network stack -- will disconnect"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  WARNING: REBOOT REQUIRED -- network WILL be interrupted"
   netsh winsock reset 2>&1|Out-Null;Write-Output "  Winsock reset done"
   netsh int ip reset 2>&1|Out-Null;netsh int ipv6 reset 2>&1|Out-Null;Write-Output "  TCP/IP reset done"
   ipconfig /flushdns 2>&1|Out-Null;ipconfig /registerdns 2>&1|Out-Null
   ipconfig /release 2>&1|Out-Null;Start-Sleep 2;ipconfig /renew 2>&1|Out-Null
   Write-Output "  Network stack reset complete -- REBOOT REQUIRED" } }
 @{Id="dns_latency";Cat="Network";D=$false;L="DNS Resolution and Latency Test";Ds="DNS lookup time for 5 major domains"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  Domain                        IP                   Latency"
   foreach($d in @("google.com","microsoft.com","amazon.com","github.com","youtube.com")){
     $t=Measure-Command{$ip=(Resolve-DnsName $d -EA SilentlyContinue|Select-Object -First 1).IPAddress}
     Write-Output "  $($d.PadRight(30)) $($ip.PadRight(21)) $([math]::Round($t.TotalMilliseconds,1)) ms"} } }
 @{Id="firewall_status";Cat="Network";D=$false;L="Firewall and Security Status Report";Ds="Firewall profiles, AV products, listening ports"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  === WINDOWS FIREWALL ==="
   Get-NetFirewallProfile -EA SilentlyContinue|ForEach-Object{
     Write-Output "  $($_.Name): Enabled=$($_.Enabled) In=$($_.DefaultInboundAction) Out=$($_.DefaultOutboundAction)"}
   Write-Output ""
   Write-Output "  === ANTIVIRUS ==="
   $av=Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -EA SilentlyContinue
   if($av){$av|ForEach-Object{Write-Output "  $($_.displayName)"}}else{Write-Output "  None in SecurityCenter2"}
   Write-Output ""
   Write-Output "  === TOP LISTENING PORTS ==="
   netstat -an 2>$null|Select-String "LISTENING"|Select-Object -First 15|ForEach-Object{Write-Output "  $_"} } }
 @{Id="active_conn";Cat="Network";D=$false;L="Active Network Connections Report";Ds="Active TCP connections with owning process names"
   Cmd={$ProgressPreference="SilentlyContinue"
   Write-Output "  Process                    Local                      Remote                     State"
   Get-NetTCPConnection -EA SilentlyContinue|
     Where-Object{$_.State -ne "Listen" -and $_.RemoteAddress -ne "0.0.0.0" -and $_.RemoteAddress -ne "::"}|
     Select-Object -First 25|ForEach-Object{
       $proc=(Get-Process -Id $_.OwningProcess -EA SilentlyContinue).Name
       if(-not $proc){$proc="PID:$($_.OwningProcess)"}
       Write-Output "  $($proc.PadRight(27)) $("$($_.LocalAddress):$($_.LocalPort)".PadRight(27)) $("$($_.RemoteAddress):$($_.RemotePort)".PadRight(27)) $($_.State)"} } }
)

# ============================================================
# HELPER FUNCTIONS
# ============================================================
$Script:RtbLog=$null
function LogIt([string]$t,[string]$tag="out") {
    if(-not $Script:RtbLog){return}
    $col=switch($tag){"hdr"{$CYAN}"ok"{$GRN}"warn"{$YEL}"err"{$RED}"dim"{$DIM}"task"{$TXTB}"info"{$TXDD}default{$OUT2}}
    $Script:RtbLog.SelectionStart=$Script:RtbLog.TextLength
    $Script:RtbLog.SelectionLength=0
    $Script:RtbLog.SelectionColor=$col
    $Script:RtbLog.AppendText($t+"`r`n")
    $Script:RtbLog.ScrollToCaret()
    if($Script:LogFile){Add-Content -Path $Script:LogFile -Value $t -Encoding UTF8 -EA SilentlyContinue}
}
function ConnStat([string]$t,[System.Drawing.Color]$c) {
    if($Script:LblConn){$Script:LblConn.Text=" $t";$Script:LblConn.ForeColor=$c}
}
function GetSel { $Ops|Where-Object{$CbMap.ContainsKey($_.Id) -and $CbMap[$_.Id].Checked} }
function UpdCount {
    $n=(GetSel).Count
    $nd=($Ops|Where-Object{$DANGER -contains $_.Id -and $CbMap.ContainsKey($_.Id) -and $CbMap[$_.Id].Checked}).Count
    $cntTxt="$n task(s) selected"
    if($nd){$cntTxt="$n task(s) selected  |  ! $nd sensitive"}
    $Script:LblCnt.Text=$cntTxt
}

# ============================================================
# FORM
# ============================================================
$F=New-Object System.Windows.Forms.Form
$F.Text="PC Admin & Performance Tool  v2.7  --  (c) 2024-2026 Abdullah"
$F.ClientSize=New-Object System.Drawing.Size(1380,860)
$F.MinimumSize=New-Object System.Drawing.Size(1100,680)
$F.BackColor=$BG;$F.StartPosition="CenterScreen"
try{$F.Icon=[System.Drawing.Icon]::ExtractAssociatedIcon([System.Windows.Forms.Application]::ExecutablePath)}catch{}

# HEADER 52px
$PH=New-Object System.Windows.Forms.Panel;$PH.Dock="Top";$PH.Height=52;$PH.BackColor=$HDRB
$lTi=New-Object System.Windows.Forms.Label
$lTi.Text="   PC ADMIN  PERFORMANCE TROUBLESHOOTING TOOL"
$lTi.Font=GF "Segoe UI" 13 -B;$lTi.ForeColor=$TXTB;$lTi.TextAlign="MiddleLeft";$lTi.Dock="Fill"
$PH.Controls.Add($lTi)
$pV=New-Object System.Windows.Forms.Panel;$pV.Width=480;$pV.Dock="Right";$pV.BackColor=$HDRB
$lV1=New-Object System.Windows.Forms.Label;$lV1.Text=$VER
$lV1.Font=GF "Segoe UI" 9 -B;$lV1.ForeColor=$CYAN;$lV1.TextAlign="TopRight"
$lV1.SetBounds(0,8,478,20);$pV.Controls.Add($lV1)
$lV2=New-Object System.Windows.Forms.Label;$lV2.Text="(c) 2024-2026 Abdullah  |  abuabdullah.be@outlook.com"
$lV2.Font=GF "Segoe UI" 8;$lV2.ForeColor=$TXDD;$lV2.TextAlign="TopRight"
$lV2.SetBounds(0,28,478,18);$pV.Controls.Add($lV2)
$PH.Controls.Add($pV)
$F.Controls.Add($PH)

# TABS 40px
$PT=New-Object System.Windows.Forms.Panel;$PT.Dock="Top";$PT.Height=40;$PT.BackColor=$PNL
$lFl=New-Object System.Windows.Forms.Label;$lFl.Text="  FILTER:"
$lFl.Font=GF "Segoe UI" 8 -B;$lFl.ForeColor=$TXDD;$lFl.TextAlign="MiddleLeft"
$lFl.SetBounds(0,0,66,40);$PT.Controls.Add($lFl)
$Script:TabBtns=@{};$tx=68
foreach($td in @(
  @{L="All";K="all";Col=$GRN},@{L="Clear";K="_c";Col=$RED},@{L="Select All";K="_a";Col=$GRN},
  @{L="|";K=""},
  @{L="Cleanup";K="Cleanup";Col=$CYAN},@{L="Disk";K="Disk";Col=$CYAN},
  @{L="Performance";K="Performance";Col=$CYAN},@{L="Windows Health";K="Windows Health";Col=$CYAN},
  @{L="Network";K="Network";Col=$CYAN})){
    if($td.K -eq ""){$sep=New-Object System.Windows.Forms.Label;$sep.SetBounds($tx,8,2,24);$sep.BackColor=$BDR2;$PT.Controls.Add($sep);$tx+=8;continue}
    $tb=New-Object System.Windows.Forms.Button;$tb.Text=$td.L;$tb.Tag=$td.K;$tb.AutoSize=$true
    $tb.Left=$tx;$tb.Top=6;$tb.Height=28;$tb.FlatStyle="Flat"
    $tb.FlatAppearance.BorderSize=1;$tb.FlatAppearance.BorderColor=$BDR
    $tb.BackColor=$CARD;$tb.ForeColor=$TXDD;$tb.Font=GF "Segoe UI" 9 -B
    $tb.Cursor=[System.Windows.Forms.Cursors]::Hand;$tb.Padding=New-Object System.Windows.Forms.Padding(8,0,8,0)
    $tb.Add_Click({TabClk $this.Tag});$PT.Controls.Add($tb)
    if($td.K -notin @("_c","_a")){$Script:TabBtns[$td.K]=@{B=$tb;Col=$td.Col}}
    $tx+=$tb.PreferredSize.Width+4
}
$F.Controls.Add($PT)

# FOOTER 22px
$PF=New-Object System.Windows.Forms.Panel;$PF.Dock="Bottom";$PF.Height=22;$PF.BackColor=HC "#06111e"
$lFo=New-Object System.Windows.Forms.Label;$lFo.Text="  $COPYL"
$lFo.Font=GF "Segoe UI" 8;$lFo.ForeColor=HC "#253d57";$lFo.TextAlign="MiddleLeft";$lFo.Dock="Fill"
$PF.Controls.Add($lFo);$F.Controls.Add($PF)

# ACTION BAR 60px
$PA=New-Object System.Windows.Forms.Panel;$PA.Dock="Bottom";$PA.Height=60;$PA.BackColor=$PNL
$BtnRun=New-Object System.Windows.Forms.Button;$BtnRun.Text="  PERFORM SELECTED  "
$BtnRun.SetBounds(8,9,210,42);$BtnRun.BackColor=HC "#15803d";$BtnRun.ForeColor=[System.Drawing.Color]::White
$BtnRun.FlatStyle="Flat";$BtnRun.FlatAppearance.BorderSize=0;$BtnRun.Font=GF "Segoe UI" 11 -B
$BtnRun.Cursor=[System.Windows.Forms.Cursors]::Hand;$PA.Controls.Add($BtnRun)
$BtnStop=New-Object System.Windows.Forms.Button;$BtnStop.Text="  STOP  "
$BtnStop.SetBounds(226,9,96,42);$BtnStop.BackColor=HC "#991b1b";$BtnStop.ForeColor=[System.Drawing.Color]::White
$BtnStop.FlatStyle="Flat";$BtnStop.FlatAppearance.BorderSize=0;$BtnStop.Font=GF "Segoe UI" 11 -B
$BtnStop.Enabled=$false;$BtnStop.Cursor=[System.Windows.Forms.Cursors]::Hand;$PA.Controls.Add($BtnStop)
$BtnClr=New-Object System.Windows.Forms.Button;$BtnClr.Text="Clear Log"
$BtnClr.SetBounds(330,9,86,42);$BtnClr.BackColor=$CRD2;$BtnClr.ForeColor=$TXDD
$BtnClr.FlatStyle="Flat";$BtnClr.FlatAppearance.BorderSize=0;$BtnClr.Font=GF "Segoe UI" 9
$BtnClr.Cursor=[System.Windows.Forms.Cursors]::Hand;$PA.Controls.Add($BtnClr)
$PrgBar=New-Object System.Windows.Forms.ProgressBar
$PrgBar.SetBounds(424,20,200,20);$PrgBar.Style="Continuous";$PA.Controls.Add($PrgBar)
$Script:LblStat=New-Object System.Windows.Forms.Label
$Script:LblStat.Text="Ready -- select tasks and click PERFORM SELECTED"
$Script:LblStat.SetBounds(632,9,450,42);$Script:LblStat.ForeColor=$TXDD;$Script:LblStat.Font=GF "Segoe UI" 9
$Script:LblStat.TextAlign="MiddleLeft";$Script:LblStat.BackColor=[System.Drawing.Color]::Transparent
$PA.Controls.Add($Script:LblStat)
$Script:LblCnt=New-Object System.Windows.Forms.Label;$Script:LblCnt.Text="0 tasks selected"
$Script:LblCnt.Top=9;$Script:LblCnt.Width=200;$Script:LblCnt.Height=42
$Script:LblCnt.ForeColor=$TXDD;$Script:LblCnt.Font=GF "Segoe UI" 9;$Script:LblCnt.TextAlign="MiddleRight"
$Script:LblCnt.Anchor=[System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
$PA.Controls.Add($Script:LblCnt)
$BtnLogs=New-Object System.Windows.Forms.Button;$BtnLogs.Text="Open Logs"
$BtnLogs.Top=9;$BtnLogs.Width=96;$BtnLogs.Height=42
$BtnLogs.BackColor=$CRD2;$BtnLogs.ForeColor=$TXDD;$BtnLogs.FlatStyle="Flat";$BtnLogs.FlatAppearance.BorderSize=0
$BtnLogs.Font=GF "Segoe UI" 9;$BtnLogs.Cursor=[System.Windows.Forms.Cursors]::Hand
$BtnLogs.Anchor=[System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
$PA.Controls.Add($BtnLogs)
$F.Controls.Add($PA)

# MAIN FILL
$PM=New-Object System.Windows.Forms.Panel;$PM.Dock="Fill";$PM.BackColor=$BG

# RIGHT: log panel (Dock=Right, 420px)
$PR=New-Object System.Windows.Forms.Panel;$PR.Dock="Right";$PR.Width=420;$PR.BackColor=$BG
$PRL=New-Object System.Windows.Forms.Panel;$PRL.Dock="Top";$PRL.Height=28;$PRL.BackColor=$PNL
$Script:LblDot=New-Object System.Windows.Forms.Label;$Script:LblDot.Text=" o"
$Script:LblDot.SetBounds(4,0,24,28);$Script:LblDot.ForeColor=$TXDD;$Script:LblDot.Font=GF "Segoe UI" 11;$Script:LblDot.TextAlign="MiddleLeft"
$PRL.Controls.Add($Script:LblDot)
$lLT=New-Object System.Windows.Forms.Label;$lLT.Text="LIVE OUTPUT  &  LOG"
$lLT.SetBounds(28,0,200,28);$lLT.ForeColor=$TXDD;$lLT.Font=GF "Segoe UI" 8 -B;$lLT.TextAlign="MiddleLeft"
$PRL.Controls.Add($lLT)
$Script:LblTask=New-Object System.Windows.Forms.Label;$Script:LblTask.Text=""
$Script:LblTask.SetBounds(200,0,210,28);$Script:LblTask.ForeColor=$CYAN;$Script:LblTask.Font=GF "Segoe UI" 8;$Script:LblTask.TextAlign="MiddleRight"
$PRL.Controls.Add($Script:LblTask)
$PR.Controls.Add($PRL)

# RICH TEXT BOX FOR LOGGING
$Script:RtbLog=New-Object System.Windows.Forms.RichTextBox;$Script:RtbLog.Dock="Fill"
$Script:RtbLog.BackColor=$LOGBG;$Script:RtbLog.ForeColor=$OUT2;$Script:RtbLog.Font=MF
$Script:RtbLog.BorderStyle="None";$Script:RtbLog.ReadOnly=$true
$PR.Controls.Add($Script:RtbLog)
$PM.Controls.Add($PR)

# DIVIDER 1px
$PD=New-Object System.Windows.Forms.Panel;$PD.Dock="Right";$PD.Width=1;$PD.BackColor=$BDR2
$PM.Controls.Add($PD)

# LEFT PANEL
$PL=New-Object System.Windows.Forms.Panel;$PL.Dock="Fill";$PL.BackColor=$BG

# -- CREDENTIALS PANEL --
$PC=New-Object System.Windows.Forms.Panel
$PC.Dock="Top";$PC.Height=134;$PC.BackColor=$CARD

# Header bar
$hdrBar=New-Object System.Windows.Forms.Label
$hdrBar.Text="  TARGET MACHINE  &  CREDENTIALS"
$hdrBar.SetBounds(0,0,1400,26)
$hdrBar.BackColor=HC "#0d1b2e";$hdrBar.ForeColor=$CYAN
$hdrBar.Font=GF "Segoe UI" 8 -B;$hdrBar.TextAlign="MiddleLeft"
$PC.Controls.Add($hdrBar)

# Row 1: Hostname / IP + Test Connection + Status  (y=35)
$l1a=New-Object System.Windows.Forms.Label;$l1a.Text="Hostname / IP :"
$l1a.SetBounds(8,35,112,24);$l1a.ForeColor=$TXTB;$l1a.BackColor=[System.Drawing.Color]::Transparent
$l1a.Font=GF "Segoe UI" 9;$l1a.TextAlign="MiddleLeft"
$PC.Controls.Add($l1a)

$Script:TxH=New-Object System.Windows.Forms.TextBox
$Script:TxH.SetBounds(124,33,224,28);$Script:TxH.BackColor=HC "#07111f";$Script:TxH.ForeColor=$TXTB
$Script:TxH.BorderStyle="FixedSingle";$Script:TxH.Font=GF "Consolas" 10
$PC.Controls.Add($Script:TxH)

$Script:BtnT=New-Object System.Windows.Forms.Button;$Script:BtnT.Text="  Test Connection  "
$Script:BtnT.SetBounds(356,32,172,30);$Script:BtnT.BackColor=$ACC;$Script:BtnT.ForeColor=$TXTB
$Script:BtnT.FlatStyle="Flat";$Script:BtnT.FlatAppearance.BorderSize=0;$Script:BtnT.Font=GF "Segoe UI" 9 -B
$Script:BtnT.Cursor=[System.Windows.Forms.Cursors]::Hand
$PC.Controls.Add($Script:BtnT)

$Script:LblConn=New-Object System.Windows.Forms.Label;$Script:LblConn.Text="  Not tested"
$Script:LblConn.SetBounds(536,35,430,24);$Script:LblConn.ForeColor=$TXDD
$Script:LblConn.BackColor=[System.Drawing.Color]::Transparent;$Script:LblConn.Font=GF "Segoe UI" 9;$Script:LblConn.TextAlign="MiddleLeft"
$PC.Controls.Add($Script:LblConn)

# Row 2: Username + Password + Show + Auth  (y=71)
$l2a=New-Object System.Windows.Forms.Label;$l2a.Text="Username :"
$l2a.SetBounds(8,71,82,24);$l2a.ForeColor=$TXTB;$l2a.BackColor=[System.Drawing.Color]::Transparent
$l2a.Font=GF "Segoe UI" 9;$l2a.TextAlign="MiddleLeft"
$PC.Controls.Add($l2a)

$Script:TxU=New-Object System.Windows.Forms.TextBox
$Script:TxU.SetBounds(92,69,244,28);$Script:TxU.BackColor=HC "#07111f";$Script:TxU.ForeColor=$TXTB
$Script:TxU.BorderStyle="FixedSingle";$Script:TxU.Font=GF "Consolas" 10
$PC.Controls.Add($Script:TxU)

$l2b=New-Object System.Windows.Forms.Label;$l2b.Text="Password :"
$l2b.SetBounds(346,71,80,24);$l2b.ForeColor=$TXTB;$l2b.BackColor=[System.Drawing.Color]::Transparent
$l2b.Font=GF "Segoe UI" 9;$l2b.TextAlign="MiddleLeft"
$PC.Controls.Add($l2b)

$Script:TxP=New-Object System.Windows.Forms.TextBox
$Script:TxP.SetBounds(428,69,162,28);$Script:TxP.BackColor=HC "#07111f";$Script:TxP.ForeColor=$TXTB
$Script:TxP.BorderStyle="FixedSingle";$Script:TxP.Font=GF "Consolas" 10;$Script:TxP.UseSystemPasswordChar=$true
$PC.Controls.Add($Script:TxP)

$Script:BtnE=New-Object System.Windows.Forms.Button;$Script:BtnE.Text="Show"
$Script:BtnE.SetBounds(598,68,54,30);$Script:BtnE.BackColor=$CRD2;$Script:BtnE.ForeColor=$TXDD
$Script:BtnE.FlatStyle="Flat";$Script:BtnE.FlatAppearance.BorderSize=0;$Script:BtnE.Font=GF "Segoe UI" 8
$Script:BtnE.Cursor=[System.Windows.Forms.Cursors]::Hand
$PC.Controls.Add($Script:BtnE)

$l2c=New-Object System.Windows.Forms.Label;$l2c.Text="Auth :"
$l2c.SetBounds(660,71,44,24);$l2c.ForeColor=$TXTB;$l2c.BackColor=[System.Drawing.Color]::Transparent
$l2c.Font=GF "Segoe UI" 9;$l2c.TextAlign="MiddleLeft"
$PC.Controls.Add($l2c)

$Script:CbA=New-Object System.Windows.Forms.ComboBox
$Script:CbA.SetBounds(706,69,258,28);$Script:CbA.DropDownStyle="DropDownList"
$Script:CbA.BackColor=HC "#07111f";$Script:CbA.ForeColor=$TXT;$Script:CbA.Font=GF "Segoe UI" 9
$TMAP.Keys|ForEach-Object{[void]$Script:CbA.Items.Add($_)};$Script:CbA.SelectedIndex=0
$PC.Controls.Add($Script:CbA)

# Hint row  (y=104)
$hintLbl=New-Object System.Windows.Forms.Label
$hintLbl.Text="  Username: DOMAIN\admin  or  admin@domain.local  |  NTLM=Domain  Basic=Workgroup  Kerberos=AD  CredSSP=Double-hop  |  WinRM: Enable-PSRemoting -Force"
$hintLbl.SetBounds(0,104,1400,24);$hintLbl.ForeColor=$TXDD;$hintLbl.Font=GF "Segoe UI" 8
$hintLbl.BackColor=[System.Drawing.Color]::Transparent;$hintLbl.TextAlign="MiddleLeft"
$PC.Controls.Add($hintLbl)

$PL.Controls.Add($PC)

# Task list header
$PTH=New-Object System.Windows.Forms.Panel;$PTH.Dock="Top";$PTH.Height=22;$PTH.BackColor=$BG
$lTH=New-Object System.Windows.Forms.Label
$lTH.Text=" TROUBLESHOOTING & PERFORMANCE OPTIONS  (36 operations)"
$lTH.Dock="Fill";$lTH.ForeColor=$TXDD;$lTH.Font=GF "Segoe UI" 8 -B;$lTH.TextAlign="MiddleLeft"
$PTH.Controls.Add($lTH);$PL.Controls.Add($PTH)

# Task scroll
$Script:TS=New-Object System.Windows.Forms.Panel;$Script:TS.Dock="Fill";$Script:TS.AutoScroll=$true;$Script:TS.BackColor=$CARD
$PL.Controls.Add($Script:TS)
$PM.Controls.Add($PL)
$F.Controls.Add($PM)

# ============================================================
# BUILD TASK LIST
# ============================================================
function BuildTasks([string]$Flt="all") {
    $Script:TS.SuspendLayout();$Script:TS.Controls.Clear();$CbMap.Clear()
    $Script:TS.AutoScrollPosition = New-Object System.Drawing.Point(0,0)
    $y=2;$curC=""
    foreach($op in $Ops){
        if($Flt -ne "all" -and $op.Cat -ne $Flt){continue}
        if($op.Cat -ne $curC){
            $curC=$op.Cat
            $ph=New-Object System.Windows.Forms.Panel
            $ph.Left=0;$ph.Top=$y;$ph.Width=2000;$ph.Height=26;$ph.BackColor=$PNL
            $lh2=New-Object System.Windows.Forms.Label;$lh2.Text="  [$curC]"
            $lh2.Dock="Fill";$lh2.ForeColor=$CYAN;$lh2.Font=GF "Segoe UI" 9 -B
            $lh2.TextAlign="MiddleLeft";$lh2.BackColor=$PNL
            $ph.Controls.Add($lh2);$Script:TS.Controls.Add($ph);$y+=28
        }
        $isDgr=$DANGER -contains $op.Id
        $pr=New-Object System.Windows.Forms.Panel
        $pr.Left=0;$pr.Top=$y;$pr.Width=2000;$pr.Height=28;$pr.BackColor=$CARD;$pr.Tag=$op.Id
        if($isDgr){$str=New-Object System.Windows.Forms.Panel;$str.Left=0;$str.Top=0;$str.Width=3;$str.Height=28;$str.BackColor=$YEL;$pr.Controls.Add($str)}
        $cb=New-Object System.Windows.Forms.CheckBox
        $cb.Left=8;$cb.Top=5;$cb.Width=20;$cb.Height=20;$cb.FlatStyle="Flat"
        $cb.FlatAppearance.BorderSize=2;$cb.FlatAppearance.BorderColor=[System.Drawing.Color]::White
        $cb.BackColor=$CARD;$cb.Tag=$op.Id;$cb.Add_CheckedChanged({UpdCount});$CbMap[$op.Id]=$cb
        $pr.Controls.Add($cb)
        $nc=if($isDgr){$YEL}else{$TXT};$pfx=if($isDgr){"! "}else{""}
        $ll=New-Object System.Windows.Forms.Label
        $ll.Text="$pfx$($op.L)   --   $($op.Ds)"
        $ll.Left=32;$ll.Top=5;$ll.Width=1900;$ll.Height=20
        $ll.ForeColor=$nc;$ll.Font=GF "Segoe UI" 9;$ll.BackColor=$CARD;$ll.Tag=$op.Id
        $ll.Cursor=[System.Windows.Forms.Cursors]::Hand
        $ll.Add_Click({$CbMap[$this.Tag].Checked=-not $CbMap[$this.Tag].Checked})
        $pr.Controls.Add($ll)
        $pr.Add_MouseEnter({$this.BackColor=$CRD2;foreach($ctrl in $this.Controls){if($ctrl -is [System.Windows.Forms.Label]){$ctrl.BackColor=$CRD2}}})
        $pr.Add_MouseLeave({$this.BackColor=$CARD; foreach($ctrl in $this.Controls){if($ctrl -is [System.Windows.Forms.Label]){$ctrl.BackColor=$CARD}}})
        $pr.Add_Click({$id=$this.Tag;if($CbMap.ContainsKey($id)){$CbMap[$id].Checked=-not $CbMap[$id].Checked}})
        $Script:TS.Controls.Add($pr);$y+=30
    }
    $Script:TS.ResumeLayout($true)
    $Script:TS.AutoScrollPosition = New-Object System.Drawing.Point(0,0)
    $Script:TS.VerticalScroll.Value = 0
}

# ============================================================
# TAB CLICK
# ============================================================
function TabClk([string]$k) {
    if($k -eq "_c"){$CbMap.Values|ForEach-Object{$_.Checked=$false};UpdCount;return}
    if($k -eq "_a"){$CbMap.Values|ForEach-Object{$_.Checked=$true};UpdCount;return}
    $Script:TabBtns.Keys|ForEach-Object{$b=$Script:TabBtns[$_].B
        if($_-eq$k){$b.BackColor=$CRD2;$b.ForeColor=$Script:TabBtns[$_].Col;$b.FlatAppearance.BorderColor=$BDR2}
        else{$b.BackColor=$CARD;$b.ForeColor=$TXDD;$b.FlatAppearance.BorderColor=$BDR}}
    BuildTasks $k
}

# ============================================================
# EVENTS
# ============================================================
$Script:BtnE.Add_Click({
    if($Script:TxP.UseSystemPasswordChar){$Script:TxP.UseSystemPasswordChar=$false;$Script:BtnE.Text="Hide"}
    else{$Script:TxP.UseSystemPasswordChar=$true;$Script:BtnE.Text="Show"}
})
$BtnClr.Add_Click({$Script:RtbLog.Clear();$PrgBar.Value=0;$Script:LblStat.Text="Log cleared"})
$BtnLogs.Add_Click({
    if(Test-Path $LOGD){Start-Process "explorer.exe" $LOGD}
    else{[System.Windows.Forms.MessageBox]::Show("No logs yet.","Logs")}
})
$F.Add_Resize({$w=$PA.Width
    if($w -gt 110){$BtnLogs.Left=$w-104;$Script:LblCnt.Left=[math]::Max(640,$w-312)}
})
$Script:TxH.Add_KeyDown({if($_.KeyCode -eq "Return"){$Script:BtnT.PerformClick()}})
$Script:TxP.Add_KeyDown({if($_.KeyCode -eq "Return"){$Script:BtnT.PerformClick()}})

# TEST CONNECTION
$Script:BtnT.Add_Click({
    $hn=$Script:TxH.Text.Trim();$un=$Script:TxU.Text.Trim()
    $pw=$Script:TxP.Text;$tr=$TMAP[$Script:CbA.SelectedItem]
    if(-not $hn){[System.Windows.Forms.MessageBox]::Show("Enter hostname or IP.","Input");return}
    if(-not $un){[System.Windows.Forms.MessageBox]::Show("Enter username.","Input");return}
    ConnStat "Testing..." $YEL;$Script:BtnT.Enabled=$false
    LogIt ("  "+"-"*44) "dim";LogIt "  Testing : $hn  [$tr]" "info";LogIt "  User    : $un" "info"
    if($Script:TestTimer){try{$Script:TestTimer.Stop()}catch{}}
    $Script:TestJob=[PowerShell]::Create()
    [void]$Script:TestJob.AddScript({param($h,$u,$p,$t,$sh2)
      try{$sec=ConvertTo-SecureString $p -AsPlainText -Force
        $cred=New-Object System.Management.Automation.PSCredential($u,$sec)
        $opts=New-PSSessionOption -OpenTimeout 15000 -OperationTimeout 14000
        $s=New-PSSession -ComputerName $h -Credential $cred -Authentication $t -SessionOption $opts -EA Stop
        $out=Invoke-Command -Session $s -ScriptBlock{"$env:COMPUTERNAME"} -EA Stop
        Remove-PSSession $s -EA SilentlyContinue
        $sh2.CR="ok";$sh2.CM="Connected to $h | Remote: $out | Auth: $t"
      }catch{$e=$_.Exception.Message
        if($e -match "credential|password|auth|logon"){$sh2.CR="cred";$sh2.CM=$e}
        elseif($e -match "5985|refused|connect|network"){$sh2.CR="winrm";$sh2.CM=$e}
        else{$sh2.CR="err";$sh2.CM=$e}}
    }).AddArgument($hn).AddArgument($un).AddArgument($pw).AddArgument($tr).AddArgument($SH)
    $SH.CR="";$SH.CM="";$Script:TestAr=$Script:TestJob.BeginInvoke()
    $Script:TestTimer=New-Object System.Windows.Forms.Timer;$Script:TestTimer.Interval=200
    $Script:TestTimer.Add_Tick({
        if($Script:TestJob.InvocationStateInfo.State -ne "Running"){
            $Script:TestTimer.Stop();$Script:BtnT.Enabled=$true
            switch($SH.CR){
                "ok"   {ConnStat "Connected OK" $GRN;LogIt "  Connected: $($SH.CM)" "ok"}
                "cred" {ConnStat "Auth Failed"  $RED;LogIt "  Auth FAILED: $($SH.CM)" "err";LogIt "  Try: DOMAIN\username  or  user@domain.local" "dim"}
                "winrm"{ConnStat "WinRM Failed" $RED;LogIt "  WinRM not reachable: $($SH.CM)" "err";LogIt "  Run on target: Enable-PSRemoting -Force" "dim"}
                default{ConnStat "Error"        $RED;LogIt "  Error: $($SH.CM)" "err"}}
            LogIt "" "dim";$Script:TestJob.Dispose()}
    });$Script:TestTimer.Start()
})

# STOP
$BtnStop.Add_Click({$SH.Stop=$true;LogIt "  ! STOP requested -- finishing current task..." "warn"})

# RUN TASKS
$BtnRun.Add_Click({
    $sel=GetSel
    if($sel.Count -eq 0){[System.Windows.Forms.MessageBox]::Show("Select at least one task.","No Tasks");return}
    $hn=$Script:TxH.Text.Trim();$un=$Script:TxU.Text.Trim();$pw=$Script:TxP.Text;$tr=$TMAP[$Script:CbA.SelectedItem]
    if(-not $hn){[System.Windows.Forms.MessageBox]::Show("Enter hostname or IP.","Input");return}
    if(-not $un){[System.Windows.Forms.MessageBox]::Show("Enter credentials.","Input");return}
    $dsel=$sel|Where-Object{$DANGER -contains $_.Id}
    if($dsel.Count -gt 0){
        $dn=($dsel|ForEach-Object{"  * $($_.L)"}) -join "`n"
        $ans=[System.Windows.Forms.MessageBox]::Show("WARNING: $($dsel.Count) sensitive op(s):`n`n$dn`n`nSome require reboots or may interrupt network.`n`nContinue?","Confirm","YesNo","Warning")
        if($ans -ne "Yes"){return}}
    $ts2=Get-Date -Format "yyyyMMdd_HHmmss";$shn=$hn -replace "[^\w\-\.]","_"
    $Script:LogFile=Join-Path $LOGD "AdminTool_${shn}_${ts2}.log"
    $SH.Stop=$false;$SH.Done=$false;$SH.Pv=0;$SH.Pm=$sel.Count
    $BtnRun.Enabled=$false;$BtnStop.Enabled=$true;try{$PrgBar.Value=0}catch{}
    $Script:LblDot.ForeColor=$GRN;$Script:LblStat.Text="Connecting..."
    $od=$sel|ForEach-Object{@{Id=$_.Id;L=$_.L;Cat=$_.Cat;Ds=$_.Ds;CT=$_.Cmd.ToString();D=$_.D}}
    $SH.OD=$od;$SH.HN=$hn;$SH.UN=$un;$SH.PW=$pw;$SH.TR=$tr;$SH.LF=$Script:LogFile;$SH.CP=$COPY
    $hdrs=@("="*55,"  PC ADMIN & PERFORMANCE TOOL  v2.7 -- PowerShell Edition","  $COPYL","="*55,
       "  Target   : $hn","  Username : $un  [$tr]","  Date/Time: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")",
       "  Tasks    : $($sel.Count) selected","  Log File : $(Split-Path $Script:LogFile -Leaf)","="*55,"")
    foreach($hline in $hdrs){
        $htag="dim"
        if($hline -match "^=+$" -or $hline -match "TOOL"){$htag="hdr"}
        elseif($hline -match "^  Target|Username|Date|Tasks|Log"){$htag="info"}
        $SH.Q.Enqueue(@{T=$hline;Tag=$htag})
    }
    $Script:BgRS=[runspacefactory]::CreateRunspace()
    $Script:BgRS.ApartmentState="STA";$Script:BgRS.ThreadOptions="ReuseThread";$Script:BgRS.Open()
    $Script:BgRS.SessionStateProxy.SetVariable("sh",$SH)
    $Script:BgPS=[PowerShell]::Create();$Script:BgPS.Runspace=$Script:BgRS
    [void]$Script:BgPS.AddScript({
        $h=$sh;$ProgressPreference="SilentlyContinue";$WarningPreference="SilentlyContinue"
        try{$sec=ConvertTo-SecureString $h.PW -AsPlainText -Force
          $cred=New-Object System.Management.Automation.PSCredential($h.UN,$sec)
          $opts=New-PSSessionOption -OperationTimeout 170000 -OpenTimeout 30000 -NoMachineProfile
          $sess=New-PSSession -ComputerName $h.HN -Credential $cred -Authentication $h.TR -SessionOption $opts -EA Stop
          $h.Q.Enqueue(@{T="  Session ready -- $($h.HN)";Tag="ok"});$h.Q.Enqueue(@{T="";Tag="dim"})
        }catch{$h.Q.Enqueue(@{T="  CONNECT FAILED: $($_.Exception.Message)";Tag="err"});$h.Done=$true;return}
        $tot=$h.OD.Count;$idx=0
        foreach($op in $h.OD){
            if($h.Stop){$h.Q.Enqueue(@{T="  ! STOPPED by user";Tag="warn"});break}
            $idx++;$h.Pv=$idx;$h.Stat="[$idx/$tot] $($op.L)"
            $h.Task="[$idx/$tot] $($op.L.Substring(0,[math]::Min(42,$op.L.Length)))"
            $tpfx=""
            if($op.D){$tpfx="! "}
            $h.Q.Enqueue(@{T=">> [$idx/$tot]  $tpfx$($op.L)";Tag="task"})
            $h.Q.Enqueue(@{T="    Category: $($op.Cat)  --  $($op.Ds)";Tag="dim"})
            $h.Q.Enqueue(@{T="    "+"-"*48;Tag="dim"})
            $t0=Get-Date
            try{
                $sb=[scriptblock]::Create('$ProgressPreference="SilentlyContinue"'+"`n"+'$WarningPreference="SilentlyContinue"'+"`n"+'$OutputEncoding=[Text.Encoding]::UTF8'+"`n"+$op.CT)
                $out=Invoke-Command -Session $sess -ScriptBlock $sb -EA Stop;$ok=$true
                if($out){foreach($line in $out){$l="$line".TrimEnd();if(-not $l){continue}
                    $lo=$l.ToLower()
                    $tag=if($lo -match "freed|cleared|complete|restarted|maintained|preserved|pass|ok"){"ok"}
                         elseif($lo -match "warn|skip|not found|already|reboot|interrupt|cannot"){"warn"}
                         elseif($lo -match "error|fail|denied|critical"){"err"}
                         else{"out"}
                    $h.Q.Enqueue(@{T="    $l";Tag=$tag})}}
                else{$h.Q.Enqueue(@{T="    ! No output -- check permissions or nothing to process";Tag="warn"})}
            }catch{
                $ok=$false;$em=$_.Exception.Message
                if($em -match "#< CLIXML|<Objs|<T>Completed"){$h.Q.Enqueue(@{T="    (non-critical PowerShell diagnostic output suppressed)";Tag="warn"})}
                elseif($em -match "AccessDenied|Access is denied"){$h.Q.Enqueue(@{T="    Access denied -- use Domain Admin account";Tag="err"})}
                elseif($em -match "timed out|timeout|cannot connect|RPC server|WinRM client"){
                    $h.Q.Enqueue(@{T="    Connection lost -- reconnecting...";Tag="warn"})
                    try{Remove-PSSession $sess -EA SilentlyContinue
                        $sess=New-PSSession -ComputerName $h.HN -Credential $cred -Authentication $h.TR -SessionOption $opts -EA Stop
                        $rt=Invoke-Command -Session $sess -ScriptBlock{"RECONNECTED"} -EA Stop
                        if($rt -eq "RECONNECTED"){$h.Q.Enqueue(@{T="    Session reconnected -- continuing";Tag="ok"})}
                    }catch{$h.Q.Enqueue(@{T="    Reconnect failed: $($_.Exception.Message)";Tag="err"})}}
                else{$h.Q.Enqueue(@{T="    Error: $em";Tag="err"})}
            }
            $el=[math]::Round(((Get-Date)-$t0).TotalSeconds,1)
            $doneTxt="Completed with errors";$doneTag="warn"
            if($ok){$doneTxt="Completed";$doneTag="ok"}
            $h.Q.Enqueue(@{T="    $doneTxt in ${el}s";Tag=$doneTag})
            $h.Q.Enqueue(@{T="";Tag="dim"})
        }
        Remove-PSSession $sess -EA SilentlyContinue
        $h.Q.Enqueue(@{T="="*55;Tag="hdr"})
        $finalTxt="ALL TASKS COMPLETED";$finalTag="ok"
        if($h.Stop){$finalTxt="STOPPED BY USER";$finalTag="warn"}
        $h.Q.Enqueue(@{T="  $finalTxt";Tag=$finalTag})
        $h.Q.Enqueue(@{T="  Finished : $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")";Tag="dim"})
        $h.Q.Enqueue(@{T="  Log: $(Split-Path $h.LF -Leaf)";Tag="dim"})
        $h.Q.Enqueue(@{T="  $($h.CP)";Tag="dim"});$h.Q.Enqueue(@{T="="*55;Tag="hdr"})
        $h.Done=$true
    })
    $Script:BgPS.BeginInvoke()|Out-Null
})

# UI POLL TIMER
$UT=New-Object System.Windows.Forms.Timer;$UT.Interval=80
$UT.Add_Tick({
    $item=$null
    while($SH.Q.TryDequeue([ref]$item)){LogIt $item.T $item.Tag}
    $pm=$SH.Pm;if($pm -lt 1){$pm=1}
    $pct=[math]::Min(100,[int](([math]::Min($SH.Pv,$pm)/$pm)*100))
    try{$PrgBar.Value=$pct}catch{}
    if($SH.Stat){$Script:LblStat.Text=$SH.Stat;$SH.Stat=""}
    if($SH.Task){$Script:LblTask.Text=$SH.Task;$SH.Task=""}
    if($SH.Done){
        $UT.Stop();$SH.Done=$false;try{$PrgBar.Value=100}catch{}
        $BtnRun.Enabled=$true;$BtnStop.Enabled=$false
        $Script:LblDot.ForeColor=$TXDD;$Script:LblTask.Text=""
        $Script:LblStat.Text=if($SH.Stop){"Stopped -- review log"}else{"All tasks completed -- log saved"}
        try{$Script:BgPS.Dispose()}catch{};try{$Script:BgRS.Close();$Script:BgRS.Dispose()}catch{}
        $Script:LogFile=$null}
})
$UT.Start()

# FORM SHOWN
$F.Add_Shown({
    $PH.SendToBack()
    $PT.SendToBack()
    $PF.SendToBack()
    $PA.SendToBack()
    $PM.BringToFront()

    $w=$PA.Width;$BtnLogs.Left=$w-104;$Script:LblCnt.Left=[math]::Max(640,$w-312)
    TabClk "all"
    LogIt "  PC Admin & Performance Tool  v2.7 -- PowerShell GUI Edition" "hdr"
    LogIt "  $COPY" "dim";LogIt ("  "+"-"*50) "dim"
    LogIt "  $($Ops.Count) operations ready across 5 categories" "info"
    LogIt "  Enter Hostname/IP -- Test Connection -- Select tasks -- Perform" "dim"
    LogIt "" "dim"
})

[System.Windows.Forms.Application]::Run($F)