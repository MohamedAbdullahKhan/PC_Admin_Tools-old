PC Admin & Performance Tool -- PowerShell GUI Edition  (v2.7)
================================================================

WHAT'S IN THIS FOLDER
  PCAdminTool.ps1      The complete tool (WinForms GUI, 36 operations).
  Run-AdminTool.bat     Double-click launcher. Requests Administrator
                         rights automatically, then opens the GUI.
  README.txt            This file.

REQUIREMENTS
  - Windows 7 SP1 or later (client running the tool)
  - PowerShell 5.0+ (built in to Windows 7 SP1+/8.1/10/11)
  - Zero external modules / zero installs -- uses only
    System.Windows.Forms and System.Drawing (built in to .NET)
  - WinRM enabled on TARGET machines you want to manage:
      Run on each target (as Admin):  Enable-PSRemoting -Force

HOW TO RUN
  1. Copy this whole folder to the admin workstation.
  2. Double-click Run-AdminTool.bat
  3. Approve the UAC prompt (the tool needs to run elevated so it
     can open outbound PSRemoting sessions with your credentials).
  4. In the GUI: enter target Hostname/IP, Username, Password,
     pick the Auth Transport, click Test Connection, select the
     tasks you want, click Perform / Run.

LOGS
  Every session writes a timestamped log to:
    PC_Admin_Logs\AdminTool_<hostname>_<timestamp>.log
  (created next to PCAdminTool.ps1)

NOTES
  - Operations marked with "!" are sensitive (may reboot the
    target, interrupt its network, or take many minutes). The
    tool shows a confirmation dialog listing them before running.
  - If Run-AdminTool.bat is blocked by SmartScreen ("Windows
    protected your PC"), click "More info" -> "Run anyway" (this
    is expected for unsigned scripts from outside the Store).

(c) 2024-2026 Abdullah | All Rights Reserved | abuabdullah.be@outlook.com
