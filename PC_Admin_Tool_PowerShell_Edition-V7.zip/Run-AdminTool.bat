@echo off
:: ============================================================
::  PC Admin & Performance Tool -- PowerShell GUI Edition
::  Self-elevating launcher -- double-click to run
::  (c) 2024-2026 Abdullah | All Rights Reserved
:: ============================================================
setlocal
cd /d "%~dp0"

:: Check for admin rights; if missing, relaunch elevated
net session >nul 2>&1
if %errorLevel% == 0 goto :run

echo Requesting Administrator privileges...
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:run
echo ============================================================
echo   PC Admin ^& Performance Tool -- PowerShell GUI Edition
echo   Launching (running as Administrator)...
echo ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0PCAdminTool.ps1"
exit /b
