#!/usr/bin/env python3
"""
================================================================================
  PC Admin & Performance Tool  v2.1  -- Native Python GUI Edition (Tkinter)
  (c) 2024-2026 Abdullah | All Rights Reserved
  Contact: abuabdullah.be@outlook.com
  Unauthorized copying, modification or redistribution is strictly prohibited.

  Operations ported directly from the Docker/Flask Web-Service edition
  (app.py) -- same 36 remote PowerShell operations, same PSRP execution
  model, packaged here as a single-file Tkinter desktop app (no browser,
  no Docker, no server -- just Python + pypsrp).
================================================================================
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pypsrp.client import Client
from pypsrp.exceptions import AuthenticationError, WinRMTransportError, WSManFaultError
import requests.exceptions
import threading
import queue
import socket
import datetime
import re
import os
import time
import sys
from pathlib import Path

VER = "v2.1  Native Python GUI Edition (Tkinter)"
COPYRIGHT = ("(c) 2024-2026 Abdullah | PC Admin & Performance Tool v2.1 | "
             "All Rights Reserved | abuabdullah.be@outlook.com")
COPYRIGHT_LONG = ("(c) 2024-2026 Abdullah | PC Admin & Performance Tool v2.1 | "
                   "Native Python GUI Edition | All Rights Reserved | "
                   "abuabdullah.be@outlook.com")

BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) \
    if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "PC_Admin_Logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════
#  DARK NAVY THEME  (matches the PowerShell GUI edition palette)
# ══════════════════════════════════════════════════════════════════════════
BG    = "#111827"
PNL   = "#1a2438"
CARD  = "#1f2e47"
CRD2  = "#263654"
BDR   = "#2e4368"
BDR2  = "#3a5580"
ACC   = "#1d4ed8"
CYAN  = "#22d3ee"
GRN   = "#22c55e"
RED   = "#ef4444"
YEL   = "#f59e0b"
TXT   = "#d1dff0"
TXTB  = "#eef2ff"
TXDD  = "#5c7a9a"
LOGBG = "#090f1a"
HDRB  = "#08111e"
DIM   = "#2d4a68"
OUT2  = "#8ab0cc"

# ══════════════════════════════════════════════════════════════════════════
#  OPERATIONS -- ported verbatim from app.py (Web-Service Edition, v2.0)
#  Same ids, same labels, same categories, same PowerShell command bodies.
# ══════════════════════════════════════════════════════════════════════════
OPERATIONS = [

    # ─── CLEANUP ────────────────────────────────────────────────────────
    {
        "id": "clear_user_temp",
        "label": "Clear All Users' Temp Files",
        "category": "Cleanup",
        "description": "Removes %TEMP% from every user profile, incl. SYSTEM/service accounts",
        "command": r"""
Write-Output "  Running as : $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Write-Output "  Computer   : $env:COMPUTERNAME"
$totalFreed = 0
$denied = 0
$profCount = 0
$users = Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue
if (-not $users) {
    Write-Output "  WARNING: C:\Users not found or not accessible"
} else {
    Write-Output "  Found $($users.Count) user profile folder(s) under C:\Users"
    foreach ($user in $users) {
        if ($user.Name -in @("Default","Default User","Public","All Users")) { continue }
        $profCount++
        $path = "$($user.FullName)\AppData\Local\Temp"
        if (Test-Path $path) {
            $items = Get-ChildItem $path -Recurse -Force -ErrorAction SilentlyContinue
            $sizeBefore = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
            if (-not $sizeBefore) { $sizeBefore = 0 }
            $before = $items.Count
            $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue -ErrorVariable delErrs
            $freed = [math]::Round($sizeBefore / 1MB, 2)
            $totalFreed += $freed
            if ($delErrs -and $delErrs.Count -gt 0) {
                $denied++
                Write-Output "  [$($user.Name)] Freed ${freed} MB  ($($delErrs.Count) file(s) skipped -- in use / access denied)"
            } else {
                Write-Output "  [$($user.Name)] Freed ${freed} MB  ($before items)"
            }
        } else {
            Write-Output "  [$($user.Name)] No temp folder (profile never fully loaded)"
        }
    }
}
$svcProfiles = @(
    @{Name="SYSTEM";         Path="C:\Windows\System32\config\systemprofile\AppData\Local\Temp"},
    @{Name="LocalService";   Path="C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"},
    @{Name="NetworkService"; Path="C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp"}
)
foreach ($sp in $svcProfiles) {
    if (Test-Path $sp.Path) {
        $items = Get-ChildItem $sp.Path -Recurse -Force -ErrorAction SilentlyContinue
        $sizeBefore = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if (-not $sizeBefore) { $sizeBefore = 0 }
        $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue -ErrorVariable svcErrs
        $freed = [math]::Round($sizeBefore / 1MB, 2)
        $totalFreed += $freed
        $note = if ($svcErrs -and $svcErrs.Count -gt 0) { " ($($svcErrs.Count) file(s) skipped -- in use)" } else { "" }
        Write-Output "  [$($sp.Name)] Freed ${freed} MB$note"
        $profCount++
    }
}
Write-Output "  ------------------------------------------------"
Write-Output "  Profiles processed: $profCount   |   TOTAL FREED: $totalFreed MB"
if ($denied -gt 0) { Write-Output "  NOTE: $denied profile(s) had files in use and were partially skipped (normal for the logged-in user's active session)" }
""",
        "danger": False,
    },
    {
        "id": "clear_windows_temp",
        "label": "Clear Windows System Temp (C:\\Windows\\Temp)",
        "category": "Cleanup",
        "description": "Deletes files in the Windows system temp directory",
        "command": r"""
$path = "C:\Windows\Temp"
if (-not (Test-Path $path)) { Write-Output "  Path not found: $path"; return }
$items  = Get-ChildItem $path -Recurse -ErrorAction SilentlyContinue
$count  = $items.Count
$size   = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
if (-not $size) { $size = 0 }
$items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "  Deleted $count items | Freed: $([math]::Round($size/1MB,2)) MB"
""",
        "danger": False,
    },
    {
        "id": "clear_prefetch",
        "label": "Clear Windows Prefetch Files",
        "category": "Cleanup",
        "description": "Removes .pf files from C:\\Windows\\Prefetch",
        "command": r"""
$path = "C:\Windows\Prefetch"
if (-not (Test-Path $path)) { Write-Output "  Prefetch folder not found"; return }
$files = Get-ChildItem $path -Filter "*.pf" -ErrorAction SilentlyContinue
$size  = ($files | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
if (-not $size) { $size = 0 }
$files | Remove-Item -Force -ErrorAction SilentlyContinue
Write-Output "  Removed $($files.Count) prefetch files | Freed: $([math]::Round($size/1MB,2)) MB"
""",
        "danger": False,
    },
    {
        "id": "clear_thumbnail_cache",
        "label": "Clear Thumbnail Cache (All Users)",
        "category": "Cleanup",
        "description": "Deletes thumbcache_*.db from all user Explorer profiles",
        "command": r"""
$totalFreed = 0
$users = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
if (-not $users) { Write-Output "  WARNING: Cannot enumerate C:\Users"; return }
foreach ($user in $users) {
    $path = "$($user.FullName)\AppData\Local\Microsoft\Windows\Explorer"
    if (Test-Path $path) {
        $files = Get-ChildItem $path -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue
        $size  = ($files | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if (-not $size) { $size = 0 }
        $files | Remove-Item -Force -ErrorAction SilentlyContinue
        $freed = [math]::Round($size/1MB,2)
        $totalFreed += $freed
        Write-Output "  [$($user.Name)] Removed $($files.Count) files | Freed: ${freed} MB"
    }
}
Write-Output "  Total thumbnail cache freed: $totalFreed MB"
""",
        "danger": False,
    },
    {
        "id": "clear_wu_cache",
        "label": "Clear Windows Update Download Cache",
        "category": "Cleanup",
        "description": "Stops WU/BITS, clears SoftwareDistribution\\Download, restarts services",
        "command": r"""
Write-Output "  Stopping Windows Update & BITS services..."
Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
Stop-Service bits     -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$path = "C:\Windows\SoftwareDistribution\Download"
if (Test-Path $path) {
    $size = (Get-ChildItem $path -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if (-not $size) { $size = 0 }
    Remove-Item "$path\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Output "  Cache cleared | Freed: $([math]::Round($size/1MB,2)) MB"
} else { Write-Output "  WU cache path not found" }
Start-Service wuauserv -ErrorAction SilentlyContinue
Start-Service bits     -ErrorAction SilentlyContinue
Write-Output "  Windows Update & BITS services restarted"
""",
        "danger": False,
    },
    {
        "id": "flush_dns",
        "label": "Flush DNS Resolver Cache",
        "category": "Cleanup",
        "description": "SAFE: Clears local DNS cache + /registerdns to preserve network connectivity",
        "command": r"""
Write-Output "  SAFE FLUSH -- local DNS cache only"
$before = @(Get-DnsClientCache -ErrorAction SilentlyContinue).Count
Write-Output "  Entries before : $before"
Clear-DnsClientCache -ErrorAction SilentlyContinue
ipconfig /flushdns 2>&1 | Out-Null
ipconfig /registerdns 2>&1 | Out-Null
$after = @(Get-DnsClientCache -ErrorAction SilentlyContinue).Count
Write-Output "  Entries after  : $after"
$gw = (Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4DefaultGateway} | Select-Object -First 1).IPv4DefaultGateway.NextHop
if ($gw) {
    $ping = Test-NetConnection -ComputerName $gw -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    $gwStatus = if ($ping.PingSucceeded) { "REACHABLE" } else { "check connectivity" }
    Write-Output "  Gateway $gw : $gwStatus"
}
Write-Output "  DNS flushed safely -- domain connectivity preserved"
""",
        "danger": True,
    },
    {
        "id": "clear_browser_cache",
        "label": "Clear Browser Caches (Chrome / Edge / Firefox)",
        "category": "Cleanup",
        "description": "Purges browser cache folders for all user profiles",
        "command": r"""
$totalFreed = 0
$browsers = @{
    "Google Chrome"  = "\AppData\Local\Google\Chrome\User Data\Default\Cache"
    "Microsoft Edge" = "\AppData\Local\Microsoft\Edge\User Data\Default\Cache"
}
$users = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
if (-not $users) { Write-Output "  WARNING: Cannot enumerate C:\Users"; return }
foreach ($user in $users) {
    foreach ($b in $browsers.GetEnumerator()) {
        $p = "$($user.FullName)$($b.Value)"
        if (Test-Path $p) {
            $size = (Get-ChildItem $p -Recurse -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            if (-not $size) { $size = 0 }
            Remove-Item "$p\*" -Recurse -Force -EA SilentlyContinue
            $freed = [math]::Round($size/1MB,2); $totalFreed += $freed
            Write-Output "  [$($user.Name)] $($b.Key): Freed ${freed} MB"
        }
    }
    # Firefox
    $ffBase = "$($user.FullName)\AppData\Local\Mozilla\Firefox\Profiles"
    if (Test-Path $ffBase) {
        Get-ChildItem $ffBase -Directory -EA SilentlyContinue | foreach {
            $cache = "$($_.FullName)\cache2"
            if (Test-Path $cache) {
                $size = (Get-ChildItem $cache -Recurse -EA SilentlyContinue | Measure-Object Length -Sum).Sum
                if (-not $size) { $size = 0 }
                Remove-Item "$cache\*" -Recurse -Force -EA SilentlyContinue
                $freed = [math]::Round($size/1MB,2); $totalFreed += $freed
                Write-Output "  [$($user.Name)] Firefox: Freed ${freed} MB"
            }
        }
    }
}
Write-Output "  TOTAL browser cache freed: $totalFreed MB"
""",
        "danger": False,
    },
    {
        "id": "clear_event_logs",
        "label": "Clear Windows Event Logs",
        "category": "Cleanup",
        "description": "Clears Application, System, and Setup logs; skips Security if >100k entries",
        "command": r"""
$logs = @("Application","System","Security","Setup")
foreach ($log in $logs) {
    try {
        $count = 0
        try { $li = Get-WinEvent -ListLog $log -ErrorAction SilentlyContinue; if ($li) { $count = $li.RecordCount } } catch {}
        if ($log -eq "Security" -and $count -gt 100000) {
            Write-Output "  SKIPPED: $log ($count entries) -- too large, would hang session"
            continue
        }
        wevtutil cl "$log" 2>$null
        Write-Output "  Cleared: $log ($count entries)"
    } catch { Write-Output "  Skipped: $log" }
}
""",
        "danger": False,
    },
    {
        "id": "empty_recycle_bin",
        "label": "Empty Recycle Bin (All Drives & Users)",
        "category": "Cleanup",
        "description": "Permanently empties the Recycle Bin on all drives",
        "command": r"""
try {
    $shell = New-Object -ComObject Shell.Application
    $rb = $shell.Namespace(0xA)
    $items = $rb.Items()
    $count = ($items | Measure-Object).Count
    Clear-RecycleBin -Force -ErrorAction Stop
    Write-Output "  Recycle Bin emptied: $count items removed"
} catch { Write-Output "  Recycle Bin already empty or access error: $_" }
""",
        "danger": True,
    },
    {
        "id": "disk_cleanup",
        "label": "Run Disk Cleanup Utility (cleanmgr)",
        "category": "Cleanup",
        "description": "Runs Windows built-in Disk Cleanup silently with all categories",
        "command": r"""
Write-Output "  Configuring Disk Cleanup categories..."
$regBase = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
$keys = Get-ChildItem $regBase -ErrorAction SilentlyContinue
$count = 0
foreach ($key in $keys) {
    Set-ItemProperty -Path $key.PSPath -Name StateFlags0099 -Value 2 -ErrorAction SilentlyContinue
    $count++
}
Write-Output "  Configured $count cleanup categories"
Write-Output "  Launching cleanmgr (max wait: 10 minutes)..."
$proc = Start-Process cleanmgr -ArgumentList "/sagerun:99" -WindowStyle Hidden -PassThru -ErrorAction SilentlyContinue
if ($proc) {
    $finished = $proc.WaitForExit(600000)
    if (-not $finished) {
        Write-Output "  WARNING: cleanmgr did not finish within 10 minutes. Remote/service"
        Write-Output "  sessions have no desktop, so cleanmgr can silently wait forever on a"
        Write-Output "  UI dialog nobody can see. Terminating it now."
        try { $proc.Kill() } catch {}
        Get-Process cleanmgr -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Output "  Disk Cleanup was terminated after timeout -- some categories may be incomplete"
    } else {
        Write-Output "  Disk Cleanup completed (exit code: $($proc.ExitCode))"
    }
} else {
    Write-Output "  Failed to launch cleanmgr"
}
""",
        "danger": True,
    },

    # ─── DISK ───────────────────────────────────────────────────────────
    {
        "id": "disk_space_report",
        "label": "Disk Space Report (All Drives)",
        "category": "Disk",
        "description": "Shows used/free space and health status for all fixed drives",
        "command": r"""
Write-Output "  Drive   FS         Total     Used      Free      Used%   Health"
Write-Output "  ──────────────────────────────────────────────────────────────────"
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter}
if (-not $vols) { Write-Output "  No fixed volumes found (may need admin rights)"; return }
foreach ($v in $vols) {
    $total = [math]::Round($v.Size/1GB,2)
    $free  = [math]::Round($v.SizeRemaining/1GB,2)
    $used  = [math]::Round($total - $free, 2)
    $pct   = if($total -gt 0) { "$([math]::Round(($used/$total)*100,1))%" } else { "N/A" }
    $warn  = if($total -gt 0 -and ($used/$total) -gt 0.9) { " ⚠CRITICAL" } elseif($total -gt 0 -and ($used/$total) -gt 0.8) { " ⚠LOW" } else { "" }
    Write-Output "  $($v.DriveLetter):      $($v.FileSystem.PadRight(10)) ${total} GB    ${used} GB    ${free} GB   $pct$warn   $($v.HealthStatus)"
}
""",
        "danger": False,
    },
    {
        "id": "defrag_drives",
        "label": "Optimize / Defragment All Fixed Drives",
        "category": "Disk",
        "description": "Defragments HDDs; runs TRIM on SSDs (auto-detects drive type)",
        "command": r"""
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter -and ($_.FileSystem -eq 'NTFS' -or $_.FileSystem -eq 'ReFS')}
if (-not $vols) { Write-Output "  No eligible NTFS/ReFS volumes found"; return }
foreach ($v in $vols) {
    $dl = $v.DriveLetter
    Write-Output "  Optimizing drive ${dl}: ($($v.FileSystem))..."
    $result = Optimize-Volume -DriveLetter $dl -Verbose 4>$null -ErrorAction SilentlyContinue
    Write-Output "  Drive ${dl}: optimization complete"
}
""",
        "danger": False,
    },
    {
        "id": "disk_health_scan",
        "label": "Scan Disk Health (Quick Scan — No Reboot)",
        "category": "Disk",
        "description": "Runs Repair-Volume scan on all drives without requiring a reboot",
        "command": r"""
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter}
if (-not $vols) { Write-Output "  No fixed volumes found"; return }
foreach ($v in $vols) {
    $dl = $v.DriveLetter
    Write-Output "  Scanning Drive ${dl}: ..."
    $result = Repair-Volume -DriveLetter $dl -Scan -ErrorAction SilentlyContinue
    Write-Output "  Drive ${dl}: Scan=$result | Health=$($v.HealthStatus) | FS=$($v.FileSystem)"
}
""",
        "danger": False,
    },
    {
        "id": "large_files_report",
        "label": "Find Top 20 Largest Files on C: Drive",
        "category": "Disk",
        "description": "Identifies the biggest disk space consumers on the C: drive",
        "command": r"""
Write-Output "  Scanning C: drive for large files (>100MB)..."
$files = Get-ChildItem "C:\" -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.Length -gt 100MB}
$sorted = $files | Sort-Object Length -Descending | Select-Object -First 20
Write-Output "  Size (GB)    Path"
Write-Output "  ─────────────────────────────────────────────────────────"
foreach ($f in $sorted) {
    $sz = [math]::Round($f.Length/1GB,3)
    Write-Output "  $($sz.ToString('F3')) GB   $($f.FullName)"
}
Write-Output "  Total large files found: $($files.Count)"
""",
        "danger": False,
    },

    # ─── PERFORMANCE ────────────────────────────────────────────────────
    {
        "id": "high_perf_power",
        "label": "Set High Performance Power Plan",
        "category": "Performance",
        "description": "Activates the built-in High Performance power scheme",
        "command": r"""
$guid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
$result = powercfg -setactive $guid 2>&1
$active  = powercfg -getactivescheme 2>&1
Write-Output "  Power plan set to: High Performance"
Write-Output "  Active: $active"
""",
        "danger": True,
    },
    {
        "id": "visual_effects_perf",
        "label": "Optimize Visual Effects for Performance",
        "category": "Performance",
        "description": "Sets Windows to Best Performance visual mode (disables animations)",
        "command": r"""
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
if (-not (Test-Path $regPath)) { New-Item $regPath -Force -ErrorAction SilentlyContinue | Out-Null }
Set-ItemProperty -Path $regPath -Name VisualFXSetting -Value 2 -ErrorAction SilentlyContinue
$dp = "HKCU:\Control Panel\Desktop"
Set-ItemProperty $dp -Name DragFullWindows -Value "0" -ErrorAction SilentlyContinue
Set-ItemProperty $dp -Name MenuShowDelay   -Value "0" -ErrorAction SilentlyContinue
$wm = "HKCU:\Control Panel\Desktop\WindowMetrics"
if (Test-Path $wm) { Set-ItemProperty $wm -Name MinAnimate -Value "0" -ErrorAction SilentlyContinue }
Write-Output "  Visual effects set to Best Performance"
Write-Output "  Animations & shadows disabled"
Write-Output "  Note: Re-login required for full effect"
""",
        "danger": False,
    },
    {
        "id": "optimize_ram",
        "label": "Optimize RAM / Force Garbage Collection",
        "category": "Performance",
        "description": "Reports RAM usage before and after forcing .NET GC collection",
        "command": r"""
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
if (-not $os) { Write-Output "  Cannot query WMI — insufficient rights"; return }
$totalGB  = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
$freeBefore = [math]::Round($os.FreePhysicalMemory/1MB,2)
$usedBefore = [math]::Round($totalGB - $freeBefore,2)
Write-Output "  RAM BEFORE — Total: ${totalGB} GB | Used: ${usedBefore} GB | Free: ${freeBefore} GB"
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()
[System.GC]::Collect()
$freeAfter = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,2)
$usedAfter = [math]::Round($totalGB - $freeAfter,2)
$recovered = [math]::Round($freeAfter - $freeBefore,2)
Write-Output "  RAM AFTER  — Total: ${totalGB} GB | Used: ${usedAfter} GB | Free: ${freeAfter} GB"
Write-Output "  Recovered : ${recovered} GB"
""",
        "danger": False,
    },
    {
        "id": "tune_sysmain",
        "label": "Auto-Tune SysMain / Superfetch (SSD Detection)",
        "category": "Performance",
        "description": "Disables SysMain on SSDs; keeps it active on HDDs",
        "command": r"""
$svc  = Get-Service -Name "SysMain" -ErrorAction SilentlyContinue
$ssds = Get-PhysicalDisk -ErrorAction SilentlyContinue | Where-Object {$_.MediaType -eq 'SSD'}
if ($ssds) {
    Write-Output "  SSD detected on this system"
    if ($svc -and $svc.Status -eq 'Running') {
        Stop-Service SysMain -Force -ErrorAction SilentlyContinue
        Set-Service  SysMain -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Output "  SysMain DISABLED (recommended for SSD performance)"
    } else { Write-Output "  SysMain already stopped/disabled" }
} else {
    Write-Output "  HDD-only system — SysMain kept ACTIVE"
    if ($svc -and $svc.Status -ne 'Running') {
        Start-Service SysMain -ErrorAction SilentlyContinue
        Set-Service   SysMain -StartupType Automatic -ErrorAction SilentlyContinue
        Write-Output "  SysMain re-enabled for HDD performance"
    }
}
""",
        "danger": False,
    },
    {
        "id": "restart_search",
        "label": "Restart & Reset Windows Search Indexer",
        "category": "Performance",
        "description": "Restarts WSearch service to free CPU/disk from heavy indexing",
        "command": r"""
$svc = Get-Service -Name "WSearch" -ErrorAction SilentlyContinue
if ($svc) {
    Stop-Service WSearch -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Start-Service WSearch -ErrorAction SilentlyContinue
    Write-Output "  Windows Search indexer restarted successfully"
} else { Write-Output "  Windows Search service not found" }
""",
        "danger": False,
    },
    {
        "id": "startup_report",
        "label": "Startup Programs & Services Report",
        "category": "Performance",
        "description": "Lists all auto-start programs from registry and scheduled tasks",
        "command": r"""
Write-Output "  === STARTUP REGISTRY ENTRIES ==="
$paths = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
)
foreach ($p in $paths) {
    if (Test-Path $p) {
        $branch = $p.Split('\')[-3]
        Get-ItemProperty $p -ErrorAction SilentlyContinue | ForEach-Object {
            $_.PSObject.Properties | Where-Object {$_.Name -notlike 'PS*'} | ForEach-Object {
                Write-Output "  [$branch] $($_.Name) = $($_.Value)"
            }
        }
    }
}
Write-Output ""
Write-Output "  === WIN32 STARTUP COMMANDS ==="
Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | foreach {
    Write-Output "  [$($_.User)] $($_.Name) — $($_.Command)"
}
Write-Output ""
Write-Output "  === ENABLED THIRD-PARTY SCHEDULED TASKS ==="
Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object {$_.State -eq 'Ready' -and $_.TaskPath -notlike '\Microsoft\*'} |
    Select-Object -First 15 | foreach { Write-Output "  $($_.TaskPath)$($_.TaskName)" }
""",
        "danger": False,
    },
    {
        "id": "pagefile_report",
        "label": "Virtual Memory / Page File Report",
        "category": "Performance",
        "description": "Shows current page file settings, usage and recommendations",
        "command": r"""
$sys = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
if (-not $sys) { Write-Output "  Cannot query WMI"; return }
$ramGB = [math]::Round($sys.TotalPhysicalMemory/1GB,2)
Write-Output "  RAM Installed     : ${ramGB} GB"
Write-Output "  Auto-Managed PF   : $($sys.AutomaticManagedPagefile)"
Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue | foreach {
    Write-Output "  Page File Path    : $($_.Name)"
    Write-Output "  Allocated Size    : $($_.AllocatedBaseSize) MB"
    Write-Output "  Current Usage     : $($_.CurrentUsage) MB"
    Write-Output "  Peak Usage        : $($_.PeakUsage) MB"
}
$recMin = [math]::Round($ramGB * 1024 * 1.5)
$recMax = [math]::Round($ramGB * 1024 * 3)
Write-Output "  Recommended Range : ${recMin} MB — ${recMax} MB (1.5x–3x RAM)"
""",
        "danger": False,
    },
    {
        "id": "non_essential_services",
        "label": "Non-Essential Running Services Report",
        "category": "Performance",
        "description": "Lists third-party services consuming CPU/memory resources",
        "command": r"""
Write-Output "  === THIRD-PARTY AUTO-START SERVICES ==="
$svcs = Get-WmiObject Win32_Service -ErrorAction SilentlyContinue |
    Where-Object { $_.State -eq 'Running' -and $_.StartMode -eq 'Auto' -and
        $_.PathName -notlike '*system32*' -and $_.PathName -notlike '*SysWOW64*' -and
        $_.PathName -notlike '*SystemRoot*' }
if ($svcs) {
    foreach ($s in $svcs) {
        $mem = "N/A"
        try { $proc = Get-Process -Id $s.ProcessId -EA SilentlyContinue
              if ($proc) { $mem = "$([math]::Round($proc.WorkingSet64/1MB,1)) MB" } } catch {}
        Write-Output "  $($s.Name.PadRight(40)) RAM: $mem"
    }
} else { Write-Output "  No non-system auto-start services found" }
""",
        "danger": False,
    },

    # ─── WINDOWS HEALTH ─────────────────────────────────────────────────
    {
        "id": "system_info",
        "label": "Full System Information Report",
        "category": "Windows Health",
        "description": "CPU, RAM, OS version, uptime, BIOS, and model info",
        "command": r"""
$cs  = Get-CimInstance Win32_ComputerSystem  -ErrorAction SilentlyContinue
$os  = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cpu = Get-CimInstance Win32_Processor       -ErrorAction SilentlyContinue | Select-Object -First 1
$bio = Get-CimInstance Win32_BIOS            -ErrorAction SilentlyContinue
if (-not $cs) { Write-Output "  Cannot query WMI — check permissions"; return }
$uptime = (Get-Date) - $os.LastBootUpTime
Write-Output "  Hostname     : $($cs.Name)"
Write-Output "  Manufacturer : $($cs.Manufacturer) $($cs.Model)"
Write-Output "  OS           : $($os.Caption) $($os.OSArchitecture)"
Write-Output "  OS Build     : $($os.Version) (Build $($os.BuildNumber))"
Write-Output "  CPU          : $($cpu.Name)"
Write-Output "  CPU Cores    : $($cpu.NumberOfCores) Physical / $($cpu.NumberOfLogicalProcessors) Logical"
Write-Output "  CPU Speed    : $($cpu.MaxClockSpeed) MHz"
Write-Output "  RAM Total    : $([math]::Round($cs.TotalPhysicalMemory/1GB,2)) GB"
if ($bio) { Write-Output "  BIOS         : $($bio.Manufacturer) v$($bio.SMBIOSBIOSVersion)" }
Write-Output "  Last Boot    : $($os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm:ss'))"
Write-Output "  Uptime       : $($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m $($uptime.Seconds)s"
Write-Output "  Domain       : $($cs.Domain)"
Write-Output "  Logged Users : $($cs.UserName)"
""",
        "danger": False,
    },
    {
        "id": "top_processes",
        "label": "Top CPU & RAM Consuming Processes",
        "category": "Windows Health",
        "description": "Lists top 10 processes by CPU time and working set memory",
        "command": r"""
Write-Output "  === TOP 10 PROCESSES BY CPU ==="
Write-Output "  Process Name                     CPU (s)      RAM (MB)"
Write-Output "  ──────────────────────────────────────────────────────────"
Get-Process -ErrorAction SilentlyContinue | Sort-Object CPU -Descending | Select-Object -First 10 | foreach {
    $cpu = if($_.CPU){ [math]::Round($_.CPU,1) } else { 0 }
    $ram = [math]::Round($_.WorkingSet64/1MB,1)
    Write-Output "  $($_.Name.PadRight(33)) $($cpu.ToString().PadLeft(8)) s   $($ram.ToString().PadLeft(8)) MB"
}
Write-Output ""
Write-Output "  === TOP 10 PROCESSES BY RAM ==="
Write-Output "  Process Name                     RAM (MB)     PID"
Write-Output "  ──────────────────────────────────────────────────────────"
Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 | foreach {
    $ram = [math]::Round($_.WorkingSet64/1MB,1)
    Write-Output "  $($_.Name.PadRight(33)) $($ram.ToString().PadLeft(8)) MB   PID:$($_.Id)"
}
""",
        "danger": False,
    },
    {
        "id": "run_sfc",
        "label": "Run SFC /scannow (System File Check)",
        "category": "Windows Health",
        "description": "Scans & repairs corrupted Windows system files (5-15 min)",
        "command": r"""
Write-Output "  Starting SFC scan — this may take several minutes..."
$result = sfc /scannow 2>&1
$result | foreach { Write-Output "  $_" }
Write-Output "  SFC scan complete"
""",
        "danger": True,
    },
    {
        "id": "run_dism",
        "label": "Run DISM Health Check & Scan",
        "category": "Windows Health",
        "description": "Checks and scans the Windows component store for corruption",
        "command": r"""
Write-Output "  Running DISM CheckHealth..."
DISM /Online /Cleanup-Image /CheckHealth 2>&1 | foreach { Write-Output "  $_" }
Write-Output ""
Write-Output "  Running DISM ScanHealth..."
DISM /Online /Cleanup-Image /ScanHealth 2>&1 | foreach { Write-Output "  $_" }
""",
        "danger": True,
    },
    {
        "id": "wu_history",
        "label": "Windows Update History Report",
        "category": "Windows Health",
        "description": "Shows last 20 installed Windows updates with install dates",
        "command": r"""
Write-Output "  === LAST 20 WINDOWS UPDATES INSTALLED ==="
Write-Output "  Date          HotFix ID       Description"
Write-Output "  ───────────────────────────────────────────────────────────"
Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 20 | foreach {
    $date = if($_.InstalledOn){ $_.InstalledOn.ToString('yyyy-MM-dd') } else { "Unknown    " }
    Write-Output "  $date      $($_.HotFixID.PadRight(15)) $($_.Description)"
}
""",
        "danger": False,
    },
    {
        "id": "recent_errors",
        "label": "Recent System & App Errors (Last 24h)",
        "category": "Windows Health",
        "description": "Pulls critical errors and warnings from System and Application logs",
        "command": r"""
$since = (Get-Date).AddHours(-24)
Write-Output "  === SYSTEM ERRORS/WARNINGS (last 24 hours) ==="
$sysEvts = Get-EventLog -LogName System -EntryType Error,Warning -After $since -Newest 15 -ErrorAction SilentlyContinue
if ($sysEvts) {
    $sysEvts | foreach {
        Write-Output "  [$($_.TimeGenerated.ToString('HH:mm'))] [$($_.EntryType)] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"
    }
} else { Write-Output "  No System errors in last 24 hours" }
Write-Output ""
Write-Output "  === APPLICATION ERRORS (last 24 hours) ==="
$appEvts = Get-EventLog -LogName Application -EntryType Error -After $since -Newest 15 -ErrorAction SilentlyContinue
if ($appEvts) {
    $appEvts | foreach {
        Write-Output "  [$($_.TimeGenerated.ToString('HH:mm'))] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"
    }
} else { Write-Output "  No Application errors in last 24 hours" }
""",
        "danger": False,
    },
    {
        "id": "installed_software",
        "label": "Installed Software Inventory",
        "category": "Windows Health",
        "description": "Lists all installed applications with version and install date",
        "command": r"""
Write-Output "  === INSTALLED APPLICATIONS ==="
$reg = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)
$apps = $reg | ForEach-Object { Get-ItemProperty $_ -ErrorAction SilentlyContinue } |
    Where-Object {$_.DisplayName} | Sort-Object DisplayName
Write-Output "  Total: $($apps.Count) applications"
Write-Output "  Application Name                                  Version          Installed"
Write-Output "  ─────────────────────────────────────────────────────────────────────────────"
$apps | foreach {
    $ver  = if($_.DisplayVersion){ $_.DisplayVersion } else { "—" }
    $date = if($_.InstallDate){ $_.InstallDate } else { "Unknown" }
    Write-Output "  $($_.DisplayName.PadRight(50)) $($ver.PadRight(16)) $date"
}
""",
        "danger": False,
    },

    # ─── NETWORK ────────────────────────────────────────────────────────
    {
        "id": "net_ip_config",
        "label": "Network Adapter & IP Configuration",
        "category": "Network",
        "description": "Displays IP, subnet, gateway, DNS for all active adapters",
        "command": r"""
Write-Output "  === NETWORK ADAPTERS ==="
$configs = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4Address}
if (-not $configs) { Write-Output "  No active IPv4 adapters found"; return }
foreach ($c in $configs) {
    $dns = ($c.DNSServer | Where-Object {$_.AddressFamily -eq 2} | Select-Object -ExpandProperty ServerAddresses) -join ', '
    $mac = (Get-NetAdapter -Name $c.InterfaceAlias -ErrorAction SilentlyContinue).MacAddress
    Write-Output "  Adapter      : $($c.InterfaceAlias)"
    Write-Output "  IPv4 Address : $($c.IPv4Address.IPAddress)"
    Write-Output "  Prefix Len   : /$($c.IPv4Address.PrefixLength)"
    Write-Output "  Default GW   : $($c.IPv4DefaultGateway.NextHop)"
    Write-Output "  DNS Servers  : $dns"
    Write-Output "  MAC Address  : $mac"
    Write-Output "  ──────────────────────────────────────────────"
}
""",
        "danger": False,
    },
    {
        "id": "net_connectivity",
        "label": "Test Network Connectivity (Ping Suite)",
        "category": "Network",
        "description": "Tests ping to gateway, DNS providers, Google, and Microsoft",
        "command": r"""
$gw = (Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4DefaultGateway} | Select-Object -First 1).IPv4DefaultGateway.NextHop
$targets = [ordered]@{
    "Default Gateway"        = $gw
    "Google Public DNS"      = "8.8.8.8"
    "Cloudflare DNS"         = "1.1.1.1"
    "Google.com"             = "google.com"
    "Microsoft.com"          = "microsoft.com"
    "Windows Update"         = "windowsupdate.microsoft.com"
}
Write-Output "  Target                      Address                   Status   Latency"
Write-Output "  ─────────────────────────────────────────────────────────────────────"
foreach ($t in $targets.GetEnumerator()) {
    if (-not $t.Value) { continue }
    $r = Test-NetConnection -ComputerName $t.Value -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    $ok      = if($r.PingSucceeded) { "✓ PASS" } else { "✗ FAIL" }
    $latency = if($r.PingReplyDetails) { "$($r.PingReplyDetails.RoundtripTime) ms" } else { "—" }
    Write-Output "  $($t.Key.PadRight(28)) $($t.Value.PadRight(26)) $ok   $latency"
}
""",
        "danger": False,
    },
    {
        "id": "net_adapter_stats",
        "label": "Network Adapter Speed & Traffic Stats",
        "category": "Network",
        "description": "Shows link speed, status, and byte counters for active adapters",
        "command": r"""
$adapters = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Up'}
if (-not $adapters) { Write-Output "  No active adapters found"; return }
foreach ($a in $adapters) {
    $stats = $a | Get-NetAdapterStatistics -ErrorAction SilentlyContinue
    $speed = if($a.LinkSpeed) { "$([math]::Round($a.LinkSpeed/1MB,0)) Mbps" } else { "Unknown" }
    Write-Output "  Adapter  : $($a.Name) — $($a.InterfaceDescription)"
    Write-Output "  Status   : $($a.Status)  |  Speed: $speed  |  MAC: $($a.MacAddress)"
    if ($stats) {
        Write-Output "  Sent     : $([math]::Round($stats.SentBytes/1MB,2)) MB ($($stats.SentUnicastPackets) pkts)"
        Write-Output "  Received : $([math]::Round($stats.ReceivedBytes/1MB,2)) MB ($($stats.ReceivedUnicastPackets) pkts)"
    }
    Write-Output "  ──────────────────────────────────────────────────────────"
}
""",
        "danger": False,
    },
    {
        "id": "reset_network",
        "label": "Reset TCP/IP & Winsock Stack",
        "category": "Network",
        "description": "Resets Winsock, TCP/IP stack, flushes DNS, renews IP lease",
        "command": r"""
Write-Output "  Resetting Winsock catalog..."
netsh winsock reset 2>&1 | Out-Null
Write-Output "  Winsock reset complete"
Write-Output "  Resetting TCP/IP stack (IPv4 & IPv6)..."
netsh int ip   reset 2>&1 | Out-Null
netsh int ipv6 reset 2>&1 | Out-Null
Write-Output "  TCP/IP stack reset complete"
Write-Output "  Flushing DNS resolver cache..."
ipconfig /flushdns 2>&1 | Out-Null
ipconfig /registerdns 2>&1 | Out-Null
Write-Output "  Releasing IP address..."
ipconfig /release 2>&1 | Out-Null
Start-Sleep -Seconds 2
Write-Output "  Renewing IP address..."
ipconfig /renew 2>&1 | Out-Null
Write-Output "  Network stack reset complete"
Write-Output "  NOTE: A REBOOT is recommended to fully apply Winsock/TCP-IP changes"
""",
        "danger": True,
    },
    {
        "id": "dns_test",
        "label": "DNS Resolution & Latency Test",
        "category": "Network",
        "description": "Tests DNS lookup speed for multiple domains",
        "command": r"""
$domains = @("google.com","microsoft.com","amazon.com","github.com","youtube.com")
Write-Output "  === DNS RESOLUTION LATENCY TEST ==="
Write-Output "  Domain                        IP Address         Latency"
Write-Output "  ──────────────────────────────────────────────────────────"
foreach ($d in $domains) {
    $t  = Measure-Command { $ip = (Resolve-DnsName $d -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress }
    $ms = [math]::Round($t.TotalMilliseconds,1)
    Write-Output "  $($d.PadRight(30)) $($ip.PadRight(19)) ${ms} ms"
}
""",
        "danger": False,
    },
    {
        "id": "firewall_status",
        "label": "Firewall & Security Status Report",
        "category": "Network",
        "description": "Reports Windows Firewall profiles, AV products, and listening ports",
        "command": r"""
Write-Output "  === WINDOWS FIREWALL PROFILES ==="
Get-NetFirewallProfile -ErrorAction SilentlyContinue | foreach {
    Write-Output "  $($_.Name.PadRight(14)): Enabled=$($_.Enabled)  Inbound=$($_.DefaultInboundAction)  Outbound=$($_.DefaultOutboundAction)"
}
Write-Output ""
Write-Output "  === ANTIVIRUS / SECURITY PRODUCTS ==="
$av = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
if ($av) { $av | foreach { Write-Output "  AV: $($_.displayName) | State: $($_.productState)" } }
else { Write-Output "  None registered (may be server OS or WMI namespace unavailable)" }
Write-Output ""
Write-Output "  === TOP LISTENING PORTS (TCP) ==="
netstat -an 2>$null | Select-String "LISTENING" | Select-Object -First 20 | foreach { Write-Output "  $_" }
""",
        "danger": False,
    },
    {
        "id": "active_connections",
        "label": "Active Network Connections Report",
        "category": "Network",
        "description": "Lists all active TCP connections with owning process names",
        "command": r"""
Write-Output "  === ACTIVE TCP CONNECTIONS ==="
Write-Output "  Process                    Local                      Remote                     State"
Write-Output "  ─────────────────────────────────────────────────────────────────────────────────────"
Get-NetTCPConnection -ErrorAction SilentlyContinue |
    Where-Object {$_.State -ne 'Listen' -and $_.RemoteAddress -ne '0.0.0.0' -and $_.RemoteAddress -ne '::'} |
    Select-Object -First 25 | foreach {
        $proc = (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name
        if (-not $proc) { $proc = "PID:$($_.OwningProcess)" }
        $local  = "$($_.LocalAddress):$($_.LocalPort)"
        $remote = "$($_.RemoteAddress):$($_.RemotePort)"
        Write-Output "  $($proc.PadRight(27)) $($local.PadRight(27)) $($remote.PadRight(27)) $($_.State)"
    }
""",
        "danger": False,
    },
]

CATEGORIES = list(dict.fromkeys(o["category"] for o in OPERATIONS))
assert len(OPERATIONS) == 36, f"Expected 36 operations, got {len(OPERATIONS)}"

TRANSPORTS = [
    ("Windows Domain (NTLM) -- Recommended", "ntlm"),
    ("Workgroup / Local Account (Basic)",    "basic"),
    ("Active Directory (Kerberos)",          "kerberos"),
    ("Admin Double-Hop (CredSSP)",           "credssp"),
]

# ══════════════════════════════════════════════════════════════════════════
#  WINRM HELPERS  (same execution model as app.py: EncodedCommand via run_cmd,
#  plus automatic session reconnect on timeout/connection loss)
# ══════════════════════════════════════════════════════════════════════════
def make_session(hostname, username, password, transport="ntlm"):
    """
    Returns a pypsrp.client.Client -- a real PSRP (PowerShell Remoting
    Protocol) client, identical in spirit to what New-PSSession/
    Invoke-Command use natively in the PowerShell edition. Nothing here
    actually connects yet; the first execute_ps() call opens the runspace.

    transport accepts the exact same strings already used by the "Auth
    Transport" dropdown ("ntlm"/"basic"/"kerberos"/"credssp") -- pypsrp's
    `auth` parameter uses this identical vocabulary, so no translation is
    needed.

    Basic auth is a special case: unlike ntlm/kerberos/credssp/negotiate,
    it has no protocol-level message encryption of its own, so pypsrp
    refuses to construct a WSMan client for it with the default
    encryption="auto" over plain HTTP (raises ValueError immediately --
    caught this in testing before it ever reached a real target). This
    tool has always used plain HTTP for every transport, so Basic auth's
    credentials were already unprotected at the transport layer either
    way; encryption="never" here just makes that pre-existing, already-
    accepted posture explicit for the one auth mode where it actually
    matters, instead of the whole client failing to construct.
    """
    kwargs = dict(
        username=username,
        password=password,
        auth=transport,
        ssl=False,
        port=5985,
        connection_timeout=30,
        read_timeout=180,
        operation_timeout=170,
    )
    if transport == "basic":
        kwargs["encryption"] = "never"
    return Client(hostname, **kwargs)


def run_remote_ps(session, script):
    """
    Execute a PowerShell script on the remote host over real PSRP
    (Fix #18) -- mirrors app.py's run_remote_ps exactly; keep both in sync.

    Why this replaced the old -EncodedCommand/chunked-temp-file engine:
    that approach was hand-rolling, at the application layer, exactly what
    the PSRP protocol already does correctly and natively --
    fragmenting arbitrarily large scripts, keeping Success/Error/Warning/
    Verbose/Debug/Progress cleanly separated, and transporting Unicode
    without any file-encoding guesswork. Every one of Fix #6, #7, #11,
    #12, and #17 was a real bug in that hand-rolled machinery; PSRP simply
    doesn't have that class of bug, because it was never re-implementing
    process-spawn/command-line/file-encoding semantics in the first place.
    Concretely, this also means: no command-line-length limit of any kind
    (so no minify/chunk/adaptive-retry machinery needed), no temp files
    written to the target for script delivery (so a near-full disk on the
    target no longer breaks every single operation), and no CLIXML text
    to parse (errors arrive as properly typed, cleanly str()-able
    ErrorRecord objects, and Progress records never mix into them).

    Verified against pypsrp's own recorded real-WinRM-server test fixtures
    (test_client_execute_ps / test_client_execute_ps_failure) rather than
    just the docs -- see the bug-fix history for details.

    NOTE (Fix #19): the preamble deliberately does NOT set
    [Console]::OutputEncoding. That line was carried over unchanged from
    the old -EncodedCommand engine, where it mattered because output was
    captured as a raw console byte stream. Real PSRP sessions run inside
    a RunspacePool with no console at all -- touching [Console] there
    throws "Exception setting 'OutputEncoding': 'The handle is invalid.'"
    on every single call, which is exactly what broke every task after
    Fix #18 shipped. PSRP transports Write-Output/Write-Host text
    correctly on its own regardless of any encoding preference (confirmed
    against multiple independent real-world reports of this exact error
    in remote PSSessions) -- do not add this line back.
    """
    preamble = (
        "$ErrorActionPreference = 'Continue'\n"
        "$ProgressPreference = 'SilentlyContinue'\n"
        "$WarningPreference = 'SilentlyContinue'\n"
    )
    try:
        output, streams, had_errors = session.execute_ps(preamble + script)
        error_lines = [str(e).strip() for e in streams.error if str(e).strip()]
        success = not had_errors
        return output, "\n".join(error_lines), success
    except AuthenticationError:
        return "", "CRED_ERR:Invalid username or password", False
    except (WinRMTransportError, WSManFaultError) as e:
        return "", f"TRANSPORT_ERR:{e}", False
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return "", "TIMEOUT_ERR:Operation timed out after 170 seconds", False
    except requests.exceptions.ConnectionError as e:
        return "", f"TRANSPORT_ERR:{e}", False
    except Exception as e:
        return "", f"ERR:{e}", False


# ══════════════════════════════════════════════════════════════════════════
#  CUSTOM CANVAS CHECKBOX  (white border, red tick -- matches the docx spec)
# ══════════════════════════════════════════════════════════════════════════
class TaskRow(tk.Frame):
    def __init__(self, master, op, on_toggle=None, **kw):
        super().__init__(master, bg=CARD, highlightthickness=1,
                          highlightbackground=BDR, **kw)
        self.op = op
        self.checked = tk.BooleanVar(value=False)
        self.on_toggle = on_toggle

        self.cb_canvas = tk.Canvas(self, width=20, height=20, bg=CARD,
                                    highlightthickness=0, cursor="hand2")
        self.cb_canvas.pack(side="left", padx=(10, 8), pady=8)
        self.cb_canvas.bind("<Button-1>", self._toggle)
        self._draw_box()

        txt_frame = tk.Frame(self, bg=CARD)
        txt_frame.pack(side="left", fill="x", expand=True, pady=6)
        txt_frame.bind("<Button-1>", self._toggle)

        prefix = "! " if op["danger"] else ""
        lbl_color = YEL if op["danger"] else TXTB
        self.lbl = tk.Label(txt_frame, text=f"{prefix}{op['label']}", bg=CARD,
                             fg=lbl_color, font=("Segoe UI", 9, "bold"),
                             anchor="w", cursor="hand2")
        self.lbl.pack(anchor="w")
        self.lbl.bind("<Button-1>", self._toggle)
        self.sub = tk.Label(txt_frame, text=op["description"], bg=CARD,
                             fg=TXDD, font=("Segoe UI", 8), anchor="w",
                             cursor="hand2")
        self.sub.pack(anchor="w")
        self.sub.bind("<Button-1>", self._toggle)

        self.cat_lbl = tk.Label(self, text=op["category"], bg=CRD2, fg=OUT2,
                                 font=("Segoe UI", 7, "bold"), padx=6, pady=2)
        self.cat_lbl.pack(side="right", padx=10)

    def _draw_box(self):
        self.cb_canvas.delete("all")
        if self.checked.get():
            self.cb_canvas.create_rectangle(2, 2, 18, 18, outline="#ffffff",
                                             width=2, fill=RED)
            self.cb_canvas.create_line(5, 10, 9, 14, fill="#ffffff", width=2)
            self.cb_canvas.create_line(9, 14, 15, 6, fill="#ffffff", width=2)
        else:
            self.cb_canvas.create_rectangle(2, 2, 18, 18, outline="#ffffff",
                                             width=2, fill=CARD)

    def _toggle(self, _evt=None):
        self.checked.set(not self.checked.get())
        self._draw_box()
        if self.on_toggle:
            self.on_toggle()

    def set_checked(self, val):
        self.checked.set(val)
        self._draw_box()


# ══════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════════════
class PCAdminApp:
    def __init__(self, root):
        self.root = root
        root.title(f"PC Admin & Performance Tool -- {VER}")
        root.geometry("1180x760")
        root.minsize(980, 640)
        root.configure(bg=BG)

        self.rows = {}                 # id -> TaskRow
        self.log_file = None
        self.log_lines = []
        self.q = queue.Queue()
        self.stop_flag = threading.Event()
        self.worker = None
        self.running = False

        self._build_ui()
        self._poll_queue()
        self._log("hdr", f"  PC Admin & Performance Tool  {VER}")
        self._log("dim", f"  {COPYRIGHT}")
        self._log("dim", "  " + "-" * 60)
        self._log("info", f"  {len(OPERATIONS)} operations ready across "
                           f"{len(CATEGORIES)} categories")
        self._log("dim", "  Enter Hostname/IP -- Test Connection -- Select tasks -- Run")
        self._log("dim", "")

    # ────────────────────────────────────────────────────────────────
    def _build_ui(self):
        header = tk.Frame(self.root, bg=HDRB, height=54)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="PC ADMIN & PERFORMANCE TOOL", bg=HDRB, fg=TXTB,
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=16)
        tk.Label(header, text=VER, bg=HDRB, fg=CYAN,
                 font=("Segoe UI", 9)).pack(side="left", padx=4)
        tk.Label(header, text=COPYRIGHT, bg=HDRB, fg=TXDD,
                 font=("Segoe UI", 8)).pack(side="right", padx=16)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=10, pady=10)

        left = tk.Frame(body, bg=BG, width=460)
        left.pack(side="left", fill="both", padx=(0, 8))
        left.pack_propagate(False)
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        # ---- Connection panel ----
        conn = tk.LabelFrame(left, text=" Target Connection ", bg=PNL, fg=TXTB,
                              font=("Segoe UI", 9, "bold"), bd=1,
                              highlightbackground=BDR)
        conn.pack(fill="x", pady=(0, 8))

        def field(parent, label):
            tk.Label(parent, text=label, bg=PNL, fg=TXT,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=10, pady=(6, 0))
            e = tk.Entry(parent, bg=LOGBG, fg=TXTB, insertbackground=TXTB,
                         relief="flat", highlightthickness=1,
                         highlightbackground=BDR, highlightcolor=ACC)
            e.pack(fill="x", padx=10, pady=(2, 2), ipady=4)
            return e

        self.tx_host = field(conn, "Hostname / IP")
        self.tx_user = field(conn, "Username  (DOMAIN\\user or user@domain.local)")
        tk.Label(conn, text="Password", bg=PNL, fg=TXT,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=10, pady=(6, 0))
        pw_frame = tk.Frame(conn, bg=PNL)
        pw_frame.pack(fill="x", padx=10, pady=(2, 2))
        self.tx_pass = tk.Entry(pw_frame, bg=LOGBG, fg=TXTB, insertbackground=TXTB,
                                 relief="flat", show="*", highlightthickness=1,
                                 highlightbackground=BDR, highlightcolor=ACC)
        self.tx_pass.pack(side="left", fill="x", expand=True, ipady=4)
        self.show_pw = tk.BooleanVar(value=False)

        def toggle_pw():
            self.tx_pass.config(show="" if self.show_pw.get() else "*")

        tk.Checkbutton(pw_frame, text="show", variable=self.show_pw,
                        command=toggle_pw, bg=PNL, fg=TXDD,
                        selectcolor=CARD, activebackground=PNL,
                        font=("Segoe UI", 7)).pack(side="left", padx=6)

        tk.Label(conn, text="Auth Transport", bg=PNL, fg=TXT,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=10, pady=(6, 0))
        self.cb_transport = ttk.Combobox(
            conn, values=[t[0] for t in TRANSPORTS], state="readonly")
        self.cb_transport.current(0)
        self.cb_transport.pack(fill="x", padx=10, pady=(2, 8))

        btn_row = tk.Frame(conn, bg=PNL)
        btn_row.pack(fill="x", padx=10, pady=(0, 10))
        self.btn_test = tk.Button(btn_row, text="Test Connection", bg=ACC, fg="white",
                                   relief="flat", font=("Segoe UI", 9, "bold"),
                                   activebackground=CYAN, command=self.test_connection)
        self.btn_test.pack(side="left", fill="x", expand=True, ipady=5)

        # ---- Category tabs ----
        tabs = tk.Frame(left, bg=BG)
        tabs.pack(fill="x", pady=(0, 6))
        self.tab_buttons = {}
        self.active_cat = "all"

        def mk_tab(key, text):
            b = tk.Button(tabs, text=text, bg=CRD2, fg=TXT, relief="flat",
                          font=("Segoe UI", 8, "bold"),
                          command=lambda k=key: self._filter_cat(k))
            b.pack(side="left", fill="x", expand=True, padx=2, ipady=4)
            self.tab_buttons[key] = b

        mk_tab("all", "All")
        for c in CATEGORIES:
            mk_tab(c, c.split()[0])

        # ---- Task list (scrollable) ----
        list_wrap = tk.Frame(left, bg=BG, highlightthickness=1,
                              highlightbackground=BDR)
        list_wrap.pack(fill="both", expand=True)
        canvas = tk.Canvas(list_wrap, bg=BG, highlightthickness=0)
        vsb = ttk.Scrollbar(list_wrap, orient="vertical", command=canvas.yview)
        self.list_frame = tk.Frame(canvas, bg=BG)
        self.list_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.list_frame, anchor="nw",
                              width=430)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        def _mousewheel(e):
            canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _mousewheel)

        for op in OPERATIONS:
            row = TaskRow(self.list_frame, op, on_toggle=self._update_count)
            row.pack(fill="x", pady=2, padx=2)
            self.rows[op["id"]] = row

        sel_row = tk.Frame(left, bg=BG)
        sel_row.pack(fill="x", pady=6)
        tk.Button(sel_row, text="Select All", bg=CRD2, fg=TXT, relief="flat",
                  font=("Segoe UI", 8), command=self._select_all
                  ).pack(side="left", fill="x", expand=True, padx=2, ipady=3)
        tk.Button(sel_row, text="Select None", bg=CRD2, fg=TXT, relief="flat",
                  font=("Segoe UI", 8), command=self._select_none
                  ).pack(side="left", fill="x", expand=True, padx=2, ipady=3)
        self.lbl_count = tk.Label(left, text="0 tasks selected", bg=BG, fg=CYAN,
                                   font=("Segoe UI", 8, "bold"))
        self.lbl_count.pack(anchor="w", pady=(0, 4))

        # ---- Right: run controls + live log ----
        run_row = tk.Frame(right, bg=BG)
        run_row.pack(fill="x", pady=(0, 6))
        self.btn_run = tk.Button(run_row, text="\u25B6  RUN SELECTED TASKS", bg=GRN,
                                  fg="#062b14", relief="flat",
                                  font=("Segoe UI", 10, "bold"),
                                  command=self.run_tasks)
        self.btn_run.pack(side="left", ipady=8, ipadx=10)
        self.btn_stop = tk.Button(run_row, text="\u25A0  STOP", bg=RED, fg="white",
                                   relief="flat", font=("Segoe UI", 10, "bold"),
                                   state="disabled", command=self.stop_tasks)
        self.btn_stop.pack(side="left", ipady=8, ipadx=10, padx=6)
        tk.Button(run_row, text="Open Logs Folder", bg=CRD2, fg=TXT, relief="flat",
                  font=("Segoe UI", 9), command=self.open_logs
                  ).pack(side="right", ipady=8, ipadx=10)

        self.prg = ttk.Progressbar(right, orient="horizontal", mode="determinate")
        self.prg.pack(fill="x", pady=(0, 4))
        status_row = tk.Frame(right, bg=BG)
        status_row.pack(fill="x")
        self.lbl_dot = tk.Label(status_row, text="\u25CF", bg=BG, fg=TXDD,
                                 font=("Segoe UI", 10))
        self.lbl_dot.pack(side="left")
        self.lbl_stat = tk.Label(status_row, text="Idle", bg=BG, fg=TXT,
                                  font=("Segoe UI", 9))
        self.lbl_stat.pack(side="left", padx=6)
        self.lbl_task = tk.Label(status_row, text="", bg=BG, fg=TXDD,
                                  font=("Segoe UI", 8))
        self.lbl_task.pack(side="right")

        log_wrap = tk.Frame(right, bg=LOGBG, highlightthickness=1,
                             highlightbackground=BDR)
        log_wrap.pack(fill="both", expand=True, pady=(6, 0))
        self.txt = tk.Text(log_wrap, bg=LOGBG, fg=TXT, insertbackground=TXT,
                            font=("Consolas", 9), relief="flat", wrap="word",
                            state="disabled")
        tsb = ttk.Scrollbar(log_wrap, orient="vertical", command=self.txt.yview)
        self.txt.configure(yscrollcommand=tsb.set)
        self.txt.pack(side="left", fill="both", expand=True)
        tsb.pack(side="right", fill="y")

        for tag, color, bold in [
            ("hdr", CYAN, True), ("info", CYAN, False), ("ok", GRN, False),
            ("warn", YEL, False), ("err", RED, False), ("dim", TXDD, False),
            ("task", TXTB, True), ("out", OUT2, False),
        ]:
            self.txt.tag_config(tag, foreground=color,
                                 font=("Consolas", 9, "bold" if bold else "normal"))

    # ────────────────────────────────────────────────────────────────
    def _filter_cat(self, key):
        self.active_cat = key
        for k, b in self.tab_buttons.items():
            b.configure(bg=ACC if k == key else CRD2)
        for op_id, row in self.rows.items():
            show = (key == "all" or row.op["category"] == key)
            if show:
                row.pack(fill="x", pady=2, padx=2)
            else:
                row.pack_forget()

    def _select_all(self):
        for row in self.rows.values():
            if row.winfo_manager():
                row.set_checked(True)
        self._update_count()

    def _select_none(self):
        for row in self.rows.values():
            row.set_checked(False)
        self._update_count()

    def _get_selected(self):
        return [row.op for row in self.rows.values() if row.checked.get()]

    def _update_count(self):
        n = len(self._get_selected())
        self.lbl_count.config(text=f"{n} task{'s' if n != 1 else ''} selected")

    # ────────────────────────────────────────────────────────────────
    def _log(self, tag, text):
        self.txt.configure(state="normal")
        self.txt.insert("end", text + "\n", tag)
        self.txt.see("end")
        self.txt.configure(state="disabled")
        if self.log_file is not None:
            self.log_lines.append(text)

    def open_logs(self):
        try:
            os.startfile(LOG_DIR)  # Windows only
        except AttributeError:
            messagebox.showinfo("Logs", f"Log folder: {LOG_DIR}")
        except Exception as e:
            messagebox.showerror("Logs", str(e))

    # ────────────────────────────────────────────────────────────────
    def test_connection(self):
        host = self.tx_host.get().strip()
        user = self.tx_user.get().strip()
        pwd = self.tx_pass.get()
        transport = TRANSPORTS[self.cb_transport.current()][1]

        if not host:
            messagebox.showwarning("Input", "Enter hostname or IP.")
            return
        if not user:
            messagebox.showwarning("Input", "Enter credentials.")
            return

        self.btn_test.config(state="disabled", text="Testing...")
        self.lbl_stat.config(text="Testing connection...")

        def worker():
            try:
                socket.gethostbyname(host)
            except socket.gaierror:
                self.q.put(("test_result", "error", f"Cannot resolve '{host}'. Check hostname/DNS."))
                return
            try:
                sess = make_session(host, user, pwd, transport)
                stdout, stderr, ok = run_remote_ps(sess, 'Write-Output "PING_OK_$env:COMPUTERNAME"')
                if ok and "PING_OK_" in stdout:
                    remote = stdout.strip().replace("PING_OK_", "")
                    self.q.put(("test_result", "ok",
                                f"Connected to {host} as '{user}'. Remote: {remote}. WinRM OK."))
                else:
                    self.q.put(("test_result", "error",
                                f"WinRM connected but test command failed. {stderr[:200]}"))
            except AuthenticationError:
                self.q.put(("test_result", "error",
                            f"Auth failed for '{user}'. Try DOMAIN\\username or user@domain.local"))
            except Exception as e:
                err = str(e)
                if "5985" in err or "refused" in err.lower() or "timed out" in err.lower():
                    self.q.put(("test_result", "error",
                                f"Cannot reach WinRM on {host}:5985. "
                                f"Run on target (Admin): Enable-PSRemoting -Force"))
                else:
                    self.q.put(("test_result", "error", f"Connection error: {err}"))

        threading.Thread(target=worker, daemon=True).start()

    # ────────────────────────────────────────────────────────────────
    def run_tasks(self):
        if self.running:
            return
        selected = self._get_selected()
        if not selected:
            messagebox.showwarning("No Tasks", "Select at least one task.")
            return
        host = self.tx_host.get().strip()
        user = self.tx_user.get().strip()
        pwd = self.tx_pass.get()
        transport_label, transport = TRANSPORTS[self.cb_transport.current()]
        if not host:
            messagebox.showwarning("Input", "Enter hostname or IP.")
            return
        if not user:
            messagebox.showwarning("Input", "Enter credentials.")
            return

        dangerous = [op for op in selected if op["danger"]]
        if dangerous:
            names = "\n".join(f"  * {op['label']}" for op in dangerous)
            ans = messagebox.askyesno(
                "Confirm",
                f"WARNING: {len(dangerous)} sensitive op(s):\n\n{names}\n\n"
                "Some require reboots or may interrupt network.\n\nContinue?")
            if not ans:
                return

        now = datetime.datetime.now()
        ts = now.strftime("%Y%m%d_%H%M%S")
        safe_host = re.sub(r"[^\w\-.]", "_", host)
        log_path = LOG_DIR / f"AdminTool_{safe_host}_{ts}.log"
        self.log_file = log_path
        self.log_lines = []

        self.stop_flag.clear()
        self.running = True
        self.btn_run.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.lbl_dot.config(fg=GRN)
        self.lbl_stat.config(text="Connecting...")
        self.prg["value"] = 0

        header = [
            "=" * 60,
            f"  PC ADMIN & PERFORMANCE TOOL  {VER}",
            f"  {COPYRIGHT_LONG}",
            "=" * 60,
            f"  Target   : {host}",
            f"  Username : {user}  [{transport_label}]",
            f"  Date/Time: {now.strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Tasks    : {len(selected)} selected",
            f"  Log File : {log_path.name}",
            "=" * 60,
            "",
        ]
        for line in header:
            tag = "hdr" if line.startswith("=") or "TOOL" in line else \
                  "info" if line.startswith("  Target") or line.startswith("  Username") or \
                            line.startswith("  Date") or line.startswith("  Tasks") or \
                            line.startswith("  Log") else "dim"
            self._log(tag, line)

        self.worker = threading.Thread(
            target=self._run_worker, args=(host, user, pwd, transport, selected), daemon=True)
        self.worker.start()

    def stop_tasks(self):
        self.stop_flag.set()
        self.q.put(("log", "warn", "  ! STOP requested -- finishing current task..."))

    def _run_worker(self, host, user, pwd, transport, selected):
        try:
            session = make_session(host, user, pwd, transport)
            _, stderr_test, ok_test = run_remote_ps(session, 'Write-Output "SESSION_OK"')
            if not ok_test:
                self.q.put(("log", "err", f"  CONNECT FAILED: {stderr_test}"))
                self.q.put(("done", False))
                return
            self.q.put(("log", "ok", f"  Session ready -- {host}"))
            self.q.put(("log", "dim", ""))
        except AuthenticationError:
            self.q.put(("log", "err", "  CONNECT FAILED: Invalid username or password"))
            self.q.put(("done", False))
            return
        except Exception as e:
            self.q.put(("log", "err", f"  CONNECT FAILED: {e}"))
            self.q.put(("done", False))
            return

        total = len(selected)
        for idx, op in enumerate(selected, start=1):
            if self.stop_flag.is_set():
                self.q.put(("log", "warn", "  ! STOPPED by user"))
                break

            self.q.put(("progress", idx, total, f"[{idx}/{total}] {op['label']}"))
            prefix = "! " if op["danger"] else ""
            self.q.put(("log", "task", f"  >> [{idx}/{total}]  {prefix}{op['label']}"))
            self.q.put(("log", "dim", f"     Category: {op['category']}  --  {op['description']}"))
            self.q.put(("log", "dim", "     " + "-" * 48))

            t0 = time.time()
            stdout, stderr, ok = run_remote_ps(session, op["command"])

            # auto-reconnect on dead session (timeout / connection loss)
            if not ok and stderr.startswith(("TRANSPORT_ERR", "TIMEOUT_ERR")):
                self.q.put(("log", "warn", "     Connection lost -- reconnecting..."))
                try:
                    session = make_session(host, user, pwd, transport)
                    _, _, reconn_ok = run_remote_ps(session, 'Write-Output "RECONNECTED"')
                    if reconn_ok:
                        self.q.put(("log", "ok", "     Session reconnected -- retrying task"))
                        stdout, stderr, ok = run_remote_ps(session, op["command"])
                    else:
                        self.q.put(("log", "err", "     Reconnect failed"))
                except Exception as e:
                    self.q.put(("log", "err", f"     Reconnect failed: {e}"))

            elapsed = round(time.time() - t0, 1)

            if stdout.strip():
                for line in stdout.splitlines():
                    line = line.rstrip()
                    if not line:
                        continue
                    lo = line.lower()
                    if any(k in lo for k in ("freed", "cleared", "complete", "restarted",
                                              "pass", "ok", "removed", "deleted")):
                        tag = "ok"
                    elif any(k in lo for k in ("warn", "skip", "not found", "already", "empty", "cannot")):
                        tag = "warn"
                    elif any(k in lo for k in ("error", "fail", "denied", "critical")):
                        tag = "err"
                    else:
                        tag = "out"
                    self.q.put(("log", tag, f"     {line}"))
            else:
                self.q.put(("log", "warn", "     ! No output -- check permissions or nothing to process"))

            if stderr.strip():
                for line in stderr.splitlines():
                    if not line.strip():
                        continue
                    if line.startswith("CRED_ERR"):
                        line = "Authentication failed -- re-check credentials"
                    elif line.startswith("TRANSPORT_ERR"):
                        line = "WinRM transport error -- connection may have dropped"
                    elif line.startswith("TIMEOUT_ERR"):
                        line = "Task timed out (>170s) -- operation may still be running"
                    elif "AccessDenied" in line or "Access is denied" in line:
                        line = "Access denied -- use an account with admin rights"
                    self.q.put(("log", "err", f"     {line}"))

            status = "Completed" if ok else "Completed with errors"
            self.q.put(("log", "ok" if ok else "warn", f"     {status} in {elapsed}s"))
            self.q.put(("log", "dim", ""))

        stopped = self.stop_flag.is_set()
        footer = [
            "=" * 60,
            "  STOPPED BY USER" if stopped else "  ALL TASKS COMPLETED",
            f"  Finished : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Log: {self.log_file.name if self.log_file else ''}",
            f"  {COPYRIGHT}",
            "=" * 60,
        ]
        for line in footer:
            self.q.put(("log", "hdr" if line.startswith("=") else
                                "warn" if "STOPPED" in line else
                                "ok" if "COMPLETED" in line else "dim", line))
        self.q.put(("done", not stopped))

    # ────────────────────────────────────────────────────────────────
    def _poll_queue(self):
        try:
            while True:
                item = self.q.get_nowait()
                kind = item[0]
                if kind == "log":
                    _, tag, text = item
                    self._log(tag, text)
                elif kind == "progress":
                    _, idx, total, task_text = item
                    pct = int((idx / max(total, 1)) * 100)
                    self.prg["value"] = pct
                    self.lbl_stat.config(text=task_text)
                elif kind == "test_result":
                    _, status, msg = item
                    self.btn_test.config(state="normal", text="Test Connection")
                    self.lbl_stat.config(text="Idle")
                    if status == "ok":
                        messagebox.showinfo("Connection OK", msg)
                        self._log("ok", f"  Connected: {msg}")
                    else:
                        messagebox.showerror("Connection Failed", msg)
                        self._log("err", f"  {msg}")
                elif kind == "done":
                    _, success = item
                    self.running = False
                    self.btn_run.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    self.lbl_dot.config(fg=TXDD)
                    self.lbl_task.config(text="")
                    self.prg["value"] = 100 if success else self.prg["value"]
                    self.lbl_stat.config(
                        text="Stopped -- review log" if self.stop_flag.is_set()
                        else "All tasks completed -- log saved")
                    if self.log_file is not None:
                        try:
                            with open(self.log_file, "w", encoding="utf-8") as f:
                                f.write("\n".join(self.log_lines))
                        except Exception:
                            pass
                    self.log_file = None
        except queue.Empty:
            pass
        self.root.after(80, self._poll_queue)


def main():
    root = tk.Tk()
    try:
        root.iconbitmap(default="")
    except Exception:
        pass
    app = PCAdminApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
