@echo off
title PC Admin & Performance Tool - Native Python GUI Edition
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on this machine.
    echo Install Python 3.9+ from https://www.python.org/downloads/ and re-run this file.
    pause
    exit /b 1
)

echo Installing/updating dependencies (pywinrm)...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt

echo Launching PC Admin ^& Performance Tool...
start "" pythonw "PCAdminTool.pyw"
