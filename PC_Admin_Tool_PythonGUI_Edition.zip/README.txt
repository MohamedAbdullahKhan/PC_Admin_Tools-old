PC Admin & Performance Tool -- Native Python GUI Edition  (v2.1)
================================================================

WHAT'S IN THIS FOLDER
  PCAdminTool.pyw      The complete tool (Tkinter GUI, 36 operations).
  requirements.txt     Just pywinrm -- Tkinter ships with Python itself.
  install_and_run.bat  Double-click: installs pywinrm, then opens the GUI.
  README.txt           This file.

REQUIREMENTS
  - Python 3.9+ installed on the admin workstation (from
    https://www.python.org/downloads/ -- tick "Add to PATH" during
    install; Tkinter is included by default on Windows installers).
  - WinRM enabled on TARGET machines you want to manage:
      Run on each target (as Admin):  Enable-PSRemoting -Force

HOW TO RUN
  1. Copy this whole folder to the admin workstation.
  2. Double-click install_and_run.bat
     (installs pywinrm if missing, then launches the GUI with pythonw
     so no console window stays open).
  3. In the GUI: enter target Hostname/IP, Username, Password, pick
     the Auth Transport, click Test Connection, select tasks, Run.

  Alternatively, once pywinrm is installed, you can just double-click
  PCAdminTool.pyw directly (Windows associates .pyw with pythonw.exe).

LOGS
  Every session writes a timestamped log to:
    PC_Admin_Logs\AdminTool_<hostname>_<timestamp>.log
  (created next to PCAdminTool.pyw)

NOTES
  - Operations marked with "!" are sensitive (may reboot the target,
    interrupt its network, or take many minutes). The tool shows a
    confirmation dialog listing them before running.
  - Same 36 operations, same categories, and the same PowerShell
    command bodies as the Web-Service Edition (app.py) -- this is a
    desktop-native port of that same operation library, no browser
    or server required.

(c) 2024-2026 Abdullah | All Rights Reserved | abuabdullah.be@outlook.com
