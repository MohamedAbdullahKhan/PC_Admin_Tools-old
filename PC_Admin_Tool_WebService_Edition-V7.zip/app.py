#!/usr/bin/env python3
"""
================================================================================
  PC Admin & Performance Troubleshooting Tool  v2.1  — Web-Service Edition
  © 2024-2026 Abdullah | All Rights Reserved
  Contact : abuabdullah.be@outlook.com
  Unauthorized copying, modification or redistribution is strictly prohibited.

  Runs as a standalone network service on PORT 3030 -- reachable from any
  host on the same allowed subnet at http://<this-machine-IP>:3030
  Works unmodified on Linux, Windows, and Windows Server hosts (Python 3.9+).
  All logs and session files are written locally on THIS (hosting) machine,
  under the "logs" folder next to this script.
================================================================================
"""
from flask import Flask, render_template, request, jsonify, Response, stream_with_context
from pypsrp.client import Client
from pypsrp.exceptions import AuthenticationError, WinRMTransportError, WSManFaultError
import requests.exceptions
import json, datetime, socket, re, os, time, threading
from pathlib import Path

app = Flask(__name__)

SERVICE_PORT = 3030

# Logs/files live on the hosting machine (Linux, Windows, or Windows Server),
# in a "logs" folder next to this script -- not tied to a Docker container.
BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

_stop_flag  = threading.Event()
_run_lock   = threading.Lock()

COPYRIGHT = (
    "© 2024-2026 Abdullah | PC Admin & Performance Tool v2.1 | All Rights Reserved\n"
    "Contact: abuabdullah.be@outlook.com | Unauthorized use or redistribution is prohibited."
)

# ══════════════════════════════════════════════════════════════════════════════
#  OPERATIONS  — PowerShell command library
#  command field is server-side only, never sent to the browser
# ══════════════════════════════════════════════════════════════════════════════
OPERATIONS = [

    # ─── 🧹 CLEANUP ──────────────────────────────────────────────────────────
    {
        "id": "clear_user_temp",
        "label": "Clear All Users' Temp Files",
        "category": "Cleanup",
        "description": "Removes %TEMP% from every user profile, incl. SYSTEM/service accounts",
        "command": r"""
Write-Output "  Running as : $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Write-Output "  Computer   : $env:COMPUTERNAME"
$totalFreed = 0
$denied = 0
$profCount = 0
$users = Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue
if (-not $users) {
    Write-Output "  WARNING: C:\Users not found or not accessible"
} else {
    Write-Output "  Found $($users.Count) user profile folder(s) under C:\Users"
    foreach ($user in $users) {
        if ($user.Name -in @("Default","Default User","Public","All Users")) { continue }
        $profCount++
        $path = "$($user.FullName)\AppData\Local\Temp"
        if (Test-Path $path) {
            $items = Get-ChildItem $path -Recurse -Force -ErrorAction SilentlyContinue
            $sizeBefore = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
            if (-not $sizeBefore) { $sizeBefore = 0 }
            $before = $items.Count
            $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue -ErrorVariable delErrs
            $freed = [math]::Round($sizeBefore / 1MB, 2)
            $totalFreed += $freed
            if ($delErrs -and $delErrs.Count -gt 0) {
                $denied++
                Write-Output "  [$($user.Name)] Freed ${freed} MB  ($($delErrs.Count) file(s) skipped -- in use / access denied)"
            } else {
                Write-Output "  [$($user.Name)] Freed ${freed} MB  ($before items)"
            }
        } else {
            Write-Output "  [$($user.Name)] No temp folder (profile never fully loaded)"
        }
    }
}
$svcProfiles = @(
    @{Name="SYSTEM";         Path="C:\Windows\System32\config\systemprofile\AppData\Local\Temp"},
    @{Name="LocalService";   Path="C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"},
    @{Name="NetworkService"; Path="C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp"}
)
foreach ($sp in $svcProfiles) {
    if (Test-Path $sp.Path) {
        $items = Get-ChildItem $sp.Path -Recurse -Force -ErrorAction SilentlyContinue
        $sizeBefore = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if (-not $sizeBefore) { $sizeBefore = 0 }
        $items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue -ErrorVariable svcErrs
        $freed = [math]::Round($sizeBefore / 1MB, 2)
        $totalFreed += $freed
        $note = if ($svcErrs -and $svcErrs.Count -gt 0) { " ($($svcErrs.Count) file(s) skipped -- in use)" } else { "" }
        Write-Output "  [$($sp.Name)] Freed ${freed} MB$note"
        $profCount++
    }
}
Write-Output "  ------------------------------------------------"
Write-Output "  Profiles processed: $profCount   |   TOTAL FREED: $totalFreed MB"
if ($denied -gt 0) { Write-Output "  NOTE: $denied profile(s) had files in use and were partially skipped (normal for the logged-in user's active session)" }
"""
    },
    {
        "id": "clear_windows_temp",
        "label": "Clear Windows System Temp (C:\\Windows\\Temp)",
        "category": "Cleanup",
        "description": "Deletes files in the Windows system temp directory",
        "command": r"""
$path = "C:\Windows\Temp"
if (-not (Test-Path $path)) { Write-Output "  Path not found: $path"; return }
$items  = Get-ChildItem $path -Recurse -ErrorAction SilentlyContinue
$count  = $items.Count
$size   = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
if (-not $size) { $size = 0 }
$items | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "  Deleted $count items | Freed: $([math]::Round($size/1MB,2)) MB"
"""
    },
    {
        "id": "clear_prefetch",
        "label": "Clear Windows Prefetch Files",
        "category": "Cleanup",
        "description": "Removes .pf files from C:\\Windows\\Prefetch",
        "command": r"""
$path = "C:\Windows\Prefetch"
if (-not (Test-Path $path)) { Write-Output "  Prefetch folder not found"; return }
$files = Get-ChildItem $path -Filter "*.pf" -ErrorAction SilentlyContinue
$size  = ($files | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
if (-not $size) { $size = 0 }
$files | Remove-Item -Force -ErrorAction SilentlyContinue
Write-Output "  Removed $($files.Count) prefetch files | Freed: $([math]::Round($size/1MB,2)) MB"
"""
    },
    {
        "id": "clear_thumbnail_cache",
        "label": "Clear Thumbnail Cache (All Users)",
        "category": "Cleanup",
        "description": "Deletes thumbcache_*.db from all user Explorer profiles",
        "command": r"""
$totalFreed = 0
$users = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
if (-not $users) { Write-Output "  WARNING: Cannot enumerate C:\Users"; return }
foreach ($user in $users) {
    $path = "$($user.FullName)\AppData\Local\Microsoft\Windows\Explorer"
    if (Test-Path $path) {
        $files = Get-ChildItem $path -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue
        $size  = ($files | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if (-not $size) { $size = 0 }
        $files | Remove-Item -Force -ErrorAction SilentlyContinue
        $freed = [math]::Round($size/1MB,2)
        $totalFreed += $freed
        Write-Output "  [$($user.Name)] Removed $($files.Count) files | Freed: ${freed} MB"
    }
}
Write-Output "  Total thumbnail cache freed: $totalFreed MB"
"""
    },
    {
        "id": "clear_wu_cache",
        "label": "Clear Windows Update Download Cache",
        "category": "Cleanup",
        "description": "Stops WU/BITS, clears SoftwareDistribution\\Download, restarts services",
        "command": r"""
Write-Output "  Stopping Windows Update & BITS services..."
Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
Stop-Service bits     -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
$path = "C:\Windows\SoftwareDistribution\Download"
if (Test-Path $path) {
    $size = (Get-ChildItem $path -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if (-not $size) { $size = 0 }
    Remove-Item "$path\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Output "  Cache cleared | Freed: $([math]::Round($size/1MB,2)) MB"
} else { Write-Output "  WU cache path not found" }
Start-Service wuauserv -ErrorAction SilentlyContinue
Start-Service bits     -ErrorAction SilentlyContinue
Write-Output "  Windows Update & BITS services restarted"
"""
    },
    {
        "id": "flush_dns",
        "label": "Flush DNS Resolver Cache",
        "category": "Cleanup",
        "description": "SAFE: Clears local DNS cache + /registerdns to preserve network connectivity",
        "command": r"""
Write-Output "  SAFE FLUSH -- local DNS cache only"
$before = @(Get-DnsClientCache -ErrorAction SilentlyContinue).Count
Write-Output "  Entries before : $before"
Clear-DnsClientCache -ErrorAction SilentlyContinue
ipconfig /flushdns 2>&1 | Out-Null
ipconfig /registerdns 2>&1 | Out-Null
$after = @(Get-DnsClientCache -ErrorAction SilentlyContinue).Count
Write-Output "  Entries after  : $after"
$gw = (Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4DefaultGateway} | Select-Object -First 1).IPv4DefaultGateway.NextHop
if ($gw) {
    $ping = Test-NetConnection -ComputerName $gw -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    $gwStatus = if ($ping.PingSucceeded) { "REACHABLE" } else { "check connectivity" }
    Write-Output "  Gateway $gw : $gwStatus"
}
Write-Output "  DNS flushed safely -- domain connectivity preserved"
"""
    },
    {
        "id": "clear_browser_cache",
        "label": "Clear Browser Caches (Chrome / Edge / Firefox)",
        "category": "Cleanup",
        "description": "Purges browser cache folders for all user profiles",
        "command": r"""
$totalFreed = 0
$browsers = @{
    "Google Chrome"  = "\AppData\Local\Google\Chrome\User Data\Default\Cache"
    "Microsoft Edge" = "\AppData\Local\Microsoft\Edge\User Data\Default\Cache"
}
$users = Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue
if (-not $users) { Write-Output "  WARNING: Cannot enumerate C:\Users"; return }
foreach ($user in $users) {
    foreach ($b in $browsers.GetEnumerator()) {
        $p = "$($user.FullName)$($b.Value)"
        if (Test-Path $p) {
            $size = (Get-ChildItem $p -Recurse -EA SilentlyContinue | Measure-Object Length -Sum).Sum
            if (-not $size) { $size = 0 }
            Remove-Item "$p\*" -Recurse -Force -EA SilentlyContinue
            $freed = [math]::Round($size/1MB,2); $totalFreed += $freed
            Write-Output "  [$($user.Name)] $($b.Key): Freed ${freed} MB"
        }
    }
    # Firefox
    $ffBase = "$($user.FullName)\AppData\Local\Mozilla\Firefox\Profiles"
    if (Test-Path $ffBase) {
        Get-ChildItem $ffBase -Directory -EA SilentlyContinue | foreach {
            $cache = "$($_.FullName)\cache2"
            if (Test-Path $cache) {
                $size = (Get-ChildItem $cache -Recurse -EA SilentlyContinue | Measure-Object Length -Sum).Sum
                if (-not $size) { $size = 0 }
                Remove-Item "$cache\*" -Recurse -Force -EA SilentlyContinue
                $freed = [math]::Round($size/1MB,2); $totalFreed += $freed
                Write-Output "  [$($user.Name)] Firefox: Freed ${freed} MB"
            }
        }
    }
}
Write-Output "  TOTAL browser cache freed: $totalFreed MB"
"""
    },
    {
        "id": "clear_event_logs",
        "label": "Clear Windows Event Logs",
        "category": "Cleanup",
        "description": "Clears Application, System, and Setup logs; skips Security if >100k entries",
        "command": r"""
$logs = @("Application","System","Security","Setup")
foreach ($log in $logs) {
    try {
        $count = 0
        try { $li = Get-WinEvent -ListLog $log -ErrorAction SilentlyContinue; if ($li) { $count = $li.RecordCount } } catch {}
        if ($log -eq "Security" -and $count -gt 100000) {
            Write-Output "  SKIPPED: $log ($count entries) -- too large, would hang session"
            continue
        }
        wevtutil cl "$log" 2>$null
        Write-Output "  Cleared: $log ($count entries)"
    } catch { Write-Output "  Skipped: $log" }
}
"""
    },
    {
        "id": "empty_recycle_bin",
        "label": "Empty Recycle Bin (All Drives & Users)",
        "category": "Cleanup",
        "description": "Permanently empties the Recycle Bin on all drives",
        "command": r"""
try {
    $shell = New-Object -ComObject Shell.Application
    $rb = $shell.Namespace(0xA)
    $items = $rb.Items()
    $count = ($items | Measure-Object).Count
    Clear-RecycleBin -Force -ErrorAction Stop
    Write-Output "  Recycle Bin emptied: $count items removed"
} catch { Write-Output "  Recycle Bin already empty or access error: $_" }
"""
    },
    {
        "id": "disk_cleanup",
        "label": "Run Disk Cleanup Utility (cleanmgr)",
        "category": "Cleanup",
        "description": "Runs Windows built-in Disk Cleanup silently with all categories",
        "command": r"""
Write-Output "  Configuring Disk Cleanup categories..."
$regBase = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
$keys = Get-ChildItem $regBase -ErrorAction SilentlyContinue
$count = 0
foreach ($key in $keys) {
    Set-ItemProperty -Path $key.PSPath -Name StateFlags0099 -Value 2 -ErrorAction SilentlyContinue
    $count++
}
Write-Output "  Configured $count cleanup categories"
Write-Output "  Launching cleanmgr (max wait: 10 minutes)..."
$proc = Start-Process cleanmgr -ArgumentList "/sagerun:99" -WindowStyle Hidden -PassThru -ErrorAction SilentlyContinue
if ($proc) {
    $finished = $proc.WaitForExit(600000)
    if (-not $finished) {
        Write-Output "  WARNING: cleanmgr did not finish within 10 minutes. Remote/service"
        Write-Output "  sessions have no desktop, so cleanmgr can silently wait forever on a"
        Write-Output "  UI dialog nobody can see. Terminating it now."
        try { $proc.Kill() } catch {}
        Get-Process cleanmgr -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Write-Output "  Disk Cleanup was terminated after timeout -- some categories may be incomplete"
    } else {
        Write-Output "  Disk Cleanup completed (exit code: $($proc.ExitCode))"
    }
} else {
    Write-Output "  Failed to launch cleanmgr"
}
"""
    },

    # ─── 💾 DISK ─────────────────────────────────────────────────────────────
    {
        "id": "disk_space_report",
        "label": "Disk Space Report (All Drives)",
        "category": "Disk",
        "description": "Shows used/free space and health status for all fixed drives",
        "command": r"""
Write-Output "  Drive   FS         Total     Used      Free      Used%   Health"
Write-Output "  ──────────────────────────────────────────────────────────────────"
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter}
if (-not $vols) { Write-Output "  No fixed volumes found (may need admin rights)"; return }
foreach ($v in $vols) {
    $total = [math]::Round($v.Size/1GB,2)
    $free  = [math]::Round($v.SizeRemaining/1GB,2)
    $used  = [math]::Round($total - $free, 2)
    $pct   = if($total -gt 0) { "$([math]::Round(($used/$total)*100,1))%" } else { "N/A" }
    $warn  = if($total -gt 0 -and ($used/$total) -gt 0.9) { " ⚠CRITICAL" } elseif($total -gt 0 -and ($used/$total) -gt 0.8) { " ⚠LOW" } else { "" }
    Write-Output "  $($v.DriveLetter):      $($v.FileSystem.PadRight(10)) ${total} GB    ${used} GB    ${free} GB   $pct$warn   $($v.HealthStatus)"
}
"""
    },
    {
        "id": "defrag_drives",
        "label": "Optimize / Defragment All Fixed Drives",
        "category": "Disk",
        "description": "Defragments HDDs; runs TRIM on SSDs (auto-detects drive type)",
        "command": r"""
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter -and ($_.FileSystem -eq 'NTFS' -or $_.FileSystem -eq 'ReFS')}
if (-not $vols) { Write-Output "  No eligible NTFS/ReFS volumes found"; return }
foreach ($v in $vols) {
    $dl = $v.DriveLetter
    Write-Output "  Optimizing drive ${dl}: ($($v.FileSystem))..."
    $result = Optimize-Volume -DriveLetter $dl -Verbose 4>$null -ErrorAction SilentlyContinue
    Write-Output "  Drive ${dl}: optimization complete"
}
"""
    },
    {
        "id": "disk_health_scan",
        "label": "Scan Disk Health (Quick Scan — No Reboot)",
        "category": "Disk",
        "description": "Runs Repair-Volume scan on all drives without requiring a reboot",
        "command": r"""
$vols = Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter}
if (-not $vols) { Write-Output "  No fixed volumes found"; return }
foreach ($v in $vols) {
    $dl = $v.DriveLetter
    Write-Output "  Scanning Drive ${dl}: ..."
    $result = Repair-Volume -DriveLetter $dl -Scan -ErrorAction SilentlyContinue
    Write-Output "  Drive ${dl}: Scan=$result | Health=$($v.HealthStatus) | FS=$($v.FileSystem)"
}
"""
    },
    {
        "id": "large_files_report",
        "label": "Find Top 20 Largest Files on C: Drive",
        "category": "Disk",
        "description": "Identifies the biggest disk space consumers on the C: drive",
        "command": r"""
Write-Output "  Scanning C: drive for large files (>100MB)..."
$files = Get-ChildItem "C:\" -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.Length -gt 100MB}
$sorted = $files | Sort-Object Length -Descending | Select-Object -First 20
Write-Output "  Size (GB)    Path"
Write-Output "  ─────────────────────────────────────────────────────────"
foreach ($f in $sorted) {
    $sz = [math]::Round($f.Length/1GB,3)
    Write-Output "  $($sz.ToString('F3')) GB   $($f.FullName)"
}
Write-Output "  Total large files found: $($files.Count)"
"""
    },

    # ─── ⚡ PERFORMANCE ───────────────────────────────────────────────────────
    {
        "id": "high_perf_power",
        "label": "Set High Performance Power Plan",
        "category": "Performance",
        "description": "Activates the built-in High Performance power scheme",
        "command": r"""
$guid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
$result = powercfg -setactive $guid 2>&1
$active  = powercfg -getactivescheme 2>&1
Write-Output "  Power plan set to: High Performance"
Write-Output "  Active: $active"
"""
    },
    {
        "id": "visual_effects_perf",
        "label": "Optimize Visual Effects for Performance",
        "category": "Performance",
        "description": "Sets Windows to Best Performance visual mode (disables animations)",
        "command": r"""
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
if (-not (Test-Path $regPath)) { New-Item $regPath -Force -ErrorAction SilentlyContinue | Out-Null }
Set-ItemProperty -Path $regPath -Name VisualFXSetting -Value 2 -ErrorAction SilentlyContinue
$dp = "HKCU:\Control Panel\Desktop"
Set-ItemProperty $dp -Name DragFullWindows -Value "0" -ErrorAction SilentlyContinue
Set-ItemProperty $dp -Name MenuShowDelay   -Value "0" -ErrorAction SilentlyContinue
$wm = "HKCU:\Control Panel\Desktop\WindowMetrics"
if (Test-Path $wm) { Set-ItemProperty $wm -Name MinAnimate -Value "0" -ErrorAction SilentlyContinue }
Write-Output "  Visual effects set to Best Performance"
Write-Output "  Animations & shadows disabled"
Write-Output "  Note: Re-login required for full effect"
"""
    },
    {
        "id": "optimize_ram",
        "label": "Optimize RAM / Force Garbage Collection",
        "category": "Performance",
        "description": "Reports RAM usage before and after forcing .NET GC collection",
        "command": r"""
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
if (-not $os) { Write-Output "  Cannot query WMI — insufficient rights"; return }
$totalGB  = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
$freeBefore = [math]::Round($os.FreePhysicalMemory/1MB,2)
$usedBefore = [math]::Round($totalGB - $freeBefore,2)
Write-Output "  RAM BEFORE — Total: ${totalGB} GB | Used: ${usedBefore} GB | Free: ${freeBefore} GB"
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()
[System.GC]::Collect()
$freeAfter = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,2)
$usedAfter = [math]::Round($totalGB - $freeAfter,2)
$recovered = [math]::Round($freeAfter - $freeBefore,2)
Write-Output "  RAM AFTER  — Total: ${totalGB} GB | Used: ${usedAfter} GB | Free: ${freeAfter} GB"
Write-Output "  Recovered : ${recovered} GB"
"""
    },
    {
        "id": "tune_sysmain",
        "label": "Auto-Tune SysMain / Superfetch (SSD Detection)",
        "category": "Performance",
        "description": "Disables SysMain on SSDs; keeps it active on HDDs",
        "command": r"""
$svc  = Get-Service -Name "SysMain" -ErrorAction SilentlyContinue
$ssds = Get-PhysicalDisk -ErrorAction SilentlyContinue | Where-Object {$_.MediaType -eq 'SSD'}
if ($ssds) {
    Write-Output "  SSD detected on this system"
    if ($svc -and $svc.Status -eq 'Running') {
        Stop-Service SysMain -Force -ErrorAction SilentlyContinue
        Set-Service  SysMain -StartupType Disabled -ErrorAction SilentlyContinue
        Write-Output "  SysMain DISABLED (recommended for SSD performance)"
    } else { Write-Output "  SysMain already stopped/disabled" }
} else {
    Write-Output "  HDD-only system — SysMain kept ACTIVE"
    if ($svc -and $svc.Status -ne 'Running') {
        Start-Service SysMain -ErrorAction SilentlyContinue
        Set-Service   SysMain -StartupType Automatic -ErrorAction SilentlyContinue
        Write-Output "  SysMain re-enabled for HDD performance"
    }
}
"""
    },
    {
        "id": "restart_search",
        "label": "Restart & Reset Windows Search Indexer",
        "category": "Performance",
        "description": "Restarts WSearch service to free CPU/disk from heavy indexing",
        "command": r"""
$svc = Get-Service -Name "WSearch" -ErrorAction SilentlyContinue
if ($svc) {
    Stop-Service WSearch -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Start-Service WSearch -ErrorAction SilentlyContinue
    Write-Output "  Windows Search indexer restarted successfully"
} else { Write-Output "  Windows Search service not found" }
"""
    },
    {
        "id": "startup_report",
        "label": "Startup Programs & Services Report",
        "category": "Performance",
        "description": "Lists all auto-start programs from registry and scheduled tasks",
        "command": r"""
Write-Output "  === STARTUP REGISTRY ENTRIES ==="
$paths = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
)
foreach ($p in $paths) {
    if (Test-Path $p) {
        $branch = $p.Split('\')[-3]
        Get-ItemProperty $p -ErrorAction SilentlyContinue | ForEach-Object {
            $_.PSObject.Properties | Where-Object {$_.Name -notlike 'PS*'} | ForEach-Object {
                Write-Output "  [$branch] $($_.Name) = $($_.Value)"
            }
        }
    }
}
Write-Output ""
Write-Output "  === WIN32 STARTUP COMMANDS ==="
Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | foreach {
    Write-Output "  [$($_.User)] $($_.Name) — $($_.Command)"
}
Write-Output ""
Write-Output "  === ENABLED THIRD-PARTY SCHEDULED TASKS ==="
Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object {$_.State -eq 'Ready' -and $_.TaskPath -notlike '\Microsoft\*'} |
    Select-Object -First 15 | foreach { Write-Output "  $($_.TaskPath)$($_.TaskName)" }
"""
    },
    {
        "id": "pagefile_report",
        "label": "Virtual Memory / Page File Report",
        "category": "Performance",
        "description": "Shows current page file settings, usage and recommendations",
        "command": r"""
$sys = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
if (-not $sys) { Write-Output "  Cannot query WMI"; return }
$ramGB = [math]::Round($sys.TotalPhysicalMemory/1GB,2)
Write-Output "  RAM Installed     : ${ramGB} GB"
Write-Output "  Auto-Managed PF   : $($sys.AutomaticManagedPagefile)"
Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue | foreach {
    Write-Output "  Page File Path    : $($_.Name)"
    Write-Output "  Allocated Size    : $($_.AllocatedBaseSize) MB"
    Write-Output "  Current Usage     : $($_.CurrentUsage) MB"
    Write-Output "  Peak Usage        : $($_.PeakUsage) MB"
}
$recMin = [math]::Round($ramGB * 1024 * 1.5)
$recMax = [math]::Round($ramGB * 1024 * 3)
Write-Output "  Recommended Range : ${recMin} MB — ${recMax} MB (1.5x–3x RAM)"
"""
    },
    {
        "id": "non_essential_services",
        "label": "Non-Essential Running Services Report",
        "category": "Performance",
        "description": "Lists third-party services consuming CPU/memory resources",
        "command": r"""
Write-Output "  === THIRD-PARTY AUTO-START SERVICES ==="
$svcs = Get-WmiObject Win32_Service -ErrorAction SilentlyContinue |
    Where-Object { $_.State -eq 'Running' -and $_.StartMode -eq 'Auto' -and
        $_.PathName -notlike '*system32*' -and $_.PathName -notlike '*SysWOW64*' -and
        $_.PathName -notlike '*SystemRoot*' }
if ($svcs) {
    foreach ($s in $svcs) {
        $mem = "N/A"
        try { $proc = Get-Process -Id $s.ProcessId -EA SilentlyContinue
              if ($proc) { $mem = "$([math]::Round($proc.WorkingSet64/1MB,1)) MB" } } catch {}
        Write-Output "  $($s.Name.PadRight(40)) RAM: $mem"
    }
} else { Write-Output "  No non-system auto-start services found" }
"""
    },

    # ─── 🔧 WINDOWS HEALTH ───────────────────────────────────────────────────
    {
        "id": "system_info",
        "label": "Full System Information Report",
        "category": "Windows Health",
        "description": "CPU, RAM, OS version, uptime, BIOS, and model info",
        "command": r"""
$cs  = Get-CimInstance Win32_ComputerSystem  -ErrorAction SilentlyContinue
$os  = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
$cpu = Get-CimInstance Win32_Processor       -ErrorAction SilentlyContinue | Select-Object -First 1
$bio = Get-CimInstance Win32_BIOS            -ErrorAction SilentlyContinue
if (-not $cs) { Write-Output "  Cannot query WMI — check permissions"; return }
$uptime = (Get-Date) - $os.LastBootUpTime
Write-Output "  Hostname     : $($cs.Name)"
Write-Output "  Manufacturer : $($cs.Manufacturer) $($cs.Model)"
Write-Output "  OS           : $($os.Caption) $($os.OSArchitecture)"
Write-Output "  OS Build     : $($os.Version) (Build $($os.BuildNumber))"
Write-Output "  CPU          : $($cpu.Name)"
Write-Output "  CPU Cores    : $($cpu.NumberOfCores) Physical / $($cpu.NumberOfLogicalProcessors) Logical"
Write-Output "  CPU Speed    : $($cpu.MaxClockSpeed) MHz"
Write-Output "  RAM Total    : $([math]::Round($cs.TotalPhysicalMemory/1GB,2)) GB"
if ($bio) { Write-Output "  BIOS         : $($bio.Manufacturer) v$($bio.SMBIOSBIOSVersion)" }
Write-Output "  Last Boot    : $($os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm:ss'))"
Write-Output "  Uptime       : $($uptime.Days)d $($uptime.Hours)h $($uptime.Minutes)m $($uptime.Seconds)s"
Write-Output "  Domain       : $($cs.Domain)"
Write-Output "  Logged Users : $($cs.UserName)"
"""
    },
    {
        "id": "top_processes",
        "label": "Top CPU & RAM Consuming Processes",
        "category": "Windows Health",
        "description": "Lists top 10 processes by CPU time and working set memory",
        "command": r"""
Write-Output "  === TOP 10 PROCESSES BY CPU ==="
Write-Output "  Process Name                     CPU (s)      RAM (MB)"
Write-Output "  ──────────────────────────────────────────────────────────"
Get-Process -ErrorAction SilentlyContinue | Sort-Object CPU -Descending | Select-Object -First 10 | foreach {
    $cpu = if($_.CPU){ [math]::Round($_.CPU,1) } else { 0 }
    $ram = [math]::Round($_.WorkingSet64/1MB,1)
    Write-Output "  $($_.Name.PadRight(33)) $($cpu.ToString().PadLeft(8)) s   $($ram.ToString().PadLeft(8)) MB"
}
Write-Output ""
Write-Output "  === TOP 10 PROCESSES BY RAM ==="
Write-Output "  Process Name                     RAM (MB)     PID"
Write-Output "  ──────────────────────────────────────────────────────────"
Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 | foreach {
    $ram = [math]::Round($_.WorkingSet64/1MB,1)
    Write-Output "  $($_.Name.PadRight(33)) $($ram.ToString().PadLeft(8)) MB   PID:$($_.Id)"
}
"""
    },
    {
        "id": "run_sfc",
        "label": "Run SFC /scannow (System File Check)",
        "category": "Windows Health",
        "description": "Scans & repairs corrupted Windows system files (5-15 min)",
        "command": r"""
Write-Output "  Starting SFC scan — this may take several minutes..."
$result = sfc /scannow 2>&1
$result | foreach { Write-Output "  $_" }
Write-Output "  SFC scan complete"
"""
    },
    {
        "id": "run_dism",
        "label": "Run DISM Health Check & Scan",
        "category": "Windows Health",
        "description": "Checks and scans the Windows component store for corruption",
        "command": r"""
Write-Output "  Running DISM CheckHealth..."
DISM /Online /Cleanup-Image /CheckHealth 2>&1 | foreach { Write-Output "  $_" }
Write-Output ""
Write-Output "  Running DISM ScanHealth..."
DISM /Online /Cleanup-Image /ScanHealth 2>&1 | foreach { Write-Output "  $_" }
"""
    },
    {
        "id": "wu_history",
        "label": "Windows Update History Report",
        "category": "Windows Health",
        "description": "Shows last 20 installed Windows updates with install dates",
        "command": r"""
Write-Output "  === LAST 20 WINDOWS UPDATES INSTALLED ==="
Write-Output "  Date          HotFix ID       Description"
Write-Output "  ───────────────────────────────────────────────────────────"
Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 20 | foreach {
    $date = if($_.InstalledOn){ $_.InstalledOn.ToString('yyyy-MM-dd') } else { "Unknown    " }
    Write-Output "  $date      $($_.HotFixID.PadRight(15)) $($_.Description)"
}
"""
    },
    {
        "id": "recent_errors",
        "label": "Recent System & App Errors (Last 24h)",
        "category": "Windows Health",
        "description": "Pulls critical errors and warnings from System and Application logs",
        "command": r"""
$since = (Get-Date).AddHours(-24)
Write-Output "  === SYSTEM ERRORS/WARNINGS (last 24 hours) ==="
$sysEvts = Get-EventLog -LogName System -EntryType Error,Warning -After $since -Newest 15 -ErrorAction SilentlyContinue
if ($sysEvts) {
    $sysEvts | foreach {
        Write-Output "  [$($_.TimeGenerated.ToString('HH:mm'))] [$($_.EntryType)] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"
    }
} else { Write-Output "  No System errors in last 24 hours" }
Write-Output ""
Write-Output "  === APPLICATION ERRORS (last 24 hours) ==="
$appEvts = Get-EventLog -LogName Application -EntryType Error -After $since -Newest 15 -ErrorAction SilentlyContinue
if ($appEvts) {
    $appEvts | foreach {
        Write-Output "  [$($_.TimeGenerated.ToString('HH:mm'))] $($_.Source): $($_.Message.Split([char]10)[0].Trim().Substring(0,[math]::Min(100,$_.Message.Length)))"
    }
} else { Write-Output "  No Application errors in last 24 hours" }
"""
    },
    {
        "id": "installed_software",
        "label": "Installed Software Inventory",
        "category": "Windows Health",
        "description": "Lists all installed applications with version and install date",
        "command": r"""
Write-Output "  === INSTALLED APPLICATIONS ==="
$reg = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)
$apps = $reg | ForEach-Object { Get-ItemProperty $_ -ErrorAction SilentlyContinue } |
    Where-Object {$_.DisplayName} | Sort-Object DisplayName
Write-Output "  Total: $($apps.Count) applications"
Write-Output "  Application Name                                  Version          Installed"
Write-Output "  ─────────────────────────────────────────────────────────────────────────────"
$apps | foreach {
    $ver  = if($_.DisplayVersion){ $_.DisplayVersion } else { "—" }
    $date = if($_.InstallDate){ $_.InstallDate } else { "Unknown" }
    Write-Output "  $($_.DisplayName.PadRight(50)) $($ver.PadRight(16)) $date"
}
"""
    },

    # ─── 🌐 NETWORK ──────────────────────────────────────────────────────────
    {
        "id": "net_ip_config",
        "label": "Network Adapter & IP Configuration",
        "category": "Network",
        "description": "Displays IP, subnet, gateway, DNS for all active adapters",
        "command": r"""
Write-Output "  === NETWORK ADAPTERS ==="
$configs = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4Address}
if (-not $configs) { Write-Output "  No active IPv4 adapters found"; return }
foreach ($c in $configs) {
    $dns = ($c.DNSServer | Where-Object {$_.AddressFamily -eq 2} | Select-Object -ExpandProperty ServerAddresses) -join ', '
    $mac = (Get-NetAdapter -Name $c.InterfaceAlias -ErrorAction SilentlyContinue).MacAddress
    Write-Output "  Adapter      : $($c.InterfaceAlias)"
    Write-Output "  IPv4 Address : $($c.IPv4Address.IPAddress)"
    Write-Output "  Prefix Len   : /$($c.IPv4Address.PrefixLength)"
    Write-Output "  Default GW   : $($c.IPv4DefaultGateway.NextHop)"
    Write-Output "  DNS Servers  : $dns"
    Write-Output "  MAC Address  : $mac"
    Write-Output "  ──────────────────────────────────────────────"
}
"""
    },
    {
        "id": "net_connectivity",
        "label": "Test Network Connectivity (Ping Suite)",
        "category": "Network",
        "description": "Tests ping to gateway, DNS providers, Google, and Microsoft",
        "command": r"""
$gw = (Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object {$_.IPv4DefaultGateway} | Select-Object -First 1).IPv4DefaultGateway.NextHop
$targets = [ordered]@{
    "Default Gateway"        = $gw
    "Google Public DNS"      = "8.8.8.8"
    "Cloudflare DNS"         = "1.1.1.1"
    "Google.com"             = "google.com"
    "Microsoft.com"          = "microsoft.com"
    "Windows Update"         = "windowsupdate.microsoft.com"
}
Write-Output "  Target                      Address                   Status   Latency"
Write-Output "  ─────────────────────────────────────────────────────────────────────"
foreach ($t in $targets.GetEnumerator()) {
    if (-not $t.Value) { continue }
    $r = Test-NetConnection -ComputerName $t.Value -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    $ok      = if($r.PingSucceeded) { "✓ PASS" } else { "✗ FAIL" }
    $latency = if($r.PingReplyDetails) { "$($r.PingReplyDetails.RoundtripTime) ms" } else { "—" }
    Write-Output "  $($t.Key.PadRight(28)) $($t.Value.PadRight(26)) $ok   $latency"
}
"""
    },
    {
        "id": "net_adapter_stats",
        "label": "Network Adapter Speed & Traffic Stats",
        "category": "Network",
        "description": "Shows link speed, status, and byte counters for active adapters",
        "command": r"""
$adapters = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'Up'}
if (-not $adapters) { Write-Output "  No active adapters found"; return }
foreach ($a in $adapters) {
    $stats = $a | Get-NetAdapterStatistics -ErrorAction SilentlyContinue
    $speed = if($a.LinkSpeed) { "$([math]::Round($a.LinkSpeed/1MB,0)) Mbps" } else { "Unknown" }
    Write-Output "  Adapter  : $($a.Name) — $($a.InterfaceDescription)"
    Write-Output "  Status   : $($a.Status)  |  Speed: $speed  |  MAC: $($a.MacAddress)"
    if ($stats) {
        Write-Output "  Sent     : $([math]::Round($stats.SentBytes/1MB,2)) MB ($($stats.SentUnicastPackets) pkts)"
        Write-Output "  Received : $([math]::Round($stats.ReceivedBytes/1MB,2)) MB ($($stats.ReceivedUnicastPackets) pkts)"
    }
    Write-Output "  ──────────────────────────────────────────────────────────"
}
"""
    },
    {
        "id": "reset_network",
        "label": "Reset TCP/IP & Winsock Stack",
        "category": "Network",
        "description": "Resets Winsock, TCP/IP stack, flushes DNS, renews IP lease",
        "command": r"""
Write-Output "  Resetting Winsock catalog..."
netsh winsock reset 2>&1 | Out-Null
Write-Output "  Winsock reset complete"
Write-Output "  Resetting TCP/IP stack (IPv4 & IPv6)..."
netsh int ip   reset 2>&1 | Out-Null
netsh int ipv6 reset 2>&1 | Out-Null
Write-Output "  TCP/IP stack reset complete"
Write-Output "  Flushing DNS resolver cache..."
ipconfig /flushdns 2>&1 | Out-Null
ipconfig /registerdns 2>&1 | Out-Null
Write-Output "  Releasing IP address..."
ipconfig /release 2>&1 | Out-Null
Start-Sleep -Seconds 2
Write-Output "  Renewing IP address..."
ipconfig /renew 2>&1 | Out-Null
Write-Output "  Network stack reset complete"
Write-Output "  NOTE: A REBOOT is recommended to fully apply Winsock/TCP-IP changes"
"""
    },
    {
        "id": "dns_test",
        "label": "DNS Resolution & Latency Test",
        "category": "Network",
        "description": "Tests DNS lookup speed for multiple domains",
        "command": r"""
$domains = @("google.com","microsoft.com","amazon.com","github.com","youtube.com")
Write-Output "  === DNS RESOLUTION LATENCY TEST ==="
Write-Output "  Domain                        IP Address         Latency"
Write-Output "  ──────────────────────────────────────────────────────────"
foreach ($d in $domains) {
    $t  = Measure-Command { $ip = (Resolve-DnsName $d -ErrorAction SilentlyContinue | Select-Object -First 1).IPAddress }
    $ms = [math]::Round($t.TotalMilliseconds,1)
    Write-Output "  $($d.PadRight(30)) $($ip.PadRight(19)) ${ms} ms"
}
"""
    },
    {
        "id": "firewall_status",
        "label": "Firewall & Security Status Report",
        "category": "Network",
        "description": "Reports Windows Firewall profiles, AV products, and listening ports",
        "command": r"""
Write-Output "  === WINDOWS FIREWALL PROFILES ==="
Get-NetFirewallProfile -ErrorAction SilentlyContinue | foreach {
    Write-Output "  $($_.Name.PadRight(14)): Enabled=$($_.Enabled)  Inbound=$($_.DefaultInboundAction)  Outbound=$($_.DefaultOutboundAction)"
}
Write-Output ""
Write-Output "  === ANTIVIRUS / SECURITY PRODUCTS ==="
$av = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
if ($av) { $av | foreach { Write-Output "  AV: $($_.displayName) | State: $($_.productState)" } }
else { Write-Output "  None registered (may be server OS or WMI namespace unavailable)" }
Write-Output ""
Write-Output "  === TOP LISTENING PORTS (TCP) ==="
netstat -an 2>$null | Select-String "LISTENING" | Select-Object -First 20 | foreach { Write-Output "  $_" }
"""
    },
    {
        "id": "active_connections",
        "label": "Active Network Connections Report",
        "category": "Network",
        "description": "Lists all active TCP connections with owning process names",
        "command": r"""
Write-Output "  === ACTIVE TCP CONNECTIONS ==="
Write-Output "  Process                    Local                      Remote                     State"
Write-Output "  ─────────────────────────────────────────────────────────────────────────────────────"
Get-NetTCPConnection -ErrorAction SilentlyContinue |
    Where-Object {$_.State -ne 'Listen' -and $_.RemoteAddress -ne '0.0.0.0' -and $_.RemoteAddress -ne '::'} |
    Select-Object -First 25 | foreach {
        $proc = (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).Name
        if (-not $proc) { $proc = "PID:$($_.OwningProcess)" }
        $local  = "$($_.LocalAddress):$($_.LocalPort)"
        $remote = "$($_.RemoteAddress):$($_.RemotePort)"
        Write-Output "  $($proc.PadRight(27)) $($local.PadRight(27)) $($remote.PadRight(27)) $($_.State)"
    }
"""
    },
]

# ── Build safe metadata list (no commands) for the browser ───────────────────
OPS_META = [
    {"id": o["id"], "label": o["label"],
     "category": o["category"], "description": o["description"]}
    for o in OPERATIONS
]
OPS_MAP = {o["id"]: o for o in OPERATIONS}
CATEGORIES = list(dict.fromkeys(o["category"] for o in OPERATIONS))


# ══════════════════════════════════════════════════════════════════════════════
#  WINRM HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def make_session(hostname, username, password, transport="ntlm"):
    """
    Returns a pypsrp.client.Client -- a real PSRP (PowerShell Remoting
    Protocol) client, identical in spirit to what New-PSSession/
    Invoke-Command use natively in the PowerShell edition. Nothing here
    actually connects yet; the first execute_ps() call opens the runspace.

    transport accepts the exact same strings already used by the "Auth
    Transport" dropdown ("ntlm"/"basic"/"kerberos"/"credssp") -- pypsrp's
    `auth` parameter uses this identical vocabulary, so no translation is
    needed.

    Basic auth is a special case: unlike ntlm/kerberos/credssp/negotiate,
    it has no protocol-level message encryption of its own, so pypsrp
    refuses to construct a WSMan client for it with the default
    encryption="auto" over plain HTTP (raises ValueError immediately --
    caught this in testing before it ever reached a real target). This
    tool has always used plain HTTP for every transport, so Basic auth's
    credentials were already unprotected at the transport layer either
    way; encryption="never" here just makes that pre-existing, already-
    accepted posture explicit for the one auth mode where it actually
    matters, instead of the whole client failing to construct.
    """
    kwargs = dict(
        username=username,
        password=password,
        auth=transport,
        ssl=False,
        port=5985,
        connection_timeout=30,
        read_timeout=180,
        operation_timeout=170,
    )
    if transport == "basic":
        kwargs["encryption"] = "never"
    return Client(hostname, **kwargs)


def run_remote_ps(session, script, label=""):
    """
    Execute a PowerShell script on the remote host over real PSRP
    (Fix #18).

    Why this replaced the old -EncodedCommand/chunked-temp-file engine:
    that approach was hand-rolling, at the application layer, exactly what
    the PSRP protocol already does correctly and natively --
    fragmenting arbitrarily large scripts, keeping Success/Error/Warning/
    Verbose/Debug/Progress cleanly separated, and transporting Unicode
    without any file-encoding guesswork. Every one of Fix #6, #7, #11,
    #12, and #17 was a real bug in that hand-rolled machinery; PSRP simply
    doesn't have that class of bug, because it was never re-implementing
    process-spawn/command-line/file-encoding semantics in the first place.
    Concretely, this also means: no command-line-length limit of any kind
    (so no minify/chunk/adaptive-retry machinery needed), no temp files
    written to the target for script delivery (so a near-full disk on the
    target no longer breaks every single operation), and no CLIXML text
    to parse (errors arrive as properly typed, cleanly str()-able
    ErrorRecord objects, and Progress records never mix into them).

    Verified against pypsrp's own recorded real-WinRM-server test fixtures
    (test_client_execute_ps / test_client_execute_ps_failure) rather than
    just the docs -- see the bug-fix history for details.

    NOTE (Fix #19): the preamble deliberately does NOT set
    [Console]::OutputEncoding. That line was carried over unchanged from
    the old -EncodedCommand engine, where it mattered because output was
    captured as a raw console byte stream. Real PSRP sessions run inside
    a RunspacePool with no console at all -- touching [Console] there
    throws "Exception setting 'OutputEncoding': 'The handle is invalid.'"
    on every single call, which is exactly what broke every task after
    Fix #18 shipped. PSRP transports Write-Output/Write-Host text
    correctly on its own regardless of any encoding preference (confirmed
    against multiple independent real-world reports of this exact error
    in remote PSSessions) -- do not add this line back.
    """
    preamble = (
        "$ErrorActionPreference = 'Continue'\n"
        "$ProgressPreference = 'SilentlyContinue'\n"
        "$WarningPreference = 'SilentlyContinue'\n"
    )
    try:
        output, streams, had_errors = session.execute_ps(preamble + script)
        error_lines = [str(e).strip() for e in streams.error if str(e).strip()]
        success = not had_errors
        return output, "\n".join(error_lines), success
    except AuthenticationError:
        return "", "CRED_ERR:Invalid username or password", False
    except (WinRMTransportError, WSManFaultError) as e:
        return "", f"TRANSPORT_ERR:{e}", False
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return "", "TIMEOUT_ERR:Operation timed out after 170 seconds", False
    except requests.exceptions.ConnectionError as e:
        return "", f"TRANSPORT_ERR:{e}", False
    except Exception as e:
        return "", f"ERR:{e}", False


# ══════════════════════════════════════════════════════════════════════════════
#  FLASK ROUTES
# ══════════════════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    return render_template("index.html",
                           ops=json.dumps(OPS_META),
                           cats=json.dumps(CATEGORIES),
                           copyright=COPYRIGHT)


@app.route("/api/test", methods=["POST"])
def test_connection():
    data      = request.json or {}
    hostname  = data.get("hostname",  "").strip()
    username  = data.get("username",  "").strip()
    password  = data.get("password",  "")
    transport = data.get("transport", "ntlm")

    if not hostname: return jsonify({"status": "error",   "msg": "Hostname is required"})
    if not username: return jsonify({"status": "error",   "msg": "Username is required"})
    if not password: return jsonify({"status": "warning", "msg": "Password is empty — connection may fail"})

    # DNS resolve
    try:
        ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        return jsonify({"status": "error",
                        "msg": f"Cannot resolve '{hostname}'. Check hostname or DNS."})

    # WinRM auth test
    try:
        session = make_session(hostname, username, password, transport)
        stdout, stderr, ok = run_remote_ps(session, 'Write-Output "PING_OK_$env:COMPUTERNAME"')
        if ok and "PING_OK_" in stdout:
            remote_name = stdout.strip().replace("PING_OK_", "")
            return jsonify({"status": "success",
                            "msg": f"Connected to {hostname} ({ip}) as '{username}'. "
                                   f"Remote computer: {remote_name}. WinRM OK."})
        else:
            return jsonify({"status": "error",
                            "msg": f"WinRM connected but test command failed.\n"
                                   f"STDOUT: {stdout[:200]}\nSTDERR: {stderr[:200]}"})
    except AuthenticationError:
        return jsonify({"status": "cred_error",
                        "msg": f"Authentication failed for '{username}' on {hostname}.\n"
                               f"Try: DOMAIN\\username  or  username@domain.local"})
    except Exception as e:
        err = str(e)
        if "5985" in err or "refused" in err.lower() or "timed out" in err.lower():
            return jsonify({"status": "winrm_error",
                            "msg": f"Cannot reach WinRM on {hostname}:5985.\n"
                                   f"Run on target (Admin): Enable-PSRemoting -Force"})
        return jsonify({"status": "error", "msg": f"Connection error: {err}"})


@app.route("/api/run", methods=["POST"])
def run_tasks():
    data      = request.json or {}
    hostname  = data.get("hostname",  "").strip()
    username  = data.get("username",  "").strip()
    password  = data.get("password",  "")
    transport = data.get("transport", "ntlm")
    task_ids  = set(data.get("tasks", []))

    selected = [op for op in OPERATIONS if op["id"] in task_ids]

    _stop_flag.clear()

    now       = datetime.datetime.now()
    ts        = now.strftime("%Y%m%d_%H%M%S")
    safe_host = re.sub(r"[^\w\-.]", "_", hostname)
    log_path  = LOG_DIR / f"AdminTool_{safe_host}_{ts}.log"

    def generate():
        def ev(data_dict):
            return f"data: {json.dumps(data_dict)}\n\n"

        log_lines = []

        def lf(text):
            log_lines.append(text)

        header_txt = [
            "=" * 60,
            f"  PC ADMIN & PERFORMANCE TOOL  v2.1  -- Web-Service Edition",
            f"  {COPYRIGHT.splitlines()[0]}",
            "=" * 60,
            f"  Target   : {hostname}",
            f"  Username : {username}",
            f"  Transport: {transport}",
            f"  Date/Time: {now.strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Tasks    : {len(selected)} selected",
            f"  Log File : {log_path.name}",
            "=" * 60,
            "",
        ]
        for line in header_txt:
            lf(line)
            yield ev({"type": "header" if "=" in line or "TOOL" in line else
                               "info" if "Target" in line or "Username" in line or
                                         "Date" in line or "Tasks" in line or "Log" in line else
                               "dim", "text": line})

        # Create WinRM session
        try:
            session = make_session(hostname, username, password, transport)
            # Quick test
            _, stderr_test, ok_test = run_remote_ps(session, 'Write-Output "SESSION_OK"')
            if not ok_test:
                msg = f"  ✗ Cannot establish session: {stderr_test}"
                yield ev({"type": "error", "text": msg})
                lf(msg)
                yield ev({"type": "done", "success": False, "log": log_path.name})
                with open(log_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(log_lines))
                return
            yield ev({"type": "success", "text": "  ✓ WinRM session established"})
            lf("  Session established")
        except AuthenticationError:
            msg = "  ✗ AUTHENTICATION FAILED — check username/password and domain format"
            yield ev({"type": "error", "text": msg})
            lf(msg)
            yield ev({"type": "done", "success": False})
            return
        except Exception as e:
            msg = f"  ✗ Cannot connect: {e}\n  Ensure WinRM is enabled: Enable-PSRemoting -Force"
            yield ev({"type": "error", "text": msg})
            lf(msg)
            yield ev({"type": "done", "success": False})
            return

        yield ev({"type": "blank"})

        total = len(selected)
        for idx, task in enumerate(selected):
            if _stop_flag.is_set():
                yield ev({"type": "warning", "text": "\n  ⚠ STOPPED by user request"})
                lf("  STOPPED")
                break

            pct = int((idx / total) * 100)
            yield ev({"type": "progress", "value": pct})
            yield ev({"type": "task_start",
                      "text": f"▶ [{idx+1}/{total}]  {task['label']}",
                      "idx": idx, "total": total,
                      "label": task["label"]})
            yield ev({"type": "dim",  "text": f"    Category : {task['category']}"})
            yield ev({"type": "dim",  "text": f"    Purpose  : {task['description']}"})
            yield ev({"type": "dim",  "text": f"    {'─'*50}"})

            lf(f"\n▶ [{idx+1}/{total}]  {task['label']}")
            lf(f"    {task['description']}")
            lf(f"    {'─'*50}")

            t_start = time.time()
            stdout, stderr, success = run_remote_ps(session, task["command"], task["label"])

            # Auto-reconnect on a dropped/timed-out session, then retry once
            if not success and stderr.startswith(("TRANSPORT_ERR", "TIMEOUT_ERR")):
                yield ev({"type": "warning", "text": "    Connection lost -- reconnecting..."})
                lf("    Connection lost -- reconnecting...")
                try:
                    session = make_session(hostname, username, password, transport)
                    _, _, reconn_ok = run_remote_ps(session, 'Write-Output "RECONNECTED"')
                    if reconn_ok:
                        yield ev({"type": "success", "text": "    Session reconnected -- retrying task"})
                        lf("    Session reconnected -- retrying task")
                        stdout, stderr, success = run_remote_ps(session, task["command"], task["label"])
                    else:
                        yield ev({"type": "error", "text": "    Reconnect failed"})
                        lf("    Reconnect failed")
                except Exception as e:
                    yield ev({"type": "error", "text": f"    Reconnect failed: {e}"})
                    lf(f"    Reconnect failed: {e}")

            elapsed = round(time.time() - t_start, 1)

            # Output lines with colour hints
            if stdout.strip():
                for line in stdout.splitlines():
                    line = line.rstrip()
                    if not line:
                        continue
                    lo = line.lower()
                    tag = ("success" if any(k in lo for k in ["freed","cleared","complete","restarted","ok","pass","removed","deleted","✓"]) else
                           "warning" if any(k in lo for k in ["⚠","warn","skip","not found","empty","already","none","cannot"]) else
                           "error"   if any(k in lo for k in ["error","fail","denied","exception"]) else
                           "output")
                    yield ev({"type": tag, "text": f"    {line}"})
                    lf(f"    {line}")
            else:
                # No stdout at all. If stderr has a specific reason, let
                # that speak for itself below rather than burying it under
                # four generic guesses that usually aren't the real cause.
                if not stderr.strip():
                    yield ev({"type": "warning",
                              "text": "    ⚠ No output received. Possible reasons:"})
                    yield ev({"type": "dim",
                              "text": "      • Insufficient permissions on remote host"})
                    yield ev({"type": "dim",
                              "text": "      • Path C:\\Users not accessible under current credentials"})
                    yield ev({"type": "dim",
                              "text": "      • PowerShell Execution Policy restriction on target"})
                    yield ev({"type": "dim",
                              "text": "      • Operation completed with nothing to process (already clean)"})
                lf("    (no output)")

            if stderr.strip():
                for line in stderr.splitlines():
                    if not line.strip():
                        continue
                    # Translate common error codes to friendly messages
                    if "CRED_ERR" in line:
                        line = "⚠ Authentication failed — re-check credentials"
                    elif "TRANSPORT_ERR" in line:
                        line = "⚠ WinRM transport error — connection may have dropped"
                    elif "TIMEOUT_ERR" in line:
                        line = "⚠ Task timed out (>170s) — operation may still be running"
                    elif "AccessDenied" in line or "Access is denied" in line:
                        line = "⚠ Access denied — target requires elevated/admin permissions"
                    yield ev({"type": "error", "text": f"    ✗ {line}"})
                    lf(f"    ✗ {line}")

            status = "✓ Completed" if success else "⚠ Completed with errors"
            yield ev({"type": "success" if success else "warning",
                      "text": f"    {status} in {elapsed}s"})
            yield ev({"type": "blank"})
            lf(f"    {status} in {elapsed}s\n")

        yield ev({"type": "progress", "value": 100})

        stopped = _stop_flag.is_set()
        footer_txt = [
            "",
            "=" * 60,
            f"  {'STOPPED BY USER' if stopped else 'ALL TASKS COMPLETED ✓'}",
            f"  Finished : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Log saved: {log_path.name}",
            f"  {COPYRIGHT.splitlines()[0]}",
            "=" * 60,
        ]
        for line in footer_txt:
            lf(line)
            yield ev({"type": "warning" if stopped and "STOPPED" in line else
                               "success" if "COMPLETED" in line else
                               "dim" if "Log" in line or "©" in line else
                               "header",
                      "text": line})

        yield ev({"type": "done", "success": not stopped, "log": log_path.name})

        # Write log file
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines))

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache",
                 "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


@app.route("/api/stop", methods=["POST"])
def stop():
    _stop_flag.set()
    return jsonify({"status": "stopping"})


@app.route("/api/logs")
def list_logs():
    try:
        logs = sorted(LOG_DIR.glob("*.log"),
                      key=lambda p: p.stat().st_mtime, reverse=True)
        return jsonify([{"name": l.name,
                         "size": l.stat().st_size,
                         "modified": datetime.datetime.fromtimestamp(
                             l.stat().st_mtime).strftime("%Y-%m-%d %H:%M")}
                        for l in logs[:30]])
    except Exception:
        return jsonify([])


def _lan_ip():
    """Best-effort detection of this host's LAN IP for the startup banner."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    lan_ip = _lan_ip()
    print("=" * 60)
    print("  PC Admin & Performance Tool  v2.1  -- Web-Service Edition")
    print(f"  {COPYRIGHT.splitlines()[0]}")
    print("=" * 60)
    print(f"  Local   : http://localhost:{SERVICE_PORT}")
    print(f"  Network : http://{lan_ip}:{SERVICE_PORT}   (reachable from any")
    print("            host on the same allowed subnet)")
    print(f"  Logs    : {LOG_DIR}")
    print("=" * 60)
    app.run(host="0.0.0.0", port=SERVICE_PORT, debug=False, threaded=True)
