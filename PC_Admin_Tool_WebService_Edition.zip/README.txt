PC Admin & Performance Tool -- Web-Service Edition  (v2.1)
================================================================
Runs as a standalone network service on PORT 3030. Once started on a
host, anyone on the same allowed subnet can open it from a browser at:

    http://<hosting-machine-IP>:3030

All logs and session files are written LOCALLY on the hosting machine
(the "logs" folder next to app.py) -- not on the client's browser/PC.

WHAT'S IN THIS FOLDER
  app.py                        Flask backend, 36 remote PowerShell operations
  templates/index.html          Web UI (dark theme, category tabs, live log)
  pcadmintool_service.py        Windows Service wrapper (pywin32)
  requirements.txt              Flask, pywinrm, pywin32 (Windows only)
  install_service.bat           Windows / Windows Server: installs as a REAL
                                 Windows Service (shows in services.msc)
  uninstall_service.bat         Windows: stops & removes the service
  run_console_testmode.bat      Windows: quick foreground test run (not a
                                 service -- window must stay open)
  install_and_run.sh            Linux installer + launcher
  pcadmintool.service.template  Linux: optional systemd unit (real service)
  README.txt                    This file

WORKS ON
  - The HOSTING machine (runs this tool): Linux, Windows 10/11, or
    Windows Server 2016+, with Python 3.9+.
  - The TARGET machines it manages: must be Windows, with WinRM enabled
    (run once on each target, as Admin: Enable-PSRemoting -Force).
  - Any CLIENT browser on the same subnet, no install needed there --
    just a browser pointed at http://<hosting-IP>:3030

HOW TO RUN -- Windows / Windows Server  (installs as a real Service)
  1. Copy this folder to the machine that will host the service, e.g.
     C:\PCAdminTool\
  2. Double-click install_service.bat and approve the UAC prompt.
     This installs dependencies, registers "PC Admin & Performance
     Tool - Web Service" in services.msc with Startup Type = Automatic,
     opens firewall port 3030, and starts it immediately.
  3. Open services.msc to confirm -- you'll see it listed, Status
     "Running", Startup type "Automatic". It will keep running in the
     background (no console window) and restart automatically on reboot.
  4. Share the URL with anyone on the same subnet:
        http://<this-machine-IP-or-name>:3030
  5. To stop/remove it later, run uninstall_service.bat.

  Prefer to just test it first without installing a service? Run
  run_console_testmode.bat instead (foreground only, window must stay open).

HOW TO RUN -- Linux
  1. Copy this folder to the host.
  2. chmod +x install_and_run.sh && ./install_and_run.sh
     (or ./install_and_run.sh --daemon to background it)
  3. To install as a real systemd service (auto-start on boot, restart
     on crash, equivalent to the Windows Service above), see
     pcadmintool.service.template.

FIREWALL
  Make sure TCP port 3030 is allowed inbound on the hosting machine so
  other hosts on the subnet can reach it. install_and_run.bat attempts
  this automatically on Windows via netsh; on Linux, open it with your
  distro's firewall tool, e.g.:
    sudo ufw allow 3030/tcp
    sudo firewall-cmd --add-port=3030/tcp --permanent && sudo firewall-cmd --reload

LOGS & FILES
  Every run writes: logs/AdminTool_<hostname>_<timestamp>.log
  on the HOSTING machine (wherever app.py lives), regardless of which
  browser/client triggered the run.

WHY NOT WAITRESS?
  This tool streams live task output to the browser as it runs (Server-
  Sent Events). Werkzeug's threaded server (what app.py uses via
  app.run(..., threaded=True)) flushes each line immediately, which SSE
  needs. Waitress buffers responses before sending, which makes the web
  UI look "stuck" after clicking Run -- so both the service wrapper and
  the console/Linux launchers deliberately run app.py directly instead.

SECURITY NOTE
  Credentials are submitted from the browser to this service over plain
  HTTP by default and used to open a WinRM session to the target. Only
  run this on a trusted, access-controlled subnet, or put it behind
  HTTPS (a reverse proxy such as nginx/IIS with a TLS certificate) for
  anything beyond an isolated internal network.

(c) 2024-2026 Abdullah | All Rights Reserved | abuabdullah.be@outlook.com
