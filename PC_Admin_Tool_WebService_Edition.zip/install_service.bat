@echo off
:: ============================================================
::  PC Admin & Performance Tool -- Web-Service Edition
::  Installs and starts a REAL Windows Service (visible in
::  services.msc, auto-starts on boot). Windows / Windows Server.
::  (c) 2024-2026 Abdullah | All Rights Reserved
:: ============================================================
setlocal
cd /d "%~dp0"

:: Must run elevated to install a service
net session >nul 2>&1
if not %errorLevel%==0 (
    echo Requesting Administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on this machine.
    echo Install Python 3.9+ from https://www.python.org/downloads/ and re-run this file.
    pause
    exit /b 1
)

echo Installing/updating dependencies (Flask, pywinrm, pywin32)...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt

:: pywin32 needs its post-install step run once
python -m pywin32_postinstall -install >nul 2>nul

echo.
echo Opening inbound firewall rule for TCP port 3030...
netsh advfirewall firewall show rule name="PC Admin Tool 3030" >nul 2>nul
if errorlevel 1 (
    netsh advfirewall firewall add rule name="PC Admin Tool 3030" dir=in action=allow protocol=TCP localport=3030 >nul 2>nul
)

echo.
echo Registering Windows Service (auto-start on boot)...
python pcadmintool_service.py --startup=auto install
if errorlevel 1 (
    echo Service install failed -- see the error above.
    pause
    exit /b 1
)

echo Starting service...
net start PCAdminTool

echo.
echo ============================================================
echo   Service installed:  "PC Admin ^& Performance Tool - Web Service"
echo   Check it in services.msc -- it will keep running in the
echo   background and restart automatically on reboot.
echo   Web UI (from any host on this subnet): http://%COMPUTERNAME%:3030
echo ============================================================
pause
