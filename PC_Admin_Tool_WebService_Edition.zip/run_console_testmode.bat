@echo off
:: ============================================================
::  PC Admin & Performance Tool -- Web-Service Edition
::  CONSOLE / TEST MODE -- runs in the foreground for quick testing.
::  For a real background Windows Service (services.msc, auto-start
::  on boot), use install_service.bat instead.
:: ============================================================
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on this machine.
    echo Install Python 3.9+ from https://www.python.org/downloads/ and re-run this file.
    pause
    exit /b 1
)

echo Installing/updating dependencies...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt

echo.
echo ============================================================
echo   TEST MODE -- running in this console window on port 3030.
echo   This window must stay open. Press CTRL+C to stop.
echo   For a real Windows Service instead, run install_service.bat
echo ============================================================
python app.py
