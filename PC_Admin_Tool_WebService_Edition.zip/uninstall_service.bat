@echo off
:: ============================================================
::  PC Admin & Performance Tool -- uninstall the Windows Service
:: ============================================================
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if not %errorLevel%==0 (
    echo Requesting Administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Stopping service (if running)...
net stop PCAdminTool >nul 2>nul

echo Removing service...
python pcadmintool_service.py remove

echo.
echo Removing firewall rule...
netsh advfirewall firewall delete rule name="PC Admin Tool 3030" >nul 2>nul

echo Done. The service has been removed from services.msc.
pause
